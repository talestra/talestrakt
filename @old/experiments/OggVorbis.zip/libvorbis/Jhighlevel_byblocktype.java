package libvorbis;

final class Jhighlevel_byblocktype {
	double tone_mask_setting      = 0;
	double tone_peaklimit_setting = 0;
	double noise_bias_setting     = 0;
	double noise_compand_setting  = 0;
}
