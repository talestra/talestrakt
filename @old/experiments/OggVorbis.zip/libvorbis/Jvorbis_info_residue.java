package libvorbis;

abstract class Jvorbis_info_residue {
}
