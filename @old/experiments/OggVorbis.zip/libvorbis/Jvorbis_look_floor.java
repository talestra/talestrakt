package libvorbis;

abstract class Jvorbis_look_floor {
}
