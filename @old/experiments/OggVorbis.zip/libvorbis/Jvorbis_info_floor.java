package libvorbis;

abstract class Jvorbis_info_floor {
	static final int VIF_POSIT = 63;
	static final int VIF_CLASS = 16;
	static final int VIF_PARTS = 31;
}
