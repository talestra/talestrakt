package libFLAC;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;

// XXX java: make members public only for testing. FLAC__bitwriter_dump can be commented for regular using
//public
final class JFLAC__BitWriter {
	private static final int FLAC__BYTES_PER_WORD = 4;
	private static final int FLAC__BITS_PER_WORD = 32;
	private static final int FLAC__WORD_ALL_ONES = (0xffffffff);
	/**
	 * The default capacity here doesn't matter too much.  The buffer always grows
	 * to hold whatever is written to it.  Usually the encoder will stop adding at
	 * a frame or metadata block, then write that out and clear the buffer for the
	 * next one.
	 */
	private static final int FLAC__BITWRITER_DEFAULT_CAPACITY = 32768 / FLAC__BYTES_PER_WORD; /* size in words */

	/** When growing, increment 4K at a time */
	private static final int FLAC__BITWRITER_DEFAULT_INCREMENT = 4096 / FLAC__BYTES_PER_WORD; /* size in words */

	/* java: extracted in place
	private static int FLAC__WORDS_TO_BITS(int words) {
		return ((words) * FLAC__BITS_PER_WORD);
	}
	private static int FLAC__TOTAL_BITS(JFLAC__BitWriter bw) {
		return (FLAC__WORDS_TO_BITS(bw.words) + bw.bits);
	}
	*/

	private int[] buffer = null;
	private final Jbitwriter_helper byte_buffer = new Jbitwriter_helper();
	/** accumulator; bits are right-justified; when full, accum is appended to buffer */
	private int accum = 0;
	/** capacity of buffer in words */
	private int capacity = 0;// XXX java: can be replaced by the buffer.length
	/** # of complete words in buffer */
	private int words = 0;
	/** # of used bits in accum */
	private int bits = 0;

	/** WATCHOUT: The current implementation only grows the buffer. */
	private final boolean bitwriter_grow_(final int bits_to_add)
	{
		//FLAC__ASSERT(0 != bw);
		//FLAC__ASSERT(0 != bw->buffer);

		/* calculate total words needed to store 'bits_to_add' additional bits */
		int new_capacity = this.words + ((this.bits + bits_to_add + FLAC__BITS_PER_WORD - 1) / FLAC__BITS_PER_WORD);

		/* it's possible (due to pessimism in the growth estimation that
		 * leads to this call) that we don't actually need to grow
		 */
		if( this.capacity >= new_capacity ) {
			return true;
		}

		/* round up capacity increase to the nearest FLAC__BITWRITER_DEFAULT_INCREMENT */
		if( ((new_capacity - this.capacity) % FLAC__BITWRITER_DEFAULT_INCREMENT) != 0 ) {
			new_capacity += FLAC__BITWRITER_DEFAULT_INCREMENT - ((new_capacity - this.capacity) % FLAC__BITWRITER_DEFAULT_INCREMENT);
		/* make sure we got everything right */
		//FLAC__ASSERT(0 == (new_capacity - bw->capacity) % FLAC__BITWRITER_DEFAULT_INCREMENT);
		//FLAC__ASSERT(new_capacity > bw->capacity);
		//FLAC__ASSERT(new_capacity >= bw->words + ((bw->bits + bits_to_add + FLAC__BITS_PER_WORD - 1) / FLAC__BITS_PER_WORD));
		}

		// try {
			this.buffer = Arrays.copyOf( this.buffer, new_capacity );
			this.byte_buffer.bytebuffer = new byte[new_capacity * FLAC__BYTES_PER_WORD];
			this.capacity = new_capacity;
		//} catch(OutOfMemoryError e) {
		//	return false;
		//}
		return true;
	}

	/***********************************************************************
	 *
	 * Class constructor/destructor
	 *
	 ***********************************************************************/

	// FLAC__bitwriter_new(), FLAC__bitwriter_delete(JFLAC__BitWriter bw)
	public JFLAC__BitWriter() {
	}

	/***********************************************************************
	 *
	 * Public class methods
	 *
	 ***********************************************************************/

	public final boolean FLAC__bitwriter_init()
	{
		//FLAC__ASSERT(0 != bw);

		this.words = this.bits = 0;
		this.capacity = FLAC__BITWRITER_DEFAULT_CAPACITY;
		//try {
			this.buffer = new int[this.capacity];
			this.byte_buffer.bytebuffer = new byte[this.capacity * FLAC__BYTES_PER_WORD];
		//} catch( OutOfMemoryError e ) {
		//	return false;
		//}

		return true;
	}

	public final void FLAC__bitwriter_free()
	{
		//FLAC__ASSERT(0 != bw);

		this.buffer = null;
		this.capacity = 0;
		this.words = this.bits = 0;
	}

	public final void FLAC__bitwriter_clear()
	{
		this.words = this.bits = 0;
	}

	/*
	@SuppressWarnings("boxing")
	public final void FLAC__bitwriter_dump(java.io.OutputStream out)
	{
		int i, j;
		//if( bw == null ) {
		//	System.out.print("bitwriter is NULL\n");
		//} else
		{
			System.out.printf("bitwriter: capacity=%d words=%d bits=%d total_bits=%d\n", this.capacity, this.words, this.bits, (this.words * FLAC__BITS_PER_WORD + this.bits));

			for( i = 0; i < this.words; i++ ) {
				System.out.printf("%08X: ", i);
				for( j = 0; j < FLAC__BITS_PER_WORD; j++ )
					System.out.printf("%01d", (this.buffer[i] & (1 << (FLAC__BITS_PER_WORD - j - 1))) != 0 ? 1 : 0);
				System.out.print("\n");
			}
			if( this.bits > 0 ) {
				System.out.printf("%08X: ", i);
				for( j = 0; j < this.bits; j++ )
					System.out.printf("%01d", (this.accum & (1 << (this.bits - j - 1))) != 0 ? 1 : 0);
				System.out.print("\n");
			}
		}
	}
	*/

	final int FLAC__bitwriter_get_write_crc16() throws OutOfMemoryError// java: changed. status changed by OutOfMemoryError exception
	{
		//FLAC__ASSERT((bw->bits & 7) == 0); /* assert that we're byte-aligned */

		final Jbitwriter_helper buf = FLAC__bitwriter_get_buffer( /* buffer, bytes */ );

		final int crc = JFLAC_crc.FLAC__crc16( buf.bytebuffer, buf.bytes );
		FLAC__bitwriter_release_buffer();
		return crc;
	}

	final int FLAC__bitwriter_get_write_crc8() throws OutOfMemoryError// java: changed. status changed by OutOfMemoryError exception
	{
		//FLAC__ASSERT((bw->bits & 7) == 0); /* assert that we're byte-aligned */

		final Jbitwriter_helper buf = FLAC__bitwriter_get_buffer( /* buffer, bytes */ );

		final int crc = JFLAC_crc.FLAC__crc8( buf.bytebuffer, buf.bytes );
		FLAC__bitwriter_release_buffer();
		return crc;
	}

	/* java: used only for asserts
	private final boolean FLAC__bitwriter_is_byte_aligned()
	{
		return ((this.bits & 7) == 0);
	}
	*/

	final int FLAC__bitwriter_get_input_bits_unconsumed()
	{
		// return FLAC__TOTAL_BITS( bw );
		return (this.words * FLAC__BITS_PER_WORD + this.bits);
	}

	/** @return null - error, byte_buffer.bytebuffer - data, byte_buffer.bytes - bytes */
	final Jbitwriter_helper /* boolean */ FLAC__bitwriter_get_buffer(/* final byte[][] buffer, int[] bytes */) throws OutOfMemoryError
	{
		//FLAC__ASSERT((bw->bits & 7) == 0);
		/* double protection */
		if( (this.bits & 7) != 0 ) {
			return null;// false;
		}
		/* if we have bits in the accumulator we have to flush those to the buffer first */
		if( this.bits != 0 ) {
			//FLAC__ASSERT(bw->words <= bw->capacity);
			if( this.words == this.capacity && ! bitwriter_grow_( FLAC__BITS_PER_WORD ) ) {
				return null;// false;
			}
			/* append bits as complete word to buffer, but don't change bw->accum or bw->bits */
			this.buffer[this.words] = this.accum << (FLAC__BITS_PER_WORD - this.bits);
		}
		/* now we can just return what we have */
		//buffer[0] = (byte[])this.buffer;
		//bytes[0] = (FLAC__BYTES_PER_WORD * this.words) + (this.bits >>> 3);
		//
		final int full_words = FLAC__BYTES_PER_WORD * this.words;
		int trailing_bytes = this.bits >>> 3;
		//final byte[] buffer = new byte[full_words + trailing_bytes];
		this.byte_buffer.bytes = full_words + trailing_bytes;
		final byte[] bb = this.byte_buffer.bytebuffer;// java
		ByteBuffer.wrap( bb, 0, bb.length ).order( ByteOrder.BIG_ENDIAN ).asIntBuffer().put( this.buffer, 0, this.words );
		if( trailing_bytes != 0 ) {// TODO may be there is more elegant variant?
			int last_word = this.buffer[this.words] >>> ((FLAC__BYTES_PER_WORD - trailing_bytes) << 3);
			do {
				bb[full_words + (--trailing_bytes)] = (byte)last_word;
				last_word >>>= 8;
			} while( trailing_bytes > 0 );
		}
		return this.byte_buffer;// true;
	}

	final void FLAC__bitwriter_release_buffer()
	{
		/* nothing to do.  in the future, strict checking of a 'writer-is-in-
		 * get-mode' flag could be added everywhere and then cleared here
		 */
		//(void)bw;
	}

	public final boolean FLAC__bitwriter_write_zeroes(int nbits)
	{
		//FLAC__ASSERT(0 != bw);
		//FLAC__ASSERT(0 != bw->buffer);

		if( nbits == 0 ) {
			return true;
		}
		/* slightly pessimistic size check but faster than "<= bw->words + (bw->bits+bits+FLAC__BITS_PER_WORD-1)/FLAC__BITS_PER_WORD" */
		if( this.capacity <= this.words + nbits && ! bitwriter_grow_( nbits ) ) {
			return false;
		}
		/* first part gets to word alignment */
		if( this.bits != 0 ) {
			int n = FLAC__BITS_PER_WORD - this.bits;
			if( n > nbits ) {
				n = nbits;
			}
			this.accum <<= n;
			nbits -= n;
			this.bits += n;
			if( this.bits == FLAC__BITS_PER_WORD ) {
				this.buffer[this.words++] = this.accum;
				this.bits = 0;
			} else {
				return true;
			}
		}
		/* do whole words */
		final int[] buf = this.buffer;// java
		int nwords = this.words;// java
		while( nbits >= FLAC__BITS_PER_WORD ) {
			buf[nwords++] = 0;
			nbits -= FLAC__BITS_PER_WORD;
		}
		this.words = nwords;
		/* do any leftovers */
		if( nbits > 0 ) {
			this.accum = 0;
			this.bits = nbits;
		}
		return true;
	}

	public final boolean FLAC__bitwriter_write_raw_uint32(final int val, final int nbits)
	{
		/* WATCHOUT: code does not work with <32bit words; we can make things much faster with this assertion */
		//FLAC__ASSERT(FLAC__BITS_PER_WORD >= 32);

		//FLAC__ASSERT(0 != bw);
		//FLAC__ASSERT(0 != bw->buffer);

		//FLAC__ASSERT(bits <= 32);
		if( nbits == 0 ) {
			return true;
		}

		/* slightly pessimistic size check but faster than "<= bw->words + (bw->bits+bits+FLAC__BITS_PER_WORD-1)/FLAC__BITS_PER_WORD" */
		if( this.capacity <= this.words + nbits && ! bitwriter_grow_( nbits ) ) {
			return false;
		}

		final int left = FLAC__BITS_PER_WORD - this.bits;
		if( nbits < left ) {
			this.accum <<= nbits;
			this.accum |= val;
			this.bits += nbits;
		}
		else if( this.bits != 0 ) { /* WATCHOUT: if bw->bits == 0, left==FLAC__BITS_PER_WORD and bw->accum<<=left is a NOP instead of setting to 0 */
			this.accum <<= left;
			this.accum |= val >>> (this.bits = nbits - left);
			this.buffer[this.words++] = this.accum;
			this.accum = val;
		}
		else {
			this.accum = val;
			this.bits = 0;
			this.buffer[this.words++] = val;
		}

		return true;
	}

	final boolean FLAC__bitwriter_write_raw_int32(int val, final int nbits)
	{
		/* zero-out unused bits */
		if( nbits < 32 ) {
			val &= (~(0xffffffff << nbits));
		}

		return FLAC__bitwriter_write_raw_uint32( val, nbits );
	}

	public final boolean FLAC__bitwriter_write_raw_uint64(final long val, final int nbits)
	{
		/* this could be a little faster but it's not used for much */
		if( nbits > 32 ) {
			return
				FLAC__bitwriter_write_raw_uint32( (int)(val >>> 32), nbits - 32 ) &&
				FLAC__bitwriter_write_raw_uint32( (int)val, 32 );
		}// else {
			return FLAC__bitwriter_write_raw_uint32( (int)val, nbits );
		//}
	}

	final boolean FLAC__bitwriter_write_raw_uint32_little_endian(final int val)
	{
		/* this doesn't need to be that fast as currently it is only used for vorbis comments */

		if( ! FLAC__bitwriter_write_raw_uint32( val & 0xff, 8 ) ) {
			return false;
		}
		if( ! FLAC__bitwriter_write_raw_uint32( (val >>> 8) & 0xff, 8 ) ) {
			return false;
		}
		if( ! FLAC__bitwriter_write_raw_uint32( (val >>> 16) & 0xff, 8 ) ) {
			return false;
		}
		if( ! FLAC__bitwriter_write_raw_uint32( val >>> 24, 8 ) ) {
			return false;
		}

		return true;
	}

	final boolean FLAC__bitwriter_write_byte_block(final byte vals[], final int nvals)
	{
		/* this could be faster but currently we don't need it to be since it's only used for writing metadata */
		for( int i = 0; i < nvals; i++ ) {
			if( ! FLAC__bitwriter_write_raw_uint32( vals[i] & 0xff, 8 ) ) {
				return false;
			}
		}

		return true;
	}

	final boolean FLAC__bitwriter_write_unary_unsigned(int val)
	{
		if( val < 32 ) {
			return FLAC__bitwriter_write_raw_uint32( 1, ++val );
		}// else {
			return
				FLAC__bitwriter_write_zeroes( val ) &&
				FLAC__bitwriter_write_raw_uint32( 1, 1 );
		//}
	}

	/* FIXME unused
	private static int FLAC__bitwriter_rice_bits(int val, int parameter)
	{
		int uval;

		//FLAC__ASSERT(parameter < sizeof(unsigned)*8);

		// fold signed to unsigned; actual formula is: negative(v)? -2v-1 : 2v
		uval = (val << 1) ^ (val >> 31);

		return 1 + parameter + (uval >> parameter);
	}
	*/

/* #if 0 // UNUSED
	private static int FLAC__bitwriter_golomb_bits_signed(int val, int parameter)
	{
		int bits, msbs, uval;
		int k;

		//FLAC__ASSERT(parameter > 0);

		// fold signed to unsigned
		if( val < 0 )
			uval = (((-(++val)) << 1) + 1);
		else
			uval = (val << 1);

		k = Jformat.FLAC__bitmath_ilog2( parameter );
		if( parameter == 1 << k ) {
			//FLAC__ASSERT(k <= 30);

			msbs = uval >>> k;
			bits = 1 + k + msbs;
		}
		else {
			int q, r, d;

			d = (1 << (k + 1)) - parameter;
			q = uval / parameter;
			r = uval - (q * parameter);

			bits = 1 + q + k;
			if( r >= d )
				bits++;
		}
		return bits;
	}

	private static int FLAC__bitwriter_golomb_bits_unsigned(int uval, int parameter)
	{
		int bits, msbs;
		int k;

		//FLAC__ASSERT(parameter > 0);

		k = Jformat.FLAC__bitmath_ilog2( parameter );
		if( parameter == 1 << k ) {
			//FLAC__ASSERT(k <= 30);

			msbs = uval >>> k;
			bits = 1 + k + msbs;
		}
		else {
			int q, r, d;

			d = (1 << (k + 1)) - parameter;
			q = uval / parameter;
			r = uval - (q * parameter);

			bits = 1 + q + k;
			if( r >= d )
				bits++;
		}
		return bits;
	}
//#endif /* UNUSED */

	/* FIXME never used
	private final boolean FLAC__bitwriter_write_rice_signed(int val, int parameter)
	{
		int total_bits, interesting_bits, msbs;
		int uval, pattern;

		//FLAC__ASSERT(0 != bw);
		//FLAC__ASSERT(0 != bw->buffer);
		//FLAC__ASSERT(parameter < 8*sizeof(uval));

		// fold signed to unsigned; actual formula is: negative(v)? -2v-1 : 2v
		uval = (val << 1) ^ (val >> 31);

		msbs = uval >>> parameter;
		interesting_bits = 1 + parameter;
		total_bits = interesting_bits + msbs;
		pattern = 1 << parameter; // the unary end bit
		pattern |= (uval & ((1 << parameter) - 1)); // the binary LSBs

		if( total_bits <= 32 )
			return FLAC__bitwriter_write_raw_uint32( pattern, total_bits );
		else
			return
				FLAC__bitwriter_write_zeroes( msbs ) && // write the unary MSBs
				FLAC__bitwriter_write_raw_uint32( pattern, interesting_bits ); // write the unary end bit and binary LSBs
	}
	*/

	final boolean FLAC__bitwriter_write_rice_signed_block(final int[] vals, int offset, int nvals, final int parameter)
	{
		final int mask1 = FLAC__WORD_ALL_ONES << parameter; /* we val|=mask1 to set the stop bit above it... */
		final int mask2 = FLAC__WORD_ALL_ONES >>> (31 - parameter); /* ...then mask off the bits above the stop bit with val&=mask2*/
		final int lsbits = 1 + parameter;

		//FLAC__ASSERT(0 != bw);
		//FLAC__ASSERT(0 != bw->buffer);
		//FLAC__ASSERT(parameter < 8*sizeof(uint32_t)-1);
		/* WATCHOUT: code does not work with <32bit words; we can make things much faster with this assertion */
		//FLAC__ASSERT(FLAC__BITS_PER_WORD >= 32);

		while( nvals != 0 ) {
			/* fold signed to unsigned; actual formula is: negative(v)? -2v-1 : 2v */
			int uval = (vals[offset] << 1) ^ (vals[offset] >> 31);// uint32 or long?

			int msbits = uval >>> parameter;

			if( this.bits != 0 && this.bits + msbits + lsbits < FLAC__BITS_PER_WORD ) { /* i.e. if the whole thing fits in the current uint32_t */
				/* ^^^ if bw->bits is 0 then we may have filled the buffer and have no free uint32_t to work in */
				this.bits = this.bits + msbits + lsbits;
				uval |= mask1; /* set stop bit */
				uval &= mask2; /* mask off unused top bits */
				this.accum <<= msbits + lsbits;
				this.accum |= uval;
			}
			else {
				/* slightly pessimistic size check but faster than "<= bw->words + (bw->bits+msbits+lsbits+FLAC__BITS_PER_WORD-1)/FLAC__BITS_PER_WORD" */
				/* OPT: pessimism may cause flurry of false calls to grow_ which eat up all savings before it */
				if( this.capacity <= this.words + this.bits + msbits + 1/*lsbits always fit in 1 uint32_t*/ && ! bitwriter_grow_( msbits + lsbits ) ) {
					return false;
				}

				if( msbits != 0 ) {
					/* first part gets to word alignment */
					if( this.bits != 0 ) {
						final int left = FLAC__BITS_PER_WORD - this.bits;
						if( msbits < left ) {
							this.accum <<= msbits;
							this.bits += msbits;
							//goto break1;
						}
						else {
							this.accum <<= left;
							msbits -= left;
							this.buffer[this.words++] = this.accum;
							this.bits = 0;
							// java: added to avoid goto break1
							/* do whole words */
							while( msbits >= FLAC__BITS_PER_WORD ) {
								this.buffer[this.words++] = 0;
								msbits -= FLAC__BITS_PER_WORD;
							}
							/* do any leftovers */
							if( msbits > 0 ) {
								this.accum = 0;
								this.bits = msbits;
							}
						}
					} else {// java: added to avoid goto break1
						/* do whole words */
						final int[] buf = this.buffer;// java
						int nwords = this.words;// java
						while( msbits >= FLAC__BITS_PER_WORD ) {
							buf[nwords++] = 0;
							msbits -= FLAC__BITS_PER_WORD;
						}
						this.words = nwords;
						/* do any leftovers */
						if( msbits > 0 ) {
							this.accum = 0;
							this.bits = msbits;
						}
					}
				}
	// break1:
				uval |= mask1; /* set stop bit */
				uval &= mask2; /* mask off unused top bits */

				final int left = FLAC__BITS_PER_WORD - this.bits;
				if( lsbits < left ) {
					this.accum <<= lsbits;
					this.accum |= uval;
					this.bits += lsbits;
				}
				else {
					/* if bw->bits == 0, left==FLAC__BITS_PER_WORD which will always
					 * be > lsbits (because of previous assertions) so it would have
					 * triggered the (lsbits<left) case above.
					 */
					//FLAC__ASSERT(bw->bits);
					//FLAC__ASSERT(left < FLAC__BITS_PER_WORD);
					this.accum <<= left;
					this.accum |= uval >>> (this.bits = lsbits - left);
					this.buffer[this.words++] = this.accum;
					this.accum = uval;
				}
			}
			offset++;//vals++;
			nvals--;
		}
		return true;
	}

/*#if 0 // UNUSED
	private final boolean FLAC__bitwriter_write_golomb_signed(int val, int parameter)
	{
		int total_bits, msbs, uval;
		int k;

		//FLAC__ASSERT(0 != bw);
		//FLAC__ASSERT(0 != bw->buffer);
		//FLAC__ASSERT(parameter > 0);

		// fold signed to unsigned
		if( val < 0 )
			uval = (((-(++val)) << 1) + 1);
		else
			uval = (val << 1);

		k = Jformat.FLAC__bitmath_ilog2( parameter );
		if( parameter == 1 << k ) {
			int pattern;

			//FLAC__ASSERT(k <= 30);

			msbs = uval >>> k;
			total_bits = 1 + k + msbs;
			pattern = 1 << k; // the unary end bit
			pattern |= (uval & ((1 << k) - 1)); // the binary LSBs

			if( total_bits <= 32 ) {
				if( ! FLAC__bitwriter_write_raw_uint32( pattern, total_bits ) )
					return false;
			}
			else {
				// write the unary MSBs
				if( ! FLAC__bitwriter_write_zeroes( msbs ) )
					return false;
				// write the unary end bit and binary LSBs
				if( ! FLAC__bitwriter_write_raw_uint32( pattern, k + 1 ) )
					return false;
			}
		}
		else {
			int q, r, d;

			d = (1 << (k + 1)) - parameter;
			q = uval / parameter;
			r = uval - (q * parameter);
			// write the unary MSBs
			if( ! FLAC__bitwriter_write_zeroes( q ) )
				return false;
			// write the unary end bit
			if( ! FLAC__bitwriter_write_raw_uint32( 1, 1 ) )
				return false;
			// write the binary LSBs
			if( r >= d ) {
				if( ! FLAC__bitwriter_write_raw_uint32( r + d, k + 1 ) )
					return false;
			}
			else {
				if( ! FLAC__bitwriter_write_raw_uint32( r, k ) )
					return false;
			}
		}
		return true;
	}

	private final boolean FLAC__bitwriter_write_golomb_unsigned(int uval, int parameter)
	{
		int total_bits, msbs;
		int k;

		//FLAC__ASSERT(0 != bw);
		//FLAC__ASSERT(0 != bw->buffer);
		//FLAC__ASSERT(parameter > 0);

		k = Jformat.FLAC__bitmath_ilog2( parameter );
		if( parameter == 1 << k ) {
			int pattern;

			//FLAC__ASSERT(k <= 30);

			msbs = uval >>> k;
			total_bits = 1 + k + msbs;
			pattern = 1 << k; // the unary end bit
			pattern |= (uval & ((1 << k) - 1)); // the binary LSBs

			if( total_bits <= 32 ) {
				if( ! FLAC__bitwriter_write_raw_uint32( pattern, total_bits ) )
					return false;
			}
			else {
				// write the unary MSBs
				if( ! FLAC__bitwriter_write_zeroes( msbs ) )
					return false;
				// write the unary end bit and binary LSBs
				if( ! FLAC__bitwriter_write_raw_uint32( pattern, k + 1 ) )
					return false;
			}
		}
		else {
			int q, r, d;

			d = (1 << (k + 1)) - parameter;
			q = uval / parameter;
			r = uval - (q * parameter);
			// write the unary MSBs
			if( ! FLAC__bitwriter_write_zeroes( q ) )
				return false;
			// write the unary end bit
			if( ! FLAC__bitwriter_write_raw_uint32( 1, 1 ) )
				return false;
			/// write the binary LSBs
			if( r >= d ) {
				if( ! FLAC__bitwriter_write_raw_uint32( r + d, k + 1 ) )
					return false;
			}
			else {
				if( ! FLAC__bitwriter_write_raw_uint32( r, k ) )
					return false;
			}
		}
		return true;
	}
//#endif /* UNUSED */

	public final boolean FLAC__bitwriter_write_utf8_uint32(final int val)
	{
		boolean ok = true;

		//FLAC__ASSERT(0 != bw);
		//FLAC__ASSERT(0 != bw->buffer);

		//FLAC__ASSERT(!(val & 0x80000000)); /* this version only handles 31 bits */

		if( (val & 0xffffff80) == 0 ) {// if( val < 0x80 )
			return FLAC__bitwriter_write_raw_uint32( val, 8 );
		}
		else if( (val & 0xfffff800) == 0 ) {// if( val < 0x800 )
			ok &= FLAC__bitwriter_write_raw_uint32( 0xC0 | (val >>> 6), 8 );
			ok &= FLAC__bitwriter_write_raw_uint32( 0x80 | (val & 0x3F), 8 );
		}
		else if( (val & 0xffff0000) == 0 ) {// if( val < 0x10000 )
			ok &= FLAC__bitwriter_write_raw_uint32( 0xE0 | (val >>> 12), 8 );
			ok &= FLAC__bitwriter_write_raw_uint32( 0x80 | ((val >>> 6) & 0x3F), 8 );
			ok &= FLAC__bitwriter_write_raw_uint32( 0x80 | (val & 0x3F), 8 );
		}
		else if( (val & 0xffe00000) == 0 ) {// if( val < 0x200000 )
			ok &= FLAC__bitwriter_write_raw_uint32( 0xF0 | (val >>> 18), 8 );
			ok &= FLAC__bitwriter_write_raw_uint32( 0x80 | ((val >>> 12) & 0x3F), 8 );
			ok &= FLAC__bitwriter_write_raw_uint32( 0x80 | ((val >>> 6) & 0x3F), 8 );
			ok &= FLAC__bitwriter_write_raw_uint32( 0x80 | (val & 0x3F), 8 );
		}
		else if( (val & 0xfc000000) == 0 ) {// if( val < 0x4000000 )
			ok &= FLAC__bitwriter_write_raw_uint32( 0xF8 | (val >>> 24), 8 );
			ok &= FLAC__bitwriter_write_raw_uint32( 0x80 | ((val >>> 18) & 0x3F), 8 );
			ok &= FLAC__bitwriter_write_raw_uint32( 0x80 | ((val >>> 12) & 0x3F), 8 );
			ok &= FLAC__bitwriter_write_raw_uint32( 0x80 | ((val >>> 6) & 0x3F), 8 );
			ok &= FLAC__bitwriter_write_raw_uint32( 0x80 | (val & 0x3F), 8 );
		}
		else {
			ok &= FLAC__bitwriter_write_raw_uint32( 0xFC | (val >>> 30), 8 );
			ok &= FLAC__bitwriter_write_raw_uint32( 0x80 | ((val >>> 24) & 0x3F), 8 );
			ok &= FLAC__bitwriter_write_raw_uint32( 0x80 | ((val >>> 18) & 0x3F), 8 );
			ok &= FLAC__bitwriter_write_raw_uint32( 0x80 | ((val >>> 12) & 0x3F), 8 );
			ok &= FLAC__bitwriter_write_raw_uint32( 0x80 | ((val >>> 6) & 0x3F), 8 );
			ok &= FLAC__bitwriter_write_raw_uint32( 0x80 | (val & 0x3F), 8 );
		}

		return ok;
	}

	public final boolean FLAC__bitwriter_write_utf8_uint64(final long val)
	{
		boolean ok = true;

		//FLAC__ASSERT(0 != bw);
		//FLAC__ASSERT(0 != bw->buffer);

		//FLAC__ASSERT(!(val & FLAC__U64L(0xFFFFFFF000000000))); /* this version only handles 36 bits */

		final int ival = (int) val;
		if( (val & 0xffffffffffffff80L) == 0 ) {// if( val < 0x80 )
			return FLAC__bitwriter_write_raw_uint32( ival, 8);
		}
		else if( (val & 0xfffffffffffff800L) == 0 ) {// if( val < 0x800 )
			ok &= FLAC__bitwriter_write_raw_uint32( 0xC0 | (ival >>> 6), 8 );
			ok &= FLAC__bitwriter_write_raw_uint32( 0x80 | (ival & 0x3F), 8 );
		}
		else if( (val & 0xffffffffffff0000L) == 0 ) {// if( val < 0x10000 )
			ok &= FLAC__bitwriter_write_raw_uint32( 0xE0 | (ival >>> 12), 8 );
			ok &= FLAC__bitwriter_write_raw_uint32( 0x80 | ((ival >>> 6) & 0x3F), 8 );
			ok &= FLAC__bitwriter_write_raw_uint32( 0x80 | (ival & 0x3F), 8 );
		}
		else if( (val & 0xffffffffffe00000L) == 0 ) {// if( val < 0x200000 )
			ok &= FLAC__bitwriter_write_raw_uint32( 0xF0 | (ival >>> 18), 8 );
			ok &= FLAC__bitwriter_write_raw_uint32( 0x80 | ((ival >>> 12) & 0x3F), 8 );
			ok &= FLAC__bitwriter_write_raw_uint32( 0x80 | ((ival >>> 6) & 0x3F), 8 );
			ok &= FLAC__bitwriter_write_raw_uint32( 0x80 | (ival & 0x3F), 8 );
		}
		else if( (val & 0xfffffffffc000000L) == 0 ) {// if( val < 0x4000000 )
			ok &= FLAC__bitwriter_write_raw_uint32( 0xF8 | (ival >>> 24), 8 );
			ok &= FLAC__bitwriter_write_raw_uint32( 0x80 | ((ival >>> 18) & 0x3F), 8 );
			ok &= FLAC__bitwriter_write_raw_uint32( 0x80 | ((ival >>> 12) & 0x3F), 8 );
			ok &= FLAC__bitwriter_write_raw_uint32( 0x80 | ((ival >>> 6) & 0x3F), 8 );
			ok &= FLAC__bitwriter_write_raw_uint32( 0x80 | (ival & 0x3F), 8 );
		}
		else if( (val & 0xffffffff80000000L) == 0 ) {// if( val < 0x80000000 )
			ok &= FLAC__bitwriter_write_raw_uint32( 0xFC | (int)(val >>> 30), 8 );
			ok &= FLAC__bitwriter_write_raw_uint32( 0x80 | ((ival >>> 24) & 0x3F), 8 );
			ok &= FLAC__bitwriter_write_raw_uint32( 0x80 | ((ival >>> 18) & 0x3F), 8 );
			ok &= FLAC__bitwriter_write_raw_uint32( 0x80 | ((ival >>> 12) & 0x3F), 8 );
			ok &= FLAC__bitwriter_write_raw_uint32( 0x80 | ((ival >>> 6) & 0x3F), 8 );
			ok &= FLAC__bitwriter_write_raw_uint32( 0x80 | (ival & 0x3F), 8 );
		}
		else {
			ok &= FLAC__bitwriter_write_raw_uint32( 0xFE, 8 );
			ok &= FLAC__bitwriter_write_raw_uint32( 0x80 | (int)((val >>> 30) & 0x3F), 8 );
			ok &= FLAC__bitwriter_write_raw_uint32( 0x80 | ((ival >>> 24) & 0x3F), 8 );
			ok &= FLAC__bitwriter_write_raw_uint32( 0x80 | ((ival >>> 18) & 0x3F), 8 );
			ok &= FLAC__bitwriter_write_raw_uint32( 0x80 | ((ival >>> 12) & 0x3F), 8 );
			ok &= FLAC__bitwriter_write_raw_uint32( 0x80 | ((ival >>> 6) & 0x3F), 8 );
			ok &= FLAC__bitwriter_write_raw_uint32( 0x80 | (ival & 0x3F), 8 );
		}

		return ok;
	}

	final boolean FLAC__bitwriter_zero_pad_to_byte_boundary()
	{
		/* 0-pad to byte boundary */
		if( (this.bits & 7) != 0 ) {
			return FLAC__bitwriter_write_zeroes( 8 - (this.bits & 7) );
		}// else {
			return true;
		//}
	}

}
