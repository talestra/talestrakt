package libFLAC;

/** helper class to return byte buffer and byte count in the buffer */
final class Jbitwriter_helper {
	byte[] bytebuffer = null;
	int bytes = 0;
}
