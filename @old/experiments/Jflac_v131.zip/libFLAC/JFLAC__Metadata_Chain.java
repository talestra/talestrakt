package libFLAC;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

public final class JFLAC__Metadata_Chain extends Jmetadata_iterators implements
	JFLAC__StreamDecoderReadCallback,
	JFLAC__StreamDecoderWriteCallback,
	JFLAC__StreamDecoderMetadataCallback,
	JFLAC__StreamDecoderErrorCallback
{
	//typedef enum {
		/** The chain is in the normal OK state */
		private static final int FLAC__METADATA_CHAIN_STATUS_OK = 0;

		/** The data passed into a function violated the function's usage criteria */
		private static final int FLAC__METADATA_CHAIN_STATUS_ILLEGAL_INPUT = 1;

		/** The chain could not open the target file */
		private static final int FLAC__METADATA_CHAIN_STATUS_ERROR_OPENING_FILE = 2;

		/** The chain could not find the FLAC signature at the start of the file */
		private static final int FLAC__METADATA_CHAIN_STATUS_NOT_A_FLAC_FILE = 3;

		/** The chain tried to write to a file that was not writable */
		private static final int FLAC__METADATA_CHAIN_STATUS_NOT_WRITABLE = 4;

		/** The chain encountered input that does not conform to the FLAC metadata specification */
		private static final int FLAC__METADATA_CHAIN_STATUS_BAD_METADATA = 5;

		/** The chain encountered an error while reading the FLAC file */
		private static final int FLAC__METADATA_CHAIN_STATUS_READ_ERROR = 6;

		/** The chain encountered an error while seeking in the FLAC file */
		private static final int FLAC__METADATA_CHAIN_STATUS_SEEK_ERROR = 7;

		/** The chain encountered an error while writing the FLAC file */
		private static final int FLAC__METADATA_CHAIN_STATUS_WRITE_ERROR = 8;

		/** The chain encountered an error renaming the FLAC file */
		private static final int FLAC__METADATA_CHAIN_STATUS_RENAME_ERROR = 9;

		/** The chain encountered an error removing the temporary file */
		private static final int FLAC__METADATA_CHAIN_STATUS_UNLINK_ERROR = 10;

		/** Memory allocation failed */
		private static final int FLAC__METADATA_CHAIN_STATUS_MEMORY_ALLOCATION_ERROR = 11;

		/** The caller violated an assertion or an unexpected error occurred */
		private static final int FLAC__METADATA_CHAIN_STATUS_INTERNAL_ERROR = 12;

		/** One or more of the required callbacks was NULL */
		private static final int FLAC__METADATA_CHAIN_STATUS_INVALID_CALLBACKS = 13;

		/** FLAC__metadata_chain_write() was called on a chain read by
		 *   FLAC__metadata_chain_read_with_callbacks()/FLAC__metadata_chain_read_ogg_with_callbacks(),
		 *   or
		 *   FLAC__metadata_chain_write_with_callbacks()/FLAC__metadata_chain_write_with_callbacks_and_tempfile()
		 *   was called on a chain read by
		 *   FLAC__metadata_chain_read()/FLAC__metadata_chain_read_ogg().
		 *   Matching read/write methods must always be used. */
		private static final int FLAC__METADATA_CHAIN_STATUS_READ_WRITE_MISMATCH = 14;

		/** FLAC__metadata_chain_write_with_callbacks() was called when the
		 *   chain write requires a tempfile; use
		 *   FLAC__metadata_chain_write_with_callbacks_and_tempfile() instead.
		 *   Or, FLAC__metadata_chain_write_with_callbacks_and_tempfile() was
		 *   called when the chain write does not require a tempfile; use
		 *   FLAC__metadata_chain_write_with_callbacks() instead.
		 *   Always check FLAC__metadata_chain_check_if_tempfile_needed()
		 *   before writing via callbacks. */
		private static final int FLAC__METADATA_CHAIN_STATUS_WRONG_WRITE_CALL = 15;

	//} FLAC__Metadata_ChainStatus;

	private String filename = null; /* will be NULL if using callbacks */
	private boolean is_ogg = false;
	JFLAC__Metadata_Node head = null;
	JFLAC__Metadata_Node tail = null;
	int nodes = 0;
	private int /* FLAC__Metadata_ChainStatus */ status = FLAC__METADATA_CHAIN_STATUS_OK;
	private long first_offset = 0, last_offset = 0;
	/*
	 * This is the length of the chain initially read from the FLAC file.
	 * it is used to compare against the current length to decide whether
	 * or not the whole file has to be rewritten.
	 */
	private long initial_length = 0;
	/* @@@ hacky, these are currently only needed by ogg reader */
	//Object /* FLAC__IOHandle */ handle = null;
	//JFLAC__IOCallback_Read read_cb = null;
	private RandomAccessFile handle;// java: FLAC__IOHandle and FLAC__IOCallback_Read are changed to file.read

	private final void clear() {
		filename = null;
		is_ogg = false;
		head = null;
		tail = null;
		nodes = 0;
		status = FLAC__METADATA_CHAIN_STATUS_OK;
		first_offset = 0;
		last_offset = 0;
		initial_length = 0;
		handle = null;
	}

	public final void FLAC__metadata_chain_delete()
	{
		//FLAC__ASSERT(0 != chain);

		chain_clear_();

		//free(chain);
	}

	private final void chain_clear_()
	{
		JFLAC__Metadata_Node node, next;

		//FLAC__ASSERT(0 != chain);

		for( node = this.head; node != null; ) {
			next = node.next;
			node.node_delete_();
			node = next;
		}

		this.filename = null;

		this.clear();
	}

	private final void chain_append_node_(final JFLAC__Metadata_Node node)
	{
		//FLAC__ASSERT(0 != chain);
		//FLAC__ASSERT(0 != node);
		//FLAC__ASSERT(0 != node->data);

		node.next = node.prev = null;
		node.data.is_last = true;
		if( null != this.tail ) {
			this.tail.data.is_last = false;
		}

		if( null == this.head ) {
			this.head = node;
		} else {
			//FLAC__ASSERT(0 != chain.tail);
			this.tail.next = node;
			node.prev = this.tail;
		}
		this.tail = node;
		this.nodes++;
	}

	private final void chain_remove_node_(final JFLAC__Metadata_Node node)
	{
		//FLAC__ASSERT(0 != chain);
		//FLAC__ASSERT(0 != node);

		if( node == this.head ) {
			this.head = node.next;
		} else {
			node.prev.next = node.next;
		}

		if( node == this.tail ) {
			this.tail = node.prev;
		} else {
			node.next.prev = node.prev;
		}

		if( null != this.tail ) {
			this.tail.data.is_last = true;
		}

		this.nodes--;
	}

	final void chain_delete_node_(final JFLAC__Metadata_Node node)
	{
		chain_remove_node_( node );
		node.node_delete_();
	}

	private final long chain_calculate_length_()
	{
		JFLAC__Metadata_Node node;
		long length = 0;
		for( node = this.head; node != null; node = node.next ) {
			length += (Jformat.FLAC__STREAM_METADATA_HEADER_LENGTH + node.data.length);
		}
		return length;
	}

	/* return true iff node and node->next are both padding */
	private final boolean chain_merge_adjacent_padding_(final JFLAC__Metadata_Node node)
	{
		if( node.data.type == Jformat.FLAC__METADATA_TYPE_PADDING && null != node.next && node.next.data.type == Jformat.FLAC__METADATA_TYPE_PADDING ) {
			final int growth = Jformat.FLAC__STREAM_METADATA_HEADER_LENGTH + node.next.data.length;
			node.data.length += growth;

			chain_delete_node_( node.next );
			return true;
		} else {
			return false;
		}
	}

	/** Returns the new length of the chain, or 0 if there was an error. */
	/* WATCHOUT: This can get called multiple times before a write, so
	 * it should still work when this happens.
	 */
	/* WATCHOUT: Make sure to also update the logic in
	 * FLAC__metadata_chain_check_if_tempfile_needed() if the logic here changes.
	 */
	private final long chain_prepare_for_write_(final boolean use_padding)
	{
		long current_length = chain_calculate_length_();

		if( use_padding ) {
			/* if the metadata shrank and the last block is padding, we just extend the last padding block */
			if( current_length < this.initial_length && this.tail.data.type == Jformat.FLAC__METADATA_TYPE_PADDING ) {
				final long delta = this.initial_length - current_length;
				this.tail.data.length += delta;
				current_length += delta;
				//FLAC__ASSERT(current_length == chain->initial_length);
			}
			/* if the metadata shrank more than 4 bytes then there's room to add another padding block */
			else if( current_length + Jformat.FLAC__STREAM_METADATA_HEADER_LENGTH <= this.initial_length ) {
				JFLAC__StreamMetadata padding;
				JFLAC__Metadata_Node node;
				padding = JFLAC__StreamMetadata.FLAC__metadata_object_new( Jformat.FLAC__METADATA_TYPE_PADDING );
				padding.length = (int)(this.initial_length - (Jformat.FLAC__STREAM_METADATA_HEADER_LENGTH + current_length));
				node = new JFLAC__Metadata_Node();
				node.data = padding;
				chain_append_node_( node );
				current_length = chain_calculate_length_();
				//FLAC__ASSERT(current_length == chain->initial_length);
			}
			/* if the metadata grew but the last block is padding, try cutting the padding to restore the original length so we don't have to rewrite the whole file */
			else if( current_length > this.initial_length ) {
				final long delta = current_length - this.initial_length;
				if( this.tail.data.type == Jformat.FLAC__METADATA_TYPE_PADDING ) {
					/* if the delta is exactly the size of the last padding block, remove the padding block */
					if( (long)this.tail.data.length + (long)Jformat.FLAC__STREAM_METADATA_HEADER_LENGTH == delta ) {
						chain_delete_node_( this.tail );
						current_length = chain_calculate_length_();
						//FLAC__ASSERT(current_length == chain.initial_length);
					}
					/* if there is at least 'delta' bytes of padding, trim the padding down */
					else if( this.tail.data.length >= delta ) {
						this.tail.data.length -= delta;
						current_length -= delta;
						//FLAC__ASSERT(current_length == chain->initial_length);
					}
				}
			}
		}

		return current_length;
	}

	/****************************************************************************
	 *
	 * Local function definitions
	 *
	 ***************************************************************************/

	private final boolean chain_read_cb_(final RandomAccessFile iohandle)// java: changed
			//JFLAC__IOHandle handle, JFLAC__IOCallback_Read read_cb, JFLAC__IOCallback_Seek seek_cb, JFLAC__IOCallback_Tell tell_cb)
	{
		//FLAC__ASSERT(0 != chain);

		/* we assume we're already at the beginning of the file */

		switch( seek_to_first_metadata_block_cb_( iohandle /*handle, read_cb, seek_cb*/ ) ) {
			case 0:
				break;
			case 1:
				this.status = FLAC__METADATA_CHAIN_STATUS_READ_ERROR;
				return false;
			case 2:
				this.status = FLAC__METADATA_CHAIN_STATUS_SEEK_ERROR;
				return false;
			case 3:
				this.status = FLAC__METADATA_CHAIN_STATUS_NOT_A_FLAC_FILE;
				return false;
			default:
				//FLAC__ASSERT(0);
				return false;
		}

		{
			try {
				final long pos = iohandle.getFilePointer();
				this.first_offset = pos;
			} catch(final IOException e) {
				this.status = FLAC__METADATA_CHAIN_STATUS_READ_ERROR;
				return false;
			}
		}

		{
			Jmetadata_block_header_helper h;
			do {
				final JFLAC__Metadata_Node node = new JFLAC__Metadata_Node();

				if( null == (h = read_metadata_block_header_cb_( iohandle/*, handle, read_cb, is_last, type, length */)) ) {
					node.node_delete_();
					this.status = FLAC__METADATA_CHAIN_STATUS_READ_ERROR;
					return false;
				}

				node.data = JFLAC__StreamMetadata.FLAC__metadata_object_new( h.type );
				if( null == node.data ) {
					node.node_delete_();
					this.status = FLAC__METADATA_CHAIN_STATUS_MEMORY_ALLOCATION_ERROR;
					return false;
				}

				node.data.is_last = h.is_last;
				node.data.length = h.length;

				this.status = get_equivalent_status_( read_metadata_block_data_cb_( iohandle, /*handle, read_cb, seek_cb,*/ node.data ) );
				if( this.status != FLAC__METADATA_CHAIN_STATUS_OK ) {
					node.node_delete_();
					return false;
				}
				chain_append_node_( node );
			} while( ! h.is_last );
		}

		{
			try {
				final long pos = iohandle.getFilePointer();
				this.last_offset = pos;
			} catch(final IOException e) {
				this.status = FLAC__METADATA_CHAIN_STATUS_READ_ERROR;
				return false;
			}
		}

		this.initial_length = chain_calculate_length_();

		return true;
	}

	private final boolean chain_read_ogg_cb_(final RandomAccessFile iohandle)// java: changed
			//JFLAC__IOHandle handle, JFLAC__IOCallback_Read read_cb)
	{
		//FLAC__ASSERT(0 != chain);

		/* we assume we're already at the beginning of the file */

		//chain.handle = handle;
		//chain.read_cb = read_cb;
		this.handle = iohandle;
		final JFLAC__StreamDecoder decoder = new JFLAC__StreamDecoder();
		decoder.FLAC__stream_decoder_set_metadata_respond_all();
		if( decoder.FLAC__stream_decoder_init_ogg_stream(
				this,// chain_read_ogg_read_cb_,
				/*seek_callback=*/null,
				/*tell_callback=*/null,
				/*length_callback=*/null,
				/*eof_callback=*/null,
				this,// chain_read_ogg_write_cb_,
				this,// chain_read_ogg_metadata_cb_,
				this//,// chain_read_ogg_error_cb_,
				/* this */ ) != JFLAC__StreamDecoder.FLAC__STREAM_DECODER_INIT_STATUS_OK ) {
			decoder.FLAC__stream_decoder_delete();
			this.status = FLAC__METADATA_CHAIN_STATUS_INTERNAL_ERROR; /*@@@ maybe needs better error code */
			return false;
		}

		this.first_offset = 0; /*@@@ wrong; will need to be set correctly to implement metadata writing for Ogg FLAC */

		if( ! decoder.FLAC__stream_decoder_process_until_end_of_metadata() ) {
			this.status = FLAC__METADATA_CHAIN_STATUS_INTERNAL_ERROR; /*@@@ maybe needs better error code */
		}
		if( this.status != FLAC__METADATA_CHAIN_STATUS_OK ) {
			decoder.FLAC__stream_decoder_delete();
			return false;
		}

		decoder.FLAC__stream_decoder_delete();

		this.last_offset = 0; /*@@@ wrong; will need to be set correctly to implement metadata writing for Ogg FLAC */

		this.initial_length = chain_calculate_length_();

		return true;
	}

	private final boolean chain_rewrite_metadata_in_place_cb_(final RandomAccessFile iohandle)// java: changed
			//FLAC__IOHandle handle, FLAC__IOCallback_Write write_cb, FLAC__IOCallback_Seek seek_cb)
	{
		//FLAC__ASSERT(0 != chain);
		//FLAC__ASSERT(0 != chain->head);

		try {
			iohandle.seek( this.first_offset/*, SEEK_SET*/ );
		} catch(final IOException e) {
			this.status = FLAC__METADATA_CHAIN_STATUS_SEEK_ERROR;
			return false;
		}

		for( JFLAC__Metadata_Node node = this.head; node != null; node = node.next ) {
			if( ! write_metadata_block_header_cb_( iohandle/*, write_cb*/, node.data ) ) {
				this.status = FLAC__METADATA_CHAIN_STATUS_WRITE_ERROR;
				return false;
			}
			if( ! write_metadata_block_data_cb_( iohandle/*, write_cb*/, node.data ) ) {
				this.status = FLAC__METADATA_CHAIN_STATUS_WRITE_ERROR;
				return false;
			}
		}

		/*FLAC__ASSERT(fflush(), ftello() == chain->last_offset);*/

		this.status = FLAC__METADATA_CHAIN_STATUS_OK;
		return true;
	}

	private final boolean chain_rewrite_metadata_in_place_()
	{
		RandomAccessFile file = null;
		boolean ret;

		//FLAC__ASSERT(0 != chain->filename);

		try {
			file = new RandomAccessFile( this.filename, "rw" );

			/* chain_rewrite_metadata_in_place_cb_() sets chain->status for us */
			ret = chain_rewrite_metadata_in_place_cb_( file/*, (FLAC__IOCallback_Write)fwrite, fseek_wrapper_*/ );

		} catch(final FileNotFoundException e) {
			this.status = FLAC__METADATA_CHAIN_STATUS_ERROR_OPENING_FILE;
			return false;
		} finally {
			if( file != null ) {
				try { file.close(); } catch( final IOException e ) {}
			}
		}

		return ret;
	}

	private final boolean chain_rewrite_file_(final String tempfile_path_prefix)
	{
		RandomAccessFile f = null, tempfile = null;
		int /* FLAC__Metadata_SimpleIteratorStatus */ ret;

		//FLAC__ASSERT(0 != chain);
		//FLAC__ASSERT(0 != chain->filename);
		//FLAC__ASSERT(0 != chain->head);
		// java: changed
		/*if(!open_tempfile_(chain->filename, tempfile_path_prefix, &tempfile, &tempfilename, &status)) {
			chain->status = get_equivalent_status_(status);
			cleanup_tempfile_(&tempfile, &tempfilename);
			return false;
		}*/
		final String tempfilename = get_tempfile_name_( this.filename, tempfile_path_prefix );
		try {
			tempfile = new RandomAccessFile( tempfilename, "rw" );
		} catch(final FileNotFoundException e) {
			this.status = get_equivalent_status_( FLAC__METADATA_SIMPLE_ITERATOR_STATUS_ERROR_OPENING_FILE );
			cleanup_tempfile_( tempfile, tempfilename );
			return false;
		}
		try {
			/* copy the file prefix (data up to first metadata block */
			f = new RandomAccessFile( this.filename, "r" );
			if( FLAC__METADATA_SIMPLE_ITERATOR_STATUS_OK != (ret = copy_n_bytes_from_file_( f, tempfile, this.first_offset )) ) {
				this.status = get_equivalent_status_( ret );
				cleanup_tempfile_( tempfile, tempfilename );
				return false;
			}

			/* write the metadata */
			for( JFLAC__Metadata_Node node = this.head; node != null; node = node.next ) {
				if( FLAC__METADATA_SIMPLE_ITERATOR_STATUS_OK != (ret = write_metadata_block_header_( tempfile, node.data )) ) {
					this.status = get_equivalent_status_( ret );
					cleanup_tempfile_( tempfile, tempfilename );
					return false;
				}
				if( FLAC__METADATA_SIMPLE_ITERATOR_STATUS_OK != (ret = write_metadata_block_data_( tempfile, node.data )) ) {
					this.status = get_equivalent_status_( ret );
					cleanup_tempfile_( tempfile, tempfilename );
					return false;
				}
			}
			/*FLAC__ASSERT(fflush(), ftello() == chain->last_offset);*/

			/* copy the file postfix (everything after the metadata) */
			f.seek( this.last_offset );

			if( FLAC__METADATA_SIMPLE_ITERATOR_STATUS_OK != (ret = copy_remaining_bytes_from_file_( f, tempfile )) ) {
				cleanup_tempfile_( tempfile, tempfilename );
				this.status = get_equivalent_status_( ret );
				return false;
			}

			/* move the tempfile on top of the original */
			if( FLAC__METADATA_SIMPLE_ITERATOR_STATUS_OK != (ret = transport_tempfile_( this.filename, tempfile, tempfilename )) ) {
				return false;
			}
		} catch(final FileNotFoundException e) {
			this.status = FLAC__METADATA_CHAIN_STATUS_ERROR_OPENING_FILE;
			return false;
		} catch(final IOException e) {
			cleanup_tempfile_( tempfile, tempfilename );
			this.status = FLAC__METADATA_CHAIN_STATUS_SEEK_ERROR;
			return false;
		} finally {
			if( f != null ) {
				try { f.close(); } catch( final IOException e ) {}
			}
		}
		return true;
	}

	/** @return FLAC__Metadata_SimpleIteratorStatus */
	private static int copy_n_bytes_from_file_cb_(
			final RandomAccessFile handle,// java: changed
			//FLAC__IOCallback_Read read_cb,
			final RandomAccessFile temp_handle,// java: changed
			//FLAC__IOCallback_Write temp_write_cb,
			long bytes)//, FLAC__Metadata_SimpleIteratorStatus *status)
	{
		final byte buffer[] = new byte[8192];

		//FLAC__ASSERT(bytes >= 0);
		while( bytes > 0 ) {
			final int n = Math.min( buffer.length, (int)bytes );
			try {
				if( handle.read( buffer, 0, n ) != n ) {
					return /* *status = */ FLAC__METADATA_SIMPLE_ITERATOR_STATUS_READ_ERROR;
					//return false;
				}
			} catch(final IOException e) {
				return /* *status = */ FLAC__METADATA_SIMPLE_ITERATOR_STATUS_READ_ERROR;
				//return false;
			}
			try {
				temp_handle.write( buffer, 0, n );
			} catch(final IOException e) {
				return /* *status = */ FLAC__METADATA_SIMPLE_ITERATOR_STATUS_WRITE_ERROR;
				//return false;
			}
			bytes -= n;
		}

		return FLAC__METADATA_SIMPLE_ITERATOR_STATUS_OK;
	}

	/** @return FLAC__Metadata_SimpleIteratorStatus */
	private static int /* FLAC__Metadata_SimpleIteratorStatus */ copy_remaining_bytes_from_file_cb_(
			final RandomAccessFile handle,// java: changed
			//FLAC__IOCallback_Read read_cb, FLAC__IOCallback_Eof eof_cb,
			final RandomAccessFile temp_handle)
			//FLAC__IOCallback_Write temp_write_cb,
			//FLAC__Metadata_SimpleIteratorStatus *status)
	{
		final byte buffer[] = new byte[8192];
		int n;

		while( true ) {
			try {
				n = handle.read( buffer, 0, buffer.length );
				if( n < 0 ) {
					break;
				}
			} catch(final IOException e) {
				return /* *status = */ FLAC__METADATA_SIMPLE_ITERATOR_STATUS_READ_ERROR;
				//return false;
			}
			try {
				if( n > 0 ) {
					temp_handle.write( buffer, 0, n );
				}
			} catch(final IOException e) {
				return /* *status = */ FLAC__METADATA_SIMPLE_ITERATOR_STATUS_WRITE_ERROR;
				//return false;
			}
		}

		return FLAC__METADATA_SIMPLE_ITERATOR_STATUS_OK;// true;
	}

	/** assumes 'handle' is already at beginning of file */
	private final boolean chain_rewrite_file_cb_(// FLAC__IOHandle handle,
			final RandomAccessFile iohandle,// java: changed
			//FLAC__IOCallback_Read read_cb, FLAC__IOCallback_Seek seek_cb, FLAC__IOCallback_Eof eof_cb,
			final RandomAccessFile temp_handle)// java: changed
			//FLAC__IOCallback_Write temp_write_cb)
	{
		int /* FLAC__Metadata_SimpleIteratorStatus */ ret;

		//FLAC__ASSERT(0 != chain);
		//FLAC__ASSERT(0 == chain->filename);
		//FLAC__ASSERT(0 != chain->head);

		/* copy the file prefix (data up to first metadata block */
		if( FLAC__METADATA_SIMPLE_ITERATOR_STATUS_OK != (ret = copy_n_bytes_from_file_cb_( iohandle,/* read_cb,*/ temp_handle,/* temp_write_cb,*/ this.first_offset )) ) {
			this.status = get_equivalent_status_( ret );
			return false;
		}

		/* write the metadata */
		for( JFLAC__Metadata_Node node = this.head; node != null; node = node.next ) {
			if( ! write_metadata_block_header_cb_( temp_handle/*, temp_write_cb*/, node.data ) ) {
				this.status = FLAC__METADATA_CHAIN_STATUS_WRITE_ERROR;
				return false;
			}
			if( ! write_metadata_block_data_cb_( temp_handle/*, temp_write_cb*/, node.data ) ) {
				this.status = FLAC__METADATA_CHAIN_STATUS_WRITE_ERROR;
				return false;
			}
		}
		/*FLAC__ASSERT(fflush(), ftello() == chain->last_offset);*/

		/* copy the file postfix (everything after the metadata) */
		try {
			iohandle.seek( this.last_offset );
		} catch(final IOException e) {
			this.status = FLAC__METADATA_CHAIN_STATUS_SEEK_ERROR;
			return false;
		}
		if( FLAC__METADATA_SIMPLE_ITERATOR_STATUS_OK != (ret = copy_remaining_bytes_from_file_cb_( iohandle/*, read_cb, eof_cb*/, temp_handle/*, temp_write_cb*/ )) ) {
			this.status = get_equivalent_status_( ret );
			return false;
		}

		return true;
	}

	public final int /* FLAC__Metadata_ChainStatus */ FLAC__metadata_chain_status()
	{
		//FLAC__ASSERT(0 != chain);

		final int /* FLAC__Metadata_ChainStatus */ s = this.status;
		this.status = FLAC__METADATA_CHAIN_STATUS_OK;
		return s;
	}

	private final boolean chain_read_(final String file_name, final boolean isogg)
	{
		RandomAccessFile file = null;
		boolean ret;

		//FLAC__ASSERT(0 != chain);
		//FLAC__ASSERT(0 != filename);

		chain_clear_();

		this.filename = file_name;

		this.is_ogg = isogg;

		try {
			file = new RandomAccessFile( file_name, "r" );

			/* the function also sets chain->status for us */
			ret = isogg ?
				chain_read_ogg_cb_( file/*, (FLAC__IOCallback_Read)fread*/ ) :
				chain_read_cb_( file/*, (FLAC__IOCallback_Read)fread, fseek_wrapper_, ftell_wrapper_*/ );
		} catch(final FileNotFoundException e) {
			this.status = FLAC__METADATA_CHAIN_STATUS_ERROR_OPENING_FILE;
			return false;
		} finally {
			if( file != null ) {
				try { file.close(); } catch( final IOException e ) {}
			}
		}
		return ret;
	}

	public final boolean FLAC__metadata_chain_read(final String file_name)
	{
		return chain_read_( file_name, /*is_ogg=*/false );
	}

	/*@@@@add to tests*/
	public final boolean FLAC__metadata_chain_read_ogg(final String file_name)
	{
		return chain_read_( file_name, /*is_ogg=*/true );
	}

	private final boolean chain_read_with_callbacks_(
			final RandomAccessFile iohandle,// java: changed
			//FLAC__IOCallbacks callbacks,
			final boolean isogg)
	{
		//FLAC__ASSERT(0 != chain);

		chain_clear_();

		// if( null == callbacks.read || null == callbacks.seek || null == callbacks.tell ) {
		if( null == iohandle ) {// java: just simulating, to use that status
			this.status = FLAC__METADATA_CHAIN_STATUS_INVALID_CALLBACKS;
			return false;
		}

		this.is_ogg = isogg;

		/* rewind */
		try {
			iohandle.seek( 0 );
		} catch(final IOException e) {
			this.status = FLAC__METADATA_CHAIN_STATUS_SEEK_ERROR;
			return false;
		}

		/* the function also sets chain->status for us */
		final boolean ret = isogg ?
			chain_read_ogg_cb_( iohandle/*, callbacks.read*/ ) :
			chain_read_cb_( iohandle/*, callbacks.read, callbacks.seek, callbacks.tell*/ );

		return ret;
	}

	public final boolean FLAC__metadata_chain_read_with_callbacks(
			final RandomAccessFile iohandle)// java: changed
			//FLAC__IOCallbacks callbacks)
	{
		return chain_read_with_callbacks_( iohandle/*, callbacks*/, /*is_ogg=*/false );
	}

	/*@@@@add to tests*/
	public final boolean FLAC__metadata_chain_read_ogg_with_callbacks(
			final RandomAccessFile iohandle)// java: changed
			//FLAC__IOCallbacks callbacks)
	{
		return chain_read_with_callbacks_( iohandle/*, callbacks*/, /*is_ogg=*/true );
	}

	public final boolean FLAC__metadata_chain_check_if_tempfile_needed(final boolean use_padding)
	{
		/* This does all the same checks that are in chain_prepare_for_write_()
		 * but doesn't actually alter the chain.  Make sure to update the logic
		 * here if chain_prepare_for_write_() changes.
		 */
		final long current_length = chain_calculate_length_();

		//FLAC__ASSERT(0 != chain);

		if( use_padding ) {
			/* if the metadata shrank and the last block is padding, we just extend the last padding block */
			if( current_length < this.initial_length && this.tail.data.type == Jformat.FLAC__METADATA_TYPE_PADDING ) {
				return false;
			} else if( current_length + Jformat.FLAC__STREAM_METADATA_HEADER_LENGTH <= this.initial_length ) {
				return false;
			} else if( current_length > this.initial_length ) {
				final long delta = current_length - this.initial_length;
				if( this.tail.data.type == Jformat.FLAC__METADATA_TYPE_PADDING ) {
					/* if the delta is exactly the size of the last padding block, remove the padding block */
					if( (long)this.tail.data.length + (long)Jformat.FLAC__STREAM_METADATA_HEADER_LENGTH == delta ) {
						return false;
					} else if( this.tail.data.length >= delta ) {
						return false;
					}
				}
			}
		}

		return (current_length != this.initial_length);
	}

	public final boolean FLAC__metadata_chain_write( final boolean use_padding, final boolean preserve_file_stats)
	{
		File stats = null;
		final String tempfile_path_prefix = null;

		//FLAC__ASSERT(0 != chain);

		if( this.is_ogg ) { /* cannot write back to Ogg FLAC yet */
			this.status = FLAC__METADATA_CHAIN_STATUS_INTERNAL_ERROR;
			return false;
		}

		if( null == this.filename ) {
			this.status = FLAC__METADATA_CHAIN_STATUS_READ_WRITE_MISMATCH;
			return false;
		}

		final long current_length = chain_prepare_for_write_( use_padding );

		/* a return value of 0 means there was an error; chain->status is already set */
		if( 0 == current_length ) {
			return false;
		}

		if( preserve_file_stats ) {
			stats = get_file_stats_( this.filename );
		}

		if( current_length == this.initial_length ) {
			if( ! chain_rewrite_metadata_in_place_() ) {
				return false;
			}
		}
		else {
			if( ! chain_rewrite_file_( tempfile_path_prefix ) ) {
				return false;
			}

			/* recompute lengths and offsets */
			{
				this.initial_length = current_length;
				this.last_offset = this.first_offset;
				for( JFLAC__Metadata_Node node = this.head; node != null; node = node.next ) {
					this.last_offset += (Jformat.FLAC__STREAM_METADATA_HEADER_LENGTH + node.data.length);
				}
			}
		}

		if( preserve_file_stats ) {
			set_file_stats_( this.filename, stats );
		}

		return true;
	}

	public final boolean FLAC__metadata_chain_write_with_callbacks(final boolean use_padding,
			final RandomAccessFile iohandle)// java: changed
			//FLAC__IOCallbacks callbacks)
	{
		//FLAC__ASSERT(0 != chain);

		if( this.is_ogg) { /* cannot write back to Ogg FLAC yet */
			this.status = FLAC__METADATA_CHAIN_STATUS_INTERNAL_ERROR;
			return false;
		}

		if( null != this.filename ) {
			this.status = FLAC__METADATA_CHAIN_STATUS_READ_WRITE_MISMATCH;
			return false;
		}

		/*if( null == callbacks.write || null == callbacks.seek ) {
			chain.status = FLAC__METADATA_CHAIN_STATUS_INVALID_CALLBACKS;
			return false;
		}*/

		if( FLAC__metadata_chain_check_if_tempfile_needed( use_padding ) ) {
			this.status = FLAC__METADATA_CHAIN_STATUS_WRONG_WRITE_CALL;
			return false;
		}

		final long current_length = chain_prepare_for_write_( use_padding );

		/* a return value of 0 means there was an error; chain->status is already set */
		if( 0 == current_length ) {
			return false;
		}

		//FLAC__ASSERT(current_length == chain->initial_length);

		return chain_rewrite_metadata_in_place_cb_( iohandle/*, callbacks.write, callbacks.seek*/ );
	}

	public final boolean FLAC__metadata_chain_write_with_callbacks_and_tempfile(final boolean use_padding,
			final RandomAccessFile iohandle,// java: changed
			//FLAC__IOCallbacks callbacks,
			final RandomAccessFile temp_handle)//,
			//FLAC__IOCallbacks temp_callbacks)
	{
		//FLAC__ASSERT(0 != chain);

		if( this.is_ogg ) { /* cannot write back to Ogg FLAC yet */
			this.status = FLAC__METADATA_CHAIN_STATUS_INTERNAL_ERROR;
			return false;
		}

		if( null != this.filename ) {
			this.status = FLAC__METADATA_CHAIN_STATUS_READ_WRITE_MISMATCH;
			return false;
		}

		/*if( null == callbacks.read || null == callbacks.seek || null == callbacks.eof ) {
			chain.status = FLAC__METADATA_CHAIN_STATUS_INVALID_CALLBACKS;
			return false;
		}
		if( null == temp_callbacks.write ) {
			chain.status = FLAC__METADATA_CHAIN_STATUS_INVALID_CALLBACKS;
			return false;
		}*/

		if( ! FLAC__metadata_chain_check_if_tempfile_needed( use_padding ) ) {
			this.status = FLAC__METADATA_CHAIN_STATUS_WRONG_WRITE_CALL;
			return false;
		}

		final long current_length = chain_prepare_for_write_( use_padding );

		/* a return value of 0 means there was an error; chain->status is already set */
		if( 0 == current_length ) {
			return false;
		}

		//FLAC__ASSERT(current_length != chain->initial_length);

		/* rewind */
		try {
			iohandle.seek( 0 );
		} catch(final IOException e) {
			this.status = FLAC__METADATA_CHAIN_STATUS_SEEK_ERROR;
			return false;
		}

		if( ! chain_rewrite_file_cb_( iohandle/*, callbacks.read, callbacks.seek, callbacks.eof*/, temp_handle/*, temp_callbacks.write*/ ) ) {
			return false;
		}

		/* recompute lengths and offsets */
		{
			this.initial_length = current_length;
			this.last_offset = this.first_offset;
			for( JFLAC__Metadata_Node node = this.head; node != null; node = node.next ) {
				this.last_offset += (Jformat.FLAC__STREAM_METADATA_HEADER_LENGTH + node.data.length);
			}
		}

		return true;
	}

	public final void FLAC__metadata_chain_merge_padding()
	{
		//FLAC__ASSERT(0 != chain);

		for( JFLAC__Metadata_Node node = this.head; node != null; ) {
			if( ! chain_merge_adjacent_padding_( node ) ) {
				node = node.next;
			}
		}
	}

	public final void FLAC__metadata_chain_sort_padding()
	{
		JFLAC__Metadata_Node node, save;
		int i;

		//FLAC__ASSERT(0 != chain);

		/*
		 * Don't try and be too smart... this simple algo is good enough for
		 * the small number of nodes that we deal with.
		 */
		for( i = 0, node = this.head; i < this.nodes; i++ ) {
			if( node.data.type == Jformat.FLAC__METADATA_TYPE_PADDING ) {
				save = node.next;
				chain_remove_node_( node );
				chain_append_node_( node );
				node = save;
			}
			else {
				node = node.next;
			}
		}

		FLAC__metadata_chain_merge_padding();
	}

	@Override// JFLAC__StreamDecoderReadCallback, chain_read_ogg_read_cb_
	public int dec_read_callback(final JFLAC__StreamDecoder decoder, final byte buffer[], final int offset, final int bytes/*, final Object client_data*/) throws IOException {

		// final JFLAC__Metadata_Chain chain = (JFLAC__Metadata_Chain)client_data;// java: this

		if( bytes > 0 && this.status == FLAC__METADATA_CHAIN_STATUS_OK ) {
			return this.handle.read( buffer, 0, bytes );
		}
		throw new IOException();
	}

	@Override// JFLAC__StreamDecoderWriteCallback, chain_read_ogg_write_cb_
	public int dec_write_callback(final JFLAC__StreamDecoder decoder, final JFLAC__Frame frame, final int buffer[][], final int offset/*, final Object client_data*/)
	{
		//(void)decoder, (void)frame, (void)buffer, (void)client_data;
		return JFLAC__StreamDecoder.FLAC__STREAM_DECODER_WRITE_STATUS_ABORT;
	}

	@Override// JFLAC__StreamDecoderMetadataCallback, chain_read_ogg_metadata_cb_
	public void dec_metadata_callback(final JFLAC__StreamDecoder decoder, final JFLAC__StreamMetadata metadata/*, final Object client_data*/) throws IOException {

		// final JFLAC__Metadata_Chain chain = (JFLAC__Metadata_Chain)client_data;// java: this

		//(void)decoder;

		try {
			final JFLAC__Metadata_Node node = new JFLAC__Metadata_Node();

			node.data = JFLAC__StreamMetadata.FLAC__metadata_object_clone( metadata );
			if( null == node.data ) {
				node.node_delete_();
				this.status = FLAC__METADATA_CHAIN_STATUS_MEMORY_ALLOCATION_ERROR;
				return;
			}

			this.chain_append_node_( node );
		} catch(final OutOfMemoryError e) {
			this.status = FLAC__METADATA_CHAIN_STATUS_MEMORY_ALLOCATION_ERROR;
			return;
		}
	}

	@Override// JFLAC__StreamDecoderErrorCallback, chain_read_ogg_error_cb_
	public void dec_error_callback(final JFLAC__StreamDecoder decoder, final int it_status/*, final Object client_data*/) {
		// final JFLAC__Metadata_Chain chain = (JFLAC__Metadata_Chain)client_data;// java: this
		//(void)decoder, (void)status;
		this.status = FLAC__METADATA_CHAIN_STATUS_INTERNAL_ERROR; /*@@@ maybe needs better error code */
	}

	private static int /* FLAC__Metadata_ChainStatus */ get_equivalent_status_(final int /* FLAC__Metadata_SimpleIteratorStatus */ status)
	{
		switch( status ) {
			case FLAC__METADATA_SIMPLE_ITERATOR_STATUS_OK:
				return FLAC__METADATA_CHAIN_STATUS_OK;
			case FLAC__METADATA_SIMPLE_ITERATOR_STATUS_ILLEGAL_INPUT:
				return FLAC__METADATA_CHAIN_STATUS_ILLEGAL_INPUT;
			case FLAC__METADATA_SIMPLE_ITERATOR_STATUS_ERROR_OPENING_FILE:
				return FLAC__METADATA_CHAIN_STATUS_ERROR_OPENING_FILE;
			case FLAC__METADATA_SIMPLE_ITERATOR_STATUS_NOT_A_FLAC_FILE:
				return FLAC__METADATA_CHAIN_STATUS_NOT_A_FLAC_FILE;
			case FLAC__METADATA_SIMPLE_ITERATOR_STATUS_NOT_WRITABLE:
				return FLAC__METADATA_CHAIN_STATUS_NOT_WRITABLE;
			case FLAC__METADATA_SIMPLE_ITERATOR_STATUS_BAD_METADATA:
				return FLAC__METADATA_CHAIN_STATUS_BAD_METADATA;
			case FLAC__METADATA_SIMPLE_ITERATOR_STATUS_READ_ERROR:
				return FLAC__METADATA_CHAIN_STATUS_READ_ERROR;
			case FLAC__METADATA_SIMPLE_ITERATOR_STATUS_SEEK_ERROR:
				return FLAC__METADATA_CHAIN_STATUS_SEEK_ERROR;
			case FLAC__METADATA_SIMPLE_ITERATOR_STATUS_WRITE_ERROR:
				return FLAC__METADATA_CHAIN_STATUS_WRITE_ERROR;
			case FLAC__METADATA_SIMPLE_ITERATOR_STATUS_RENAME_ERROR:
				return FLAC__METADATA_CHAIN_STATUS_RENAME_ERROR;
			case FLAC__METADATA_SIMPLE_ITERATOR_STATUS_UNLINK_ERROR:
				return FLAC__METADATA_CHAIN_STATUS_UNLINK_ERROR;
			case FLAC__METADATA_SIMPLE_ITERATOR_STATUS_MEMORY_ALLOCATION_ERROR:
				return FLAC__METADATA_CHAIN_STATUS_MEMORY_ALLOCATION_ERROR;
			case FLAC__METADATA_SIMPLE_ITERATOR_STATUS_INTERNAL_ERROR:
			default:
				return FLAC__METADATA_CHAIN_STATUS_INTERNAL_ERROR;
		}
	}
}
