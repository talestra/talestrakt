package libFLAC;

final class Jerror_stats {
	long absolute_sample;
	int frame_number;
	int channel;
	int sample;
	int expected;
	int got;
}
