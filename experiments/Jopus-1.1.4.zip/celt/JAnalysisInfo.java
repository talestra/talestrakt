package celt;

// celt.h

public final class JAnalysisInfo {
	public boolean valid;
	public float tonality;
	public float tonality_slope;
	public float noisiness;
	public float activity;
	public float music_prob;
	public int bandwidth;
	//
	public final void clear() {
		valid = false;
		tonality = 0;
		tonality_slope = 0;
		noisiness = 0;
		activity = 0;
		music_prob = 0;
		bandwidth = 0;
	}
	public final void copyFrom(final JAnalysisInfo info) {
		valid = info.valid;
		tonality = info.tonality;
		tonality_slope = info.tonality_slope;
		noisiness = info.noisiness;
		activity = info.activity;
		music_prob = info.music_prob;
		bandwidth = info.bandwidth;
	}
}
