package celt;

/**
 * Auxilary structure to exchange data on java
 */
final class Jallocation_aux {
	int mIntensity;
	boolean mDualStereo;
	int mBalance;
	//
	Jallocation_aux(final int intensity, final boolean dual_stereo/*, int balance*/) {
		mIntensity = intensity;
		mDualStereo = dual_stereo;
		//mBalance = balance;
	}
}
