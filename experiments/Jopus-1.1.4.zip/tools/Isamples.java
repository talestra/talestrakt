package tools;

/**
 * java replacement for pointer to original_samples for padder
 */
interface Isamples {
	void addSamples(int samples);
}
