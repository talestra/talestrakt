package tools;

import java.io.IOException;

final class Jpadder implements Jaudio_read_func {
	private Jaudio_read_func real_reader;
	// private Object real_readdata;
	private Isamples original_samples;
	private int channels;
	private int lpc_ptr;
	private int extra_samples;
	private float[] lpc_out;
	//
	private Jpadder() {
	}
	// start lpc.c
	/* Autocorrelation LPC coeff generation algorithm invented by
	   N. Levinson in 1947, modified by J. Durbin in 1959. */

	/** Input : n elements of time doamin data
	   Output: m lpc coefficients, excitation energy */
	private static final float vorbis_lpc_from_data(final float[] data, final int doffset,// java
			final float[] lpci, int n, final int m, final int stride) {
		final double[] aut = new double[ m + 1 ];
		final double[] lpc = new double[ m ];

		/* autocorrelation, p+1 lag coefficients */
		n *= stride;// java
		n += doffset;// java
		int j = m + 1;
		int js = j * stride;// java
		while( j != 0 ) {
			j--;
			js -= stride;
			double d = 0; /* double needed for accumulator depth */
			for( int i = doffset + js; i < n; i += stride ) {
				d += (double)data[ i ] * data[ i - js ];
			}
			aut[j] = d;
		}

		/* Generate lpc coefficients from autocorr values */

		/* set our noise floor to about -100dB */
		double error = aut[0] * (1. + 1e-10);
		final double epsilon = 1e-9 * aut[0] + 1e-10;

		for( int i = 0; i < m; i++ ) {
			double r = -aut[i + 1];

			if( error < epsilon ) {
				// memset( lpc + i, 0, (m - i) * sizeof( *lpc ) );
				for( j = i; j < m; j++ ) {
					lpc[ j ] = 0;
				}
				break;// goto done;// FIXME why need goto?
			}

			/* Sum up this iteration's reflection coefficient; note that in
			Vorbis we don't save it.  If anyone wants to recycle this code
			and needs reflection coefficients, save the results of 'r' from
			each iteration. */

			for( j = 0; j < i; j++ ) {
				r -= lpc[ j ] * aut[ i - j ];
			}
			r /= error;

			/* Update LPC coefficients and total error */

			lpc[i] = r;
			j = 0;
			int jm = i - 1;// java
			for( final int je = i >> 1; j < je; j++, jm-- ) {
				final double tmp = lpc[j];

				lpc[j] += r * lpc[ jm ];
				lpc[ jm ] += r * tmp;
			}
			if( (i & 1) != 0 ) {
				lpc[ j ] += lpc[ j ] * r;
			}

			error *= 1. - r * r;

		}
	// done:
		/* slightly damp the filter */
		{
			final double g = .99;
			double damp = g;
			for( j = 0; j < m; j++ ) {
				lpc[j] *= damp;
				damp *= g;
			}
		}

		for( j = 0; j < m; j++ ) {
			lpci[ j ] = (float)lpc[ j ];
		}

		/* we need the error value to know how big an impulse to hit the
		filter with later */

		return (float)error;
	}

	private static final void vorbis_lpc_predict(final float[] coeff,
			final float[] prime, int poffset,// java
			final int m,
			final float[] data, int doffset,// java
			final int n, final int stride) {

		/* in: coeff[0...m-1] LPC coefficients
		prime[0...m-1] initial values (allocated size of n+m-1)
		out: data[0...n-1] data samples */

		final float[] work = new float[ m + n ];

		if( null != prime ) {
			for( int i = 0; i < m; i++, poffset += stride ) {
				work[ i ] = prime[ poffset ];
			}
		}/* else {
			for( int i = 0; i < m; i++ ) {
				work[i] = 0.f;
			}
		}*/// java: don't need, already zeroed

		for( int i = 0; i < n; i++, doffset += stride ) {
			float y = 0;
			int o = i;
			int p = m;
			for( int j = 0; j < m; j++ ) {
				y -= work[ o++ ] * coeff[ --p ];
			}

			data[ doffset ] = work[ o ] = y;
		}
	}
	// end lpc.c

	private static final int LPC_ORDER = 32;// java lpc_order
	/** Read audio data, appending padding to make up any gap
	* between the available and requested number of samples
	* with LPC-predicted data to minimize the pertubation of
	* the valid data that falls in the same frame.
	*/
	@Override
	public int audio_read_func(/* final Object src,*/ final float[] buffer, final int offset, final int samples) throws IOException {
		// private static final long read_padder( void *data, float *buffer, int samples ) {
			// final Jpadder d = (Jpadder)src;
			final int in_samples = this.real_reader.audio_read_func( /* this.real_readdata,*/ buffer, offset, samples );
			// final int lpc_order = 32;

			if( this.original_samples != null ) {
				this.original_samples.addSamples( in_samples );
			}

			int extra = 0;
			if( in_samples < samples ) {
				if( this.lpc_ptr < 0 ) {
					final int nchannels = this.channels;// java
					this.lpc_out = new float[ nchannels * this.extra_samples ];
					if( in_samples > LPC_ORDER * 2 ) {
						int k = offset + (in_samples - LPC_ORDER) * nchannels;// java
						final float[] lpc = new float[ LPC_ORDER ];
						for( int i = 0, oi = offset; i < nchannels; i++, oi++, k++ ) {
							vorbis_lpc_from_data( buffer, oi, lpc, in_samples, LPC_ORDER, nchannels );
							vorbis_lpc_predict( lpc, buffer, k,
									LPC_ORDER, this.lpc_out, i, this.extra_samples, nchannels );
						}
					}
					this.lpc_ptr = 0;
				}
				extra = samples - in_samples;
				if( extra > this.extra_samples ) {
					extra = this.extra_samples;
				}
				this.extra_samples -= extra;
			}
			if( this.lpc_out != null ) {
				System.arraycopy( this.lpc_out, this.lpc_ptr * this.channels, buffer, offset + in_samples * this.channels, extra * this.channels );
			}
			this.lpc_ptr += extra;
			return in_samples + extra;
		// }
	}
	@Override
	public void close() {
	}
	// java: added return Jpadder
	static final Jpadder setup_padder( final Joe_enc_opt opt, final Isamples original_samples ) {
		final Jpadder d = new Jpadder();

		d.real_reader = opt.read_samples;
		// d.real_readdata = opt.readdata;

		opt.read_samples = d;// read_padder;
		// opt.readdata = d;
		d.channels = opt.channels;
		// d.extra_samples = opt.extraout;// java: use set_extra_samples
		d.original_samples = original_samples;
		d.lpc_ptr = -1;
		d.lpc_out = null;
		return d;
	}
	// java: added to avoid link extra_samples and opt.extraout
	/**
	 * @param extraout samples
	 */
	final void set_extra_samples(final int extraout) {
		this.extra_samples = extraout;
	}
	//
	static final void clear_padder( final Joe_enc_opt opt ) {
		final Jpadder d = (Jpadder)opt.read_samples;// opt.readdata;

		opt.read_samples = d.real_reader;
		// opt.readdata = d.real_readdata;

		d.lpc_out = null;
		// free( d );
	}
}
