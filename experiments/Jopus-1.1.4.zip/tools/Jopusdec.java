package tools;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.io.RandomAccessFile;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Random;

import celt.Jcelt;
import gnu.getopt.Getopt;
import gnu.getopt.LongOpt;
import libogg.Jogg_packet;
import libogg.Jogg_page;
import libogg.Jogg_stream_state;
import libogg.Jogg_sync_state;
import opus.JOpusDecoder;
import opus.JOpusMSDecoder;
import opus.Jopus;
import opus.Jopus_defines;

/* Copyright (c) 2002-2007 Jean-Marc Valin
   Copyright (c) 2008 CSIRO
   Copyright (c) 2007-2013 Xiph.Org Foundation
   File: opusdec.c

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions
   are met:

   - Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

   - Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
   ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
   A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE FOUNDATION OR
   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
   EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
   PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;  LOSS OF USE, DATA, OR
   PROFITS;  OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
   LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
   NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
   SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

// opusdec.c

final class Jopusdec {
	private static final String CLASS_NAME = "Jopusdec";
	private static final int EXIT_SUCCESS = 0;
	private static final int EXIT_FAILURE = 1;
	private static final String CHAR_ENCODE = "UTF-8";

	private static final class Jshapestate {
		private float[] b_buf = null;
		private float[] a_buf = null;
		private int fs;
		private int mute;
		//
		private Jshapestate(final int fsr, final int m) {
			fs = fsr;
			mute = m;
		}
		/** This implements a 16 bit quantization with full triangular dither
		and IIR noise shaping. The noise shaping filters were designed by
		Sebastian Gesemann based on the LAME ATH curves with flattening
		to limit their peak gain to 20 dB.
		( Everyone elses' noise shaping filters are mildly crazy )
		The 48kHz version of this filter is just a warped version of the
		44.1kHz filter and probably could be improved by shifting the
		HF shelf up in frequency a little bit since 48k has a bit more
		room and being more conservative against bat-ears is probably
		more important than more noise suppression.
		This process can increase the peak level of the signal ( in theory
		by the peak error of 1.5 +20 dB though this much is unobservable rare )
		so to avoid clipping the signal is attenuated by a couple thousandths
		of a dB. Initially the approach taken here was to only attenuate by
		the 99.9th percentile, making clipping rare but not impossible ( like
		SoX )  but the limited gain of the filter means that the worst case was
		only two thousandths of a dB more, so this just uses the worst case.
		The attenuation is probably also helpful to prevent clipping in the DAC
		reconstruction filters or downstream resampling in any case.*/
		private final void shape_dither_toshort( final short[] _o, final float[] _i, final int inoffset, int _n, final int _CC )
		{
			final int rate = this.fs == 44100 ? 1 : ( this.fs == 48000 ? 0 : 2 );
			final float gain = gains[rate];
			int this_mute = this.mute;
			final float[] b_buff = this.b_buf;
			final float[] a_buff = this.a_buf;
			/*In order to avoid replacing digital silence with quiet dither noise
			we mute if the output has been silent for a while*/
			if( this_mute > 64 ) {
				// memset( a_buf, 0, sizeof( float ) * _CC * 4 );
				for( int i = _CC << 2; --i >= 0; ) {
					a_buff[i] = 0;
				}
			}
			_n *= _CC;// java
			for( int pos = 0; pos < _n; pos += _CC )
			{
				boolean silent = true;
				for( int c = 0; c < _CC; c++ )
				{
					final int c4 = c << 2;// java
					final int pos_c = pos + c;// java
					float err = _i[inoffset + pos_c];// java ;)
					silent &= err == 0;
					float s = err * gain;
					err = 0;
					for( int j = 0; j < 4; j++ ) {
						err += fcoef[rate][j] * b_buff[c4 + j] - fcoef[rate][j + 4] * a_buff[c4 + j];
					}
					System.arraycopy( a_buff, c4, a_buff, c4 + 1, 3 );
					System.arraycopy( b_buff, c4, b_buff, c4 + 1, 3 );
					a_buff[c4] = err;
					s -= err;
					float r = (float)((long)fast_rand() & 0xffffffffL) * (1f / (float) 0xffffffffL) -
								(float)((long)fast_rand() & 0xffffffffL) * (1f / (float) 0xffffffffL);
					if( this_mute > 16 ) {
						r = 0;
					}
					/*Clamp in float out of paranoia that the input will be  > 96 dBFS and wrap if the
					integer is clamped.*/
					r += s;
					r = r <= 32767f ? r : 32767f;
					r = -32768f >= r ? -32768f : r;
					final int si = (int)Math.floor( (double)(.5f + r) );
					_o[pos_c] = (short)si;
					/*Including clipping in the noise shaping is generally disastrous:
					the futile effort to restore the clipped energy results in more clipping.
					However, small amounts-- at the level which could normally be created by
					dither and rounding-- are harmless and can even reduce clipping somewhat
					due to the clipping sometimes reducing the dither+rounding error.*/
					r = 0;
					if( this_mute <= 16 ) {
						r = (float)si - s;
						r = r <= 1.5f ? r : 1.5f;
						r = -1.5f >= r ? -1.5f : r;
					}
					b_buff[c4] = r;
				}
				this_mute++;
				if( ! silent ) {
					this_mute = 0;
				}
			}
			this.mute = this_mute <= 960 ? this_mute : 960;
		}
	}

	// # define float2int( flt )  ( (int)(floor( .5+flt )) )

	/* private static final int CLAMPI( final int a, int b, final int c ) {// never uses
		b = b <= c ? b : c;
		return a >= b ? a : b;
	}*/

	/** 120ms at 48000 */
	private static final int MAX_FRAME_SIZE = 960 * 6;

	private static final int memcmp(final byte[] buf1, int offset1, final byte[] buf2, final int count) {
		for ( int offset2 = 0; offset2 < count; ) {
			int u1 = buf1[offset1++];
			final int u2 = buf2[offset2++];
			u1 -= u2;
			if ( u1 != 0 ) {
				return u1;
			}
		}
		return 0;
	}

	private static final int readint( final byte[] buf, int base ) {
		int v = ( (int)buf[base++] ) & 0xff;
		v|= ( (int)buf[base++] << 8 ) & 0xff00;
		v|= ( (int)buf[base++] << 16 ) & 0xff0000;
		v|= ( (int)buf[base] << 24 ) & 0xff000000;
		return v;
	}

	private static int rngseed = 22222;
	private static final int fast_rand() {// unsigned
		rngseed = ( rngseed * 96314165 ) + 907633515;
		return rngseed;
	}

	private static final float gains[/* 3 */] = { 32768.f-15.f, 32768.f-15.f, 32768.f-3.f };
	private static final float fcoef[/* 3 */][/* 8 */] =
	{
		{2.2374f, -.7339f, -.1251f, -.6033f, 0.9030f, .0116f, -.5853f, -.2571f}, /* 48.0kHz noise shaping filter sd = 2.34*/
		{2.2061f, -.4706f, -.2534f, -.6214f, 1.0587f, .0676f, -.6054f, -.2738f}, /* 44.1kHz noise shaping filter sd = 2.51*/
		{1.0000f, 0.0000f, 0.0000f, 0.0000f, 0.0000f,0.0000f, 0.0000f, 0.0000f}, /* lowpass noise shaping filter sd = 0.65*/
	};

	private static void print_comments( final byte[] comments, final int offset, int length )
	{
		int c = 0;// comments[ c ]
		int len, i, nb_fields;
		if( length < ( 8 + 4 + 4 ) )
		{
			System.err.print("Invalid/corrupted comments\n");
			return;
		}
		if( memcmp( comments, c, "OpusTags".getBytes(), 8 ) != 0 )
		{
			System.err.print("Invalid/corrupted comments\n");
			return;
		}
		c += 8;
		System.err.print("Encoded with ");
		len = readint( comments, c );
		c += 4;
		if( len < 0 || len > ( length - 16 ) )
		{
			System.err.printf("Invalid/corrupted comments\n");
			return;
		}
		try {
			System.err.print( new String( comments, c, len, CHAR_ENCODE ) );

			c += len;
			System.err.printf("\n");
			/*The -16 check above makes sure we can read this.*/
			nb_fields = readint( comments, c );
			c += 4;
			length -= 16 + len;
			if( nb_fields < 0 || nb_fields > ( length >> 2 ) )
			{
				System.err.print("Invalid/corrupted comments\n");
				return;
			}
			for( i = 0; i < nb_fields; i++ )
			{
				if( length < 4 )
				{
					System.err.print("Invalid/corrupted comments\n");
					return;
				}
				len = readint( comments, c );
				c += 4;
				length -= 4;
				if( len < 0 || len > length )
				{
					System.err.printf("Invalid/corrupted comments\n");
					return;
				}
				System.err.print( new String( comments, c, len, CHAR_ENCODE ) );
				c += len;
				length -= len;
				System.err.print("\n");
			}
		} catch( final UnsupportedEncodingException e ) {
		} catch (final Exception e) {
			System.err.printf("Invalid/corrupted/incorrect encoding comments\n");
		}
	}

	/* extracted inplace
	private static final RandomAccessFile out_file_open( final String outFile, final int[] wav_format, final int rate,
			final int mapping_family, final int channels, final boolean fp ) throws IOException
	{
		RandomAccessFile fout = null;
		// Open output file
		if( outFile.length() == 0 )
		{
			System.err.printf("No soundcard support\n");
			System.exit( EXIT_FAILURE );
			return null;
		} else {
			if( outFile.compareTo("-") == 0 )
			{
				// fout = System.out;
				System.err.printf("stdout output not implemented" );
				throw new IOException("stdout output not implemented");
			}
			else
			{
				fout = new RandomAccessFile( outFile, "rw");
			}
			if( wav_format[0] != 0 )
			{
				wav_format[0] = Jwav_io.write_wav_header( fout, rate, mapping_family, channels, fp );
				if( wav_format[0] < 0 )
				{
					System.err.printf("Error writing WAV header.\n");
					System.exit( EXIT_FAILURE );
					return null;
				}
			}
		}
		return fout;
	}
	*/

	private static final void usage()
	{
		System.out.printf("Usage: opusdec [options] input_file.opus [output_file]\n");
		System.out.printf("\n");
		System.out.printf("Decodes a Opus file and produce a WAV file or raw file\n");
		System.out.printf("\n");
		System.out.printf("input_file can be:\n");
		System.out.printf("  filename.opus        regular Opus file\n");
		System.out.printf("  -                    stdin\n");
		System.out.printf("\n");
		System.out.printf("output_file can be:\n");
		System.out.printf("  filename.wav         Wav file\n");
		System.out.printf("  filename.*           Raw PCM file ( any extension other than .wav ) \n");
		System.out.printf("  -                    stdout ( raw;  unless --force-wav ) \n");
		System.out.printf("  ( nothing )             Will be played to soundcard\n");
		System.out.printf("\n");
		System.out.printf("Options:\n");
		System.out.printf(" --rate n              Force decoding at sampling rate n Hz\n");
		System.out.printf(" --gain n              Manually adjust gain by n.nn dB ( 0 default ) \n");
		System.out.printf(" --no-dither           Do not dither 16-bit output\n");
		System.out.printf(" --float               32-bit floating-point output\n");
		System.out.printf(" --force-wav           Force wav header on output\n");
		System.out.printf(" --packet-loss n       Simulate n %% random packet loss\n");
		System.out.printf(" --save-range file     Saves check values for every frame to a file\n");
		System.out.printf(" -h, --help            This help\n");
		System.out.printf(" -V, --version         Version information\n");
		System.out.printf(" --quiet               Quiet mode\n");
		System.out.printf("\n");
	}

	private static final void version()
	{
		System.out.printf("Jopusdec %s %s (using %)\n", Jtools.PACKAGE_NAME, Jtools.PACKAGE_VERSION, Jcelt.opus_get_version_string() );
		System.out.printf("Copyright (C) 2008-2013 Xiph.Org Foundation\n");
	}

	private static final void version_short()
	{
		version();
	}

	/** Process an Opus header and setup the opus decoder based on it.
	It takes several pointers for header values which are needed
	elsewhere in the code. */
	/* private static final JOpusMSDecoder process_header( final Jogg_packet op, final int[] rate,
			final int[] mapping_family, final int[] channels, final int[] preskip, final float[] gain,
			final float manual_gain, final int[] streams, final boolean wav_format, final boolean quiet )
	{
		final JOpusHeader header = new JOpusHeader();

		if( header.opus_header_parse( op.packet_base, op.packet, op.bytes ) == 0 )
		{
			System.out.printf("Cannot parse header\n");
			return null;
		}

		mapping_family[0] = header.channel_mapping;
		channels[0] = header.channels;
		if( wav_format ) {
			Jwav_io.adjust_wav_mapping( mapping_family[0], channels[0], header.stream_map );
		}

		if( 0 == rate[0] ) {
			rate[0] = header.input_sample_rate;
		}
		// If the rate is unspecified we decode to 48000
		if( rate[0] == 0 ) {
			rate[0] = 48000;
		}
		if( rate[0] < 8000 || rate[0] > 192000 ) {
			System.out.printf("Warning: Crazy input_rate %d, decoding to 48000 instead.\n", rate[0] );
			rate[0] = 48000;
		}

		preskip[0] = header.preskip;

		final int[] err = new int[1];
		final JOpusMSDecoder st = JOpusMSDecoder.opus_multistream_decoder_create( 48000, header.channels, header.nb_streams, header.nb_coupled, header.stream_map, err );
		if( err[0] != Jopus_defines.OPUS_OK ) {
			System.out.printf("Cannot create decoder: %s\n", Jcelt.opus_strerror( err[0] ) );
			return null;
		}
		if( null == st )
		{
			System.err.printf("Decoder initialization failed: %s\n", Jcelt.opus_strerror( err[0] ) );
			return null;
		}

		streams[0] = header.nb_streams;

		if( header.gain != 0 || manual_gain != 0 )
		{
			// Gain API added in a newer libopus version, if we don't have it
			// we apply the gain ourselves. We also add in a user provided
			// manual gain at the same time.
			final int gainadj = (int)( manual_gain * 256. ) + header.gain;
// #ifdef OPUS_SET_GAIN
			err[0] = st.opus_multistream_decoder_ctl( Jopus_defines.OPUS_SET_GAIN_REQUEST, gainadj );
			if( err[0] == Jopus_defines.OPUS_UNIMPLEMENTED )
			{
// #endif
				gain[0] = (float)Math.pow( 10., (double)gainadj / 5120. );
// #ifdef OPUS_SET_GAIN
			} else if( err[0] != Jopus_defines.OPUS_OK )
			{
				System.err.printf("Error setting gain: %s\n", Jcelt.opus_strerror( err[0] ) );
				return null;
			}
// #endif
		}

		if( ! quiet )
		{
			System.err.printf("Decoding to %d Hz (%d channel%s)", rate[0],
								channels[0], channels[0] > 1 ? "s" : "");
			if( header.version != 1 ) {
				System.err.printf(", Header v%d", header.version );
			}
			System.err.printf("\n");
			if( header.gain != 0 ) {
				System.err.printf("Playback gain: %f dB\n", header.gain / 256.f );
			}
			if( manual_gain != 0 ) {
				System.err.printf("Manual gain: %f dB\n", manual_gain );
			}
		}

		return st;
	}
	*/

	private static final long audio_write( final float[] pcm, final int channels, int frame_size,
			final RandomAccessFile fout, final JSpeexResampler resampler,
			final int[] skip, final Jshapestate shapemem, final boolean file, int maxout, final boolean fp )
			throws IOException
	{
		int pcmoffset = 0;// java
		long sampout = 0;
		final short[] out = new short[ MAX_FRAME_SIZE * channels ];
		final float[] buf = new float[ MAX_FRAME_SIZE * channels ];
		maxout = maxout < 0 ? 0 : maxout;
		do {
			int tmp_skip;
			if( skip != null ) {
				tmp_skip = ( skip[0] > frame_size ) ? (int)frame_size : skip[0];
				skip[0] -= tmp_skip;
			} else {
				tmp_skip = 0;
			}
			int out_len;
			float[] output;
			int outoffset;// java
			if( resampler != null ) {
				output = buf;
				outoffset = 0;
				int in_len = frame_size - tmp_skip;
				out_len = 1024 < maxout ? 1024 : maxout;
				final long tmp = resampler.speex_resampler_process_interleaved_float( pcm, pcmoffset + channels * tmp_skip, in_len, buf, 0, out_len );
				out_len = (int)tmp;
				in_len = (int)(tmp >> 32);
				pcmoffset += channels * ( in_len + tmp_skip );
				frame_size -= in_len + tmp_skip;
			} else {
				output = pcm;
				outoffset = channels * tmp_skip;// java
				out_len = frame_size - tmp_skip;
				frame_size = 0;
			}

			if( ! file || ! fp )
			{
				/*Convert to short and save to output file*/
				if( shapemem != null ) {
					shapemem.shape_dither_toshort( out, output, outoffset, out_len, channels );
				} else {
					for( int i = 0, oi = outoffset, ie = out_len * channels; i < ie; i++ ) {
						float v = output[ oi ] * 32768.f;
						v = v > 32767f ? 32767f : (v >= -32768f ? v : -32768f);
						out[ i ] = (short)Math.floor( (double)(.5f + v) );
					}
				}
				/* if( ( le_short( 1 ) != 1 ) && file ) {
					for( int i = 0, ie = out_len * channels; i < ie; i++ ) {
						out[i] = (short)out[i];
					}
				}*/
			}

			if( maxout > 0 )
			{
				int ret = 0;
				if( ! file ) {
					System.err.print("Error playing audio.\n");// FIXME ret is negative and will be used
				} else {
					// ret = fwrite( fp ? (char *) output : (char *) out, ( fp ? 4 : 2 ) * channels, out_len < maxout ? out_len : maxout, fout );
					//
					final boolean is_big_endian = false;
					out_len = (int)(out_len <= maxout ? out_len : maxout);
					ret = out_len;// java
					out_len *= channels;
					if( fp ) {
						// float -> byte
						final byte[] bytebuffer = new byte[ out_len * (Float.SIZE / 8) ];
						ByteBuffer.wrap( bytebuffer ).order( is_big_endian ? ByteOrder.BIG_ENDIAN : ByteOrder.LITTLE_ENDIAN )
								.asFloatBuffer().put( output, outoffset, out_len );
						fout.write( bytebuffer );
					} else {
						// short -> byte little endian
						final byte[] bytebuffer = new byte[ out_len * (Short.SIZE / 8) ];
						ByteBuffer.wrap( bytebuffer ).order( is_big_endian ? ByteOrder.BIG_ENDIAN : ByteOrder.LITTLE_ENDIAN )
								.asShortBuffer().put( out, 0, out_len );
						fout.write( bytebuffer );
					}
				}
				sampout += ret;
				maxout -= ret;
			}
		} while( frame_size > 0 && maxout > 0 );
		return sampout;
	}

	@SuppressWarnings({ "boxing", "null" })
	public static final void main( final String[] args )// int main( final int argc, char **argv )
	{
		final LongOpt long_options[] =
			{
				new LongOpt("help", LongOpt.NO_ARGUMENT, null, 0),
				new LongOpt("quiet", LongOpt.NO_ARGUMENT, null, 0),
				new LongOpt("version", LongOpt.NO_ARGUMENT, null, 0),
				new LongOpt("version-short", LongOpt.NO_ARGUMENT, null, 0),
				new LongOpt("rate", LongOpt.REQUIRED_ARGUMENT, null, 0),
				new LongOpt("gain", LongOpt.REQUIRED_ARGUMENT, null, 0),
				new LongOpt("no-dither", LongOpt.NO_ARGUMENT, null, 0),
				new LongOpt("float", LongOpt.NO_ARGUMENT, null, 0),
				new LongOpt("force-wav", LongOpt.NO_ARGUMENT, null, 0),
				new LongOpt("packet-loss", LongOpt.REQUIRED_ARGUMENT, null, 0),
				new LongOpt("save-range", LongOpt.REQUIRED_ARGUMENT, null, 0),
				// new Joption{0, 0, 0, 0}
			};
		PrintStream frange = null;
		float loss_percent = -1;
		float manual_gain = 0;
		int rate = 0;
		boolean dither = true;
		boolean fp = false;
		boolean quiet = false;
		boolean forcewav = false;

		/*Process options*/
		final Getopt g = new Getopt( CLASS_NAME, args, "hV", long_options );
		g.setOpterr( false );
		int c;
		while( (c = g.getopt()) != -1 )
		{
			final String optarg = g.getOptarg();
			switch( c )
			{
			case 0:
				final String name = long_options[ g.getLongind() ].getName();// java
				if( name.compareTo("help" ) == 0 )
				{
					usage();
					System.exit( EXIT_SUCCESS );
					return;
				} else if( name.compareTo("quiet" ) == 0 )
				{
					quiet = true;
				} else if( name.compareTo("version" ) == 0 )
				{
					version();
					System.exit( EXIT_SUCCESS );
					return;
				} else if( name.compareTo("version-short" ) == 0 )
				{
					version_short();
					System.exit( EXIT_SUCCESS );
					return;
				} else if( name.compareTo("no-dither" ) == 0 )
				{
					dither = false;
				} else if( name.compareTo("float" ) == 0 )
				{
					fp = true;
				} else if( name.compareTo("force-wav" ) == 0 )
				{
					forcewav = true;
				} else if( name.compareTo("rate" ) == 0 )
				{
					rate = Integer.parseInt( optarg );
				} else if( name.compareTo("gain" ) == 0 )
				{
					manual_gain = Float.parseFloat( optarg );
				}else if( name.compareTo("save-range" ) == 0 ) {
					try {
						frange = new PrintStream( optarg );
					} catch(final Exception e){
						System.err.printf("Could not open save-range file: %s\n", optarg );
						System.err.printf("Must provide a writable file name.\n");
						System.exit( EXIT_FAILURE );
						return;
					}
				} else if( name.compareTo("packet-loss" ) == 0 )
				{
					loss_percent = Float.parseFloat( optarg );
				}
				break;
			case 'h':
				usage();
				System.exit( EXIT_SUCCESS );
				return;
				// break;
			case 'V':
				version();
				System.exit( EXIT_SUCCESS );
				return;
				// break;
			case '?':
				usage();
				System.exit( EXIT_FAILURE );
				return;
				//break;
			}
		}
		final int optind = g.getOptind();
		if( args.length - optind != 2 && args.length - optind != 1 )
		{
			usage();
			System.exit( EXIT_FAILURE );
			return;
		}
		final String inFile = args[ optind ];

		/*Output to a file or playback?*/
		String outFile;
		int wav_format;
		if( args.length - optind == 2 ) {
			/*If we're outputting to a file, should we apply a wav header?*/
			outFile = args[ optind + 1 ];
			wav_format = outFile.endsWith(".wav") ? 1 : 0;
			wav_format |= forcewav ? 1 : 0;
		} else {
			outFile = "";
			wav_format = 0;
			/*If playing to audio out, default the rate to 48000
			instead of the original rate. The original rate is
			only important for minimizing surprise about the rate
			of output files and preserving length, which aren't
			relevant for playback. Many audio devices sound
			better at 48kHz and not resampling also saves CPU.*/
			if( rate == 0 ) {
				rate = 48000;
			}
			/*Playback is 16-bit only.*/
			fp = false;
		}
		/*If the output is floating point, don't dither.*/
		if( fp ) {
			dither = false;
		}

		/*Open input file*/
		InputStream fin = null;
		boolean close_in = false;
		RandomAccessFile fout = null;
try {
		if( inFile.compareTo("-") == 0 )
		{
			fin = System.in;
		}
		else
		{
			try {
				fin = new FileInputStream( inFile );
			} catch(final Exception e) {
				System.err.println( e.getMessage() );
				System.exit( EXIT_FAILURE );
				return;
			}
			close_in = true;
		}

		int opus_serialno = 0;// The local variable opus_serialno may not have been initialized
		int frame_size = 0;
		JOpusMSDecoder st = null;
		int streams = 0;
		JSpeexResampler resampler = null;
		int channels = -1;
		long packet_count = 0;
		int total_links = 0;
		boolean stream_init = false;
		long page_granule = 0;
		long link_out = 0;
		int last_spin = 0;
		float[] output = null;
		long audio_size = 0;
		boolean eos = false;
		boolean has_opus_stream = false;
		boolean has_tags_packet = false;
		double last_coded_seconds = 0;
		int gran_offset = 0;
		final int[] preskip = { 0 };
		float gain = 1f;
		final Jshapestate shapemem = new Jshapestate( 0, 960 );// fs = 0, mute = 960, a_buf = null, b_buf = null
		/* .opus files use the Ogg container to provide framing and timekeeping.
		* http://tools.ietf.org/html/draft-terriberry-oggopus
		* The easiest way to decode the Ogg container is to use libogg, so
		*  thats what we do here.
		* Using libogg is fairly straight forward-- you take your stream of bytes
		*  and feed them to ogg_sync_ and it periodically returns Ogg pages, you
		*  check if the pages belong to the stream you're decoding then you give
		*  them to libogg and it gives you packets. You decode the packets. The
		*  pages also provide timing information.*/
		final Jogg_sync_state oy = new Jogg_sync_state();
		final Jogg_page       og = new Jogg_page();
		final Jogg_packet     op = new Jogg_packet();
		final Jogg_stream_state os = new Jogg_stream_state();
		oy.ogg_sync_init();

		/*Main decoding loop*/
		while( true )
		{
			/*Get the ogg buffer for writing*/
			final int data = oy.ogg_sync_buffer( 200 );
			/*Read bitstream from input file*/
			final int nb_read = fin.read( oy.data, data, 200 );
			if( nb_read < 0 ) {// java analog feof
				if( ! quiet ) {
					System.err.printf("\rDecoding complete.        \n");
					System.err.flush();
				}
				break;
			}
			oy.ogg_sync_wrote( nb_read );

			/*Loop for all complete pages we got (most likely only one) */
			while( oy.ogg_sync_pageout( og ) == 1 )
			{
				if( ! stream_init ) {
					os.ogg_stream_init( og.ogg_page_serialno() );
					stream_init = true;
				}
				if( og.ogg_page_serialno() != os.serialno ) {
					/* so all streams are read. */
					os.ogg_stream_reset_serialno( og.ogg_page_serialno() );
				}
				/*Add page to the bitstream*/
				os.ogg_stream_pagein( og );
				page_granule = og.ogg_page_granulepos();
				/*Extract all available packets*/
				while( os.ogg_stream_packetout( op ) ==  1 )
				{
					/*OggOpus streams are identified by a magic string in the initial
					stream header.*/
					if( op.b_o_s && op.bytes >= 8 && 0 == memcmp( op.packet_base, op.packet, "OpusHead".getBytes(), 8 ) ) {
						if( has_opus_stream && has_tags_packet )
						{
							/*If we're seeing another BOS OpusHead now it means
							the stream is chained without an EOS.*/
							has_opus_stream = false;
							/* if( st != null ) {
								opus_multistream_decoder_destroy( st );
							}*/
							st = null;
							System.err.printf("\nWarning: stream %d ended without EOS and a new stream began.\n", os.serialno );
						}
						if( ! has_opus_stream )
						{
							if( packet_count > 0 && opus_serialno == os.serialno )
							{
								System.err.printf("\nError: Apparent chaining without changing serial number (%d == %d).\n",
													opus_serialno, os.serialno );
								System.exit( EXIT_FAILURE );// FIXME need close frange, fin, fout
								return;
							}
							opus_serialno = os.serialno;
							has_opus_stream = true;
							has_tags_packet = false;
							link_out = 0;
							packet_count = 0;
							eos = false;
							total_links++;
						} else {
							System.err.printf("\nWarning: ignoring opus stream %d\n", os.serialno );
						}
					}
					if( ! has_opus_stream || os.serialno != opus_serialno ) {
						break;
					}
					/*If first packet in a logical stream, process the Opus header*/
					if( packet_count == 0 )
					{
						// java extracted inplace to avoid a problem with getting output data
						// st = process_header( op, &rate, &mapping_family, &channels, &preskip, &gain, manual_gain, &streams, wav_format != 0, quiet );
						/* Process an Opus header and setup the opus decoder based on it.
						It takes several pointers for header values which are needed
						elsewhere in the code. */
					// {
						final JOpusHeader header = new JOpusHeader();

						if( ! header.opus_header_parse( op.packet_base, op.packet, op.bytes ) ) {
							System.out.printf("Cannot parse header\n");
							System.exit( EXIT_FAILURE );
							return;
						}

						final int mapping_family = header.channel_mapping;
						channels = header.channels;
						if( wav_format != 0 ) {
							Jwav_io.adjust_wav_mapping( mapping_family, channels, header.stream_map );
						}

						if( 0 == rate ) {
							rate = header.input_sample_rate;
						}
						/*If the rate is unspecified we decode to 48000*/
						if( rate == 0 ) {
							rate = 48000;
						}
						if( rate < 8000 || rate > 192000 ) {
							System.out.printf("Warning: Crazy input_rate %d, decoding to 48000 instead.\n", rate );
							rate = 48000;
						}

						preskip[0] = header.preskip;

						final int[] err = new int[1];
						st = JOpusMSDecoder.opus_multistream_decoder_create( 48000, header.channels, header.nb_streams, header.nb_coupled, header.stream_map, err );
						if( err[0] != Jopus_defines.OPUS_OK ) {
							System.out.printf("Cannot create decoder: %s\n", Jcelt.opus_strerror( err[0] ) );
							System.exit( EXIT_FAILURE );
							return;
						}
						if( null == st ) {
							System.err.printf("Decoder initialization failed: %s\n", Jcelt.opus_strerror( err[0] ) );
							System.exit( EXIT_FAILURE );
							return;
						}

						streams = header.nb_streams;

						if( header.gain != 0 || manual_gain != 0 ) {
							/*Gain API added in a newer libopus version, if we don't have it
							we apply the gain ourselves. We also add in a user provided
							manual gain at the same time.*/
							final int gainadj = (int)( manual_gain * 256. ) + header.gain;
				// #ifdef OPUS_SET_GAIN
							err[0] = st.opus_multistream_decoder_ctl( Jopus_defines.OPUS_SET_GAIN_REQUEST, gainadj );
							if( err[0] == Jopus_defines.OPUS_UNIMPLEMENTED ) {
				// #endif
								gain = (float)Math.pow( 10., (double)gainadj / 5120. );
				// #ifdef OPUS_SET_GAIN
							} else if( err[0] != Jopus_defines.OPUS_OK ) {
								System.err.printf("Error setting gain: %s\n", Jcelt.opus_strerror( err[0] ) );
								System.exit( EXIT_FAILURE );
								return;
							}
				// #endif
						//}

							if( ! quiet ) {
								System.err.printf("Decoding to %d Hz (%d channel%s)", rate,
													channels, channels > 1 ? "s" : "");
								if( header.version != 1 ) {
									System.err.printf(", Header v%d", header.version );
								}
								System.err.printf("\n");
								if( header.gain != 0 ) {
									System.err.printf("Playback gain: %f dB\n", header.gain / 256.f );
								}
								if( manual_gain != 0 ) {
									System.err.printf("Manual gain: %f dB\n", manual_gain );
								}
							}
						}// end process_header
						/* if( null == st ) {
							System.exit( EXIT_FAILURE );// FIXME need close frange, fin, fout
							return;
						}*/

						if( os.ogg_stream_packetout( op ) != 0 || (int)og.header_base[ og.header + og.header_len - 1 ] == -1 ) // 255 )
						{
							/*The format specifies that the initial header and tags packets are on their
							own pages. To aid implementors in discovering that their files are wrong
							we reject them explicitly here. In some player designs files like this would
							fail even without an explicit test.*/
							System.err.printf("Extra packets on initial header page. Invalid stream.\n");
							System.exit( EXIT_FAILURE );// FIXME need close frange, fin, fout
							return;
						}

						/*Remember how many samples at the front we were told to skip
						so that we can adjust the timestamp counting.*/
						gran_offset = preskip[0];

						/*Setup the memory for the dithered output*/
						if( null == shapemem.a_buf )
						{
							shapemem.a_buf = new float[ channels << 2 ];
							shapemem.b_buf = new float[ channels << 2 ];
							shapemem.fs = rate;
						}
						if( null == output ) {
							output = new float[ MAX_FRAME_SIZE * channels ];
						}

						/*Normal players should just play at 48000 or their maximum rate,
						as described in the OggOpus spec.  But for commandline tools
						like opusdec it can be desirable to exactly preserve the original
						sampling rate and duration, so we have a resampler here.*/
						if( rate != 48000 && resampler == null )
						{
							try {
								resampler = JSpeexResampler.speex_resampler_init( channels, 48000, rate, 5 );
							} catch(final IllegalArgumentException ie) {
								System.err.printf("resampler error: %s\n", ie.getMessage() );
								System.exit( EXIT_FAILURE );
								return;
							}
							resampler.speex_resampler_skip_zeros();
						}
						if( null == fout ) {
							// java extracted inplace to avoid a problem with getting output data
							// fout = out_file_open( outFile, &wav_format, rate, mapping_family, &channels, fp );
							/*Open output file*/
							if( outFile.length() == 0 ) {
								System.err.printf("No soundcard support\n");
								System.exit( EXIT_FAILURE );
								return;
							} else {
								if( outFile.compareTo("-") == 0 ) {
									// fout = System.out;
									System.err.printf("stdout output not implemented" );
									System.exit( EXIT_FAILURE );
									return;
								} else {
									fout = new RandomAccessFile( outFile, "rw");
								}
								if( wav_format != 0 ) {
									wav_format = Jwav_io.write_wav_header( fout, rate, mapping_family, channels, fp );
									if( wav_format < 0 ) {
										System.err.printf("Error writing WAV header.\n");
										System.exit( EXIT_FAILURE );
										return;
									}
								}
							}
						}
					} else if( packet_count == 1 )
					{
						if( ! quiet ) {
							print_comments( op.packet_base, op.packet, op.bytes );
						}
						has_tags_packet = true;
						if( os.ogg_stream_packetout( op ) != 0 || (int)og.header_base[ og.header + og.header_len - 1] == -1 )// 255 )
						{
							System.err.printf("Extra packets on initial tags page. Invalid stream.\n");
							System.exit( EXIT_FAILURE );// FIXME need close frange, fin, fout
							return;
						}
					} else {
						int ret;
						final boolean lost = ( loss_percent > 0 && 100 * ((float)new Random().nextInt( 0x8000 )) / 0x7fff < loss_percent );

						/*End of stream condition*/
						if( op.e_o_s && os.serialno == opus_serialno ) {
							eos = true;
						}  /* don't care for anything except opus eos */

						/*Are we simulating loss for this packet?*/
						if( ! lost ) {
							/*Decode Opus packet*/
							ret = st.opus_multistream_decode_float( op.packet_base, op.packet, op.bytes, output, 0, MAX_FRAME_SIZE, false );
						} else {
							/*Extract the original duration.
							Normally you wouldn't have it for a lost packet, but normally the
							transports used on lossy channels will effectively tell you.
							This avoids opusdec squaking when the decoded samples and
							granpos mismatches.*/
							int lost_size = MAX_FRAME_SIZE;
							if( op.bytes > 0 ) {
								int spp = JOpusDecoder.opus_packet_get_nb_frames( op.packet_base, op.packet, op.bytes );
								if( spp > 0 ) {
									spp *= Jopus.opus_packet_get_samples_per_frame( op.packet_base, op.packet, 48000/*decoding_rate*/ );
									if( spp > 0 ) {
										lost_size = spp;
									}
								}
							}
							/*Invoke packet loss concealment.*/
							ret = st.opus_multistream_decode_float( null, 0, 0, output, 0, lost_size, false );
						}

						if( ! quiet ) {
							/*Display a progress spinner while decoding.*/
							final char spinner[] = {'|', '/', '-', '\\'};
							final double coded_seconds = (double)audio_size / ( channels * rate * ( fp ? 4 : 2 ) );
							if( coded_seconds >= last_coded_seconds + 1 ) {
								System.err.printf("\r[%c] %02d:%02d:%02d", spinner[last_spin & 3],
										(int)( coded_seconds / 3600 ), (int)( coded_seconds / 60 ) % 60,
										(int)( coded_seconds ) % 60 );
								System.err.flush();
								last_spin++;
								last_coded_seconds = coded_seconds;
							}
						}

						/*If the decoder returned less than zero, we have an error.*/
						if( ret < 0 )
						{
							System.err.printf("Decoding error: %s\n", Jcelt.opus_strerror( ret ) );
							break;
						}
						frame_size = ret;

						/*If we're collecting --save-range debugging data, collect it now.*/
						if( frange != null ) {
							final long rngs[] = new long[256];
							final Object[] request = new Object[1];// java helper
							for( int i = 0; i < streams; i++ ) {
								ret = st.opus_multistream_decoder_ctl( JOpusMSDecoder.OPUS_MULTISTREAM_GET_DECODER_STATE, i, request );
								final JOpusDecoder od = (JOpusDecoder)request[0];
								ret = od.opus_decoder_ctl( Jopus_defines.OPUS_GET_FINAL_RANGE, request );
								rngs[i] = ((Long)request[0]).longValue();
							}
							Jdiag_range.save_range( frange, frame_size * ( 48000 / 48000/*decoding_rate*/ ), op.packet_base, op.packet, op.bytes,
									rngs, streams );
						}

						/*Apply header gain, if we're not using an opus library new
						enough to do this internally.*/
						if( gain != 0 && gain != 1f ) {// FIXME skip 1.
							for( int i = 0, ie = frame_size * channels; i < ie; i++ ) {
								output[i] *= gain;
							}
						}

						/*This handles making sure that our output duration respects
						the final end-trim by not letting the output sample count
						get ahead of the granpos indicated value.*/
						final int maxout = (int)(( (page_granule - (long)gran_offset) * (long)rate / 48000 ) - link_out);
						final long outsamp = audio_write( output, channels, frame_size, fout,
								resampler, preskip, dither ? shapemem : null, outFile.length() != 0, 0 > maxout ? 0 : maxout, fp );
						link_out += outsamp;
						audio_size += (fp ? 4 : 2) * outsamp * channels;
					}
					packet_count++;
				}
				/*We're done, drain the resampler if we were using it.*/
				if( eos && resampler != null )
				{
					float[] zeros = new float[ 100 * channels ];
					int drain = resampler.speex_resampler_get_input_latency();
					do {
						int tmp = drain;
						if( tmp > 100 ) {
							tmp = 100;
						}
						final long outsamp = audio_write( zeros, channels, tmp, fout,
								resampler, null, shapemem, outFile.length() != 0, (int)(((page_granule - gran_offset) * rate / 48000) - link_out), fp );
						link_out += outsamp;
						audio_size += ( fp ? 4 : 2 ) * outsamp * channels;
						drain -= tmp;
					} while( drain > 0 );
					zeros = null;
					// speex_resampler_destroy( resampler );
					resampler = null;
				}
				if( eos )
				{
					has_opus_stream = false;
					/* if( st != null ) {
						opus_multistream_decoder_destroy( st );
					} */
					st = null;
				}
			}// while( oy.ogg_sync_pageout( og ) == 1 )
			// java moved up, no analog
			/* if( feof( fin ) ) {
				if( ! quiet ) {
					System.err.printf("\rDecoding complete.        \n");
					System.err.flush();
				}
				break;
			}*/
		}// while true

		/*If we were writing wav, go set the duration.*/
		if( outFile.length() != 0 && fout != null && wav_format > 0 && audio_size < 0x7FFFFFFF )
		{
			try {
				fout.seek( 4 );
				try {
					final int tmp = (int)audio_size + 20 + wav_format;
					fout.write( tmp );// low endian
					fout.write( tmp >> 8 );
					fout.write( tmp >> 16 );
					fout.write( tmp >> 24 );
				} catch(final IOException e) {
					System.err.printf("Error writing end length.\n");
				}
				try {
					fout.seek( 4 + 4 + 16 + wav_format );// SEEK_CUR, cur = 4 + 4
					final int tmp = (int)audio_size;
					try {
						fout.write( tmp );// low endian
						fout.write( tmp >> 8 );
						fout.write( tmp >> 16 );
						fout.write( tmp >> 24 );
					} catch(final IOException e) {
						System.err.printf("Error writing header length.\n");
					}
				} catch( final IOException e ) {
					System.err.printf("First seek worked, second didn't\n");
				}
			} catch( final IOException e ) {
				System.err.printf("Cannot seek on wav file output, wav size chunk will be incorrect\n");
			}
		}

		/*Did we make it to the end without recovering ANY opus logical streams?*/
		if( 0 == total_links ) {
			System.err.printf("This doesn't look like a Opus file\n");
		}

		if( stream_init ) {
			os.ogg_stream_clear();
		}
		oy.ogg_sync_clear();

		if( outFile.length() == 0 ) {
			// WIN_Audio_close();
		}

		// if( shapemem.a_buf != null ) {
			shapemem.a_buf = null;
		// }
		// if( shapemem.b_buf != null ) {
			shapemem.b_buf = null;
		// }

		// if( output != null ) {
			output = null;
		// }
} catch(final Exception e) {
		e.printStackTrace();
} finally {
		if( frange != null ) {
			frange.close();
		}

		if( close_in ) {
			if( fin != null ) {
				try { fin.close(); } catch( final IOException e ) {}
			}
		}
		if( fout != null ) {
			try { fout.close(); } catch( final IOException e ) {}
		}
}
		System.exit( EXIT_SUCCESS );
		return;
	}
}