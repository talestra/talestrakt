package tools;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioFormat.Encoding;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import celt.Jcelt;
import gnu.getopt.Getopt;
import gnu.getopt.LongOpt;
import libogg.Jogg_packet;
import libogg.Jogg_page;
import libogg.Jogg_stream_state;
import opus.JOpusEncoder;
import opus.JOpusMSEncoder;
import opus.Jms_encoder_data_aux;
import opus.Jopus_defines;

/* Copyright (C) 2002-2011 Jean-Marc Valin
   Copyright (C) 2007-2013 Xiph.Org Foundation
   Copyright (C) 2008-2013 Gregory Maxwell
   File: opusenc.c

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions
   are met:

   - Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

   - Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
   ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
   A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE FOUNDATION OR
   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
   EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
   PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;  LOSS OF USE, DATA, OR
   PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
   LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
   NEGLIGENCE OR OTHERWISE)  ARISING IN ANY WAY OUT OF THE USE OF THIS
   SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

// opusenc.c

final class Jopusenc implements Isamples {
	private static final String CLASS_NAME = "Jopusenc";
	private static final int EXIT_SUCCESS = 0;
	private static final int EXIT_FAILURE = 1;

	// private static final boolean HAVE_LIBFLAC = false;

	/** Write an Ogg page to a file pointer */
	private static final int oe_write_page( final Jogg_page page, final OutputStream fp ) throws IOException
	{
		fp.write( page.header_base, page.header, page.header_len );
		fp.write( page.body_base, page.body, page.body_len );
		return page.header_len + page.body_len;// written
	}

	// private static final int MAX_FRAME_BYTES = 61295;// FIXME never using

	private static final void opustoolsversion( final String opusversion )
	{
		System.out.printf( "opusenc %s %s (using %s)\n", Jtools.PACKAGE_NAME, Jtools.PACKAGE_VERSION, opusversion );
		System.out.printf( "Copyright (C) 2008-2013 Xiph.Org Foundation\n");
	}

	private static final void opustoolsversion_short( final String opusversion )
	{
		opustoolsversion( opusversion );
	}

	private static final String getSupportedAudioEncoding() {
		final StringBuilder sb = new StringBuilder("It can read the ");
		final AudioFormat af = new AudioFormat( 48000, 16, 2, true, false );
		// final Encoding[] encodings = ;
		int length = sb.length();
		for( final Encoding e : AudioSystem.getTargetEncodings( af ) ) {
			final String s = e.toString();
			length += s.length();
			if( length > 70 ) {// 70 is max console chars in a line
				sb.append("\n                ");
				length = 16;// space count
			}
			sb.append( s ).append(',').append(' ');
			length += 2;
		}
		if( length + 13 /*"or raw files.\n".length()*/ > 70 ) {
			sb.append("\n                ");
		}
		sb.append("or raw files.\n");
		return sb.toString();
	}
	private static final void usage()
	{
		System.out.printf("Usage: Jopusenc [options] input_file output_file.opus\n");
		System.out.printf("\n");
		System.out.printf("Encodes input_file using Opus.\n");
/* if( HAVE_LIBFLAC ) {
		System.out.printf("It can read the WAV, AIFF, FLAC, Ogg/FLAC, or raw files.\n");
} else {
		System.out.printf("It can read the WAV, AIFF, or raw files.\n");
}*/
		System.out.print( getSupportedAudioEncoding() );
		System.out.printf("\nGeneral options:\n");
		System.out.printf(" -h, --help         This help\n");
		System.out.printf(" -V, --version      Version information\n");
		System.out.printf(" --quiet            Quiet mode\n");
		System.out.printf("\n");
		System.out.printf("input_file can be:\n");
		System.out.printf("  filename.wav      file\n");
		System.out.printf("  -                 stdin\n");
		System.out.printf("\n");
		System.out.printf("output_file can be:\n");
		System.out.printf("  filename.opus     compressed file\n");
		System.out.printf("  -                 stdout\n");
		System.out.printf("\nEncoding options:\n");
		System.out.printf(" --bitrate n.nnn    Target bitrate in kbit/sec (6-256/channel)\n");
		System.out.printf(" --vbr              Use variable bitrate encoding (default)\n");
		System.out.printf(" --cvbr             Use constrained variable bitrate encoding\n");
		System.out.printf(" --hard-cbr         Use hard constant bitrate encoding\n");
		System.out.printf(" --comp n           Encoding complexity  0-10, default: 10 (slowest))\n");
		System.out.printf(" --framesize n      Maximum frame size in milliseconds\n");
		System.out.printf("                      (2.5, 5, 10, 20, 40, 60, default: 20)\n");
		System.out.printf(" --expect-loss      Percentage packet loss to expect (default: 0)\n");
		System.out.printf(" --downmix-mono     Downmix to mono\n");
		System.out.printf(" --downmix-stereo   Downmix to stereo (if >2 channels)\n");
		System.out.printf(" --max-delay n      Maximum container delay in milliseconds\n");
		System.out.printf("                      (0-1000, default: 1000)\n");
		System.out.printf("\nDiagnostic options:\n");
		System.out.printf(" --serial n         Forces a specific stream serial number\n");
		System.out.printf(" --save-range file  Saves check values for every frame to a file\n");
		System.out.printf(" --set-ctl-int x = y  Pass the encoder control x with value y (advanced)\n");
		System.out.printf("                      Preface with s: to direct the ctl to multistream s\n");
		System.out.printf("                      This may be used multiple times\n");
		System.out.printf("\nMetadata options:\n");
		System.out.printf(" --comment          Add the given string as an extra comment\n");
		System.out.printf("                      This may be used multiple times\n");
		System.out.printf(" --artist           Author of this track\n");
		System.out.printf(" --title            Title for this track\n");
		System.out.printf(" --album            Album or collection this track belongs to\n");
		System.out.printf(" --date             Date for this track\n");
		System.out.printf(" --genre            Genre for this track\n");
		System.out.printf(" --picture          Album art for this track\n");
		System.out.printf("                      More than one --picture option can be specified.\n");
		System.out.printf("                      Either a FILENAME for the picture file or a more\n");
		System.out.printf("                      complete SPECIFICATION form can be used. The\n");
		System.out.printf("                      SPECIFICATION is a string whose parts are\n");
		System.out.printf("                      separated by | (pipe) characters. Some parts may\n");
		System.out.printf("                      be left empty to invoke default values. A\n");
		System.out.printf("                      FILENAME is just shorthand for \"||||FILENAME\".\n");
		System.out.printf("                      The format of SPECIFICATION is\n");
		System.out.printf("\n");
		System.out.printf("                      [TYPE]|[MIME-TYPE]|[DESCRIPTION]|[WIDTHxHEIGHT\n");
		System.out.printf("                      xDEPTH[/COLORS]]|FILENAME\n");
		System.out.printf("\n");
		System.out.printf("                      TYPE is an optional number from one of:\n");
		System.out.printf("                      0: Other\n");
		System.out.printf("                      1: 32x32 pixel 'file icon' (PNG only)\n");
		System.out.printf("                      2: Other file icon\n");
		System.out.printf("                      3: Cover (front)\n");
		System.out.printf("                      4: Cover (back)\n");
		System.out.printf("                      5: Leaflet page\n");
		System.out.printf("                      6: Media (e.g., label side of a CD)\n");
		System.out.printf("                      7: Lead artist/lead performer/soloist\n");
		System.out.printf("                      8: Artist/performer\n");
		System.out.printf("                      9: Conductor\n");
		System.out.printf("                      10: Band/Orchestra\n");
		System.out.printf("                      11: Composer\n");
		System.out.printf("                      12: Lyricist/text writer\n");
		System.out.printf("                      13: Recording location\n");
		System.out.printf("                      14: During recording\n");
		System.out.printf("                      15: During performance\n");
		System.out.printf("                      16: Movie/video screen capture\n");
		System.out.printf("                      17: A bright colored fish\n");
		System.out.printf("                      18: Illustration\n");
		System.out.printf("                      19: Band/artist logotype\n");
		System.out.printf("                      20: Publisher/studio logotype\n");
		System.out.printf("\n");
		System.out.printf("                      The default is 3 (front cover). There may only be\n");
		System.out.printf("                      one picture each of type 1 and 2 in a file.\n");
		System.out.printf("\n");
		System.out.printf("                      MIME-TYPE is optional. If left blank, it will be\n");
		System.out.printf("                      detected from the file. For best compatibility\n");
		System.out.printf("                      with players, use pictures with a MIME-TYPE of\n");
		System.out.printf("                      image/jpeg or image/png. The MIME-TYPE can also\n");
		System.out.printf("                      be -. to mean that FILENAME is actually a URL to\n");
		System.out.printf("                      an image, though this use is discouraged. The\n");
		System.out.printf("                      file at the URL will not be fetched. The URL\n");
		System.out.printf("                      itself is stored in the metadata.\n");
		System.out.printf("\n");
		System.out.printf("                      DESCRIPTION is optional. The default is an empty\n");
		System.out.printf("                      string.\n");
		System.out.printf("\n");
		System.out.printf("                      The next part specifies the resolution and color\n");
		System.out.printf("                      information. If the MIME-TYPE is image/jpeg,\n");
		System.out.printf("                      image/png, or image/gif, you can usually leave\n");
		System.out.printf("                      this empty and they can be detected from the\n");
		System.out.printf("                      file. Otherwise, you must specify the width in\n");
		System.out.printf("                      pixels, height in pixels, and color depth in\n");
		System.out.printf("                      bits-per-pixel. If the image has indexed colors\n");
		System.out.printf("                      you should also specify the number of colors\n");
		System.out.printf("                      used. If possible, these are checked against the\n");
		System.out.printf("                      file for accuracy.\n");
		System.out.printf("\n");
		System.out.printf("                      FILENAME is the path to the picture file to be\n");
		System.out.printf("                      imported, or the URL if the MIME-TYPE is -..\n");
		System.out.printf(" --padding n        Extra bytes to reserve for metadata (default: 512)\n");
		System.out.printf(" --discard-comments Don't keep metadata when transcoding\n");
		System.out.printf(" --discard-pictures Don't keep pictures when transcoding\n");
		System.out.printf("\nInput options:\n");
		System.out.printf(" --raw              Raw input\n");
		System.out.printf(" --raw-bits n       Set bits/sample for raw input (default: 16)\n");
		System.out.printf(" --raw-rate n       Set sampling rate for raw input (default: 48000)\n");
		System.out.printf(" --raw-chan n       Set number of channels for raw input (default: 2)\n");
		System.out.printf(" --raw-endianness n 1 for bigendian, 0 for little (defaults to 0)\n");
		System.out.printf(" --ignorelength     Always ignore the datalength in Wave headers\n");
	}

	@SuppressWarnings("boxing")
	private static final void print_time( double seconds )
	{
		final long hours = (long)(seconds / 3600.);
		seconds -= (double)hours * 3600.;
		final long minutes = (long)(seconds / 60.);
		seconds -= (double)minutes * 60.;
		if( hours != 0 ) {
			System.err.printf(" %d hour%s%s", hours, hours > 1 ? "s" : "", minutes != 0 && (seconds <= 0) ? " and" : "");
		}
		if( minutes != 0 ) {
			System.err.printf("%s%d minute%s%s",
				hours != 0 ? ", " : " ", minutes, minutes > 1 ? "s" : "", hours == 0 && seconds > 0 ? " and" : seconds > 0 ? ", and" : "");
		}
		if( seconds > 0 ) {
			System.err.printf(" %.4g second%s", seconds, seconds != 1 ? "s" : "");
		}
	}

	// private static final Jinput_format raw_format = new Jinput_format( null, 0, raw_open, wav_close, "raw", "RAW file reader");

	private static final int ENCODER_STRING_MAX_LENGTH = 1024;

	@SuppressWarnings("boxing")
	public static final void main( final String[] args ) // int main( int argc, char **argv )
	{
		final LongOpt long_options[] =
			{
				new LongOpt( "quiet", LongOpt.NO_ARGUMENT, null, 0 ),
				new LongOpt( "bitrate", LongOpt.REQUIRED_ARGUMENT, null, 0 ),
				new LongOpt( "hard-cbr", LongOpt.NO_ARGUMENT, null, 0 ),
				new LongOpt( "vbr", LongOpt.NO_ARGUMENT, null, 0 ),
				new LongOpt( "cvbr", LongOpt.NO_ARGUMENT, null, 0 ),
				new LongOpt( "comp", LongOpt.REQUIRED_ARGUMENT, null, 0 ),
				new LongOpt( "complexity", LongOpt.REQUIRED_ARGUMENT, null, 0 ),
				new LongOpt( "framesize", LongOpt.REQUIRED_ARGUMENT, null, 0 ),
				new LongOpt( "expect-loss", LongOpt.REQUIRED_ARGUMENT, null, 0 ),
				new LongOpt( "downmix-mono", LongOpt.NO_ARGUMENT, null, 0 ),
				new LongOpt( "downmix-stereo", LongOpt.NO_ARGUMENT, null, 0 ),
				new LongOpt( "no-downmix", LongOpt.NO_ARGUMENT, null, 0 ),
				new LongOpt( "max-delay", LongOpt.REQUIRED_ARGUMENT, null, 0 ),
				new LongOpt( "serial", LongOpt.REQUIRED_ARGUMENT, null, 0 ),
				new LongOpt( "save-range", LongOpt.REQUIRED_ARGUMENT, null, 0 ),
				new LongOpt( "set-ctl-int", LongOpt.REQUIRED_ARGUMENT, null, 0 ),
				new LongOpt( "help", LongOpt.NO_ARGUMENT, null, 0 ),
				new LongOpt( "raw", LongOpt.NO_ARGUMENT, null, 0 ),
				new LongOpt( "raw-bits", LongOpt.REQUIRED_ARGUMENT, null, 0 ),
				new LongOpt( "raw-rate", LongOpt.REQUIRED_ARGUMENT, null, 0 ),
				new LongOpt( "raw-chan", LongOpt.REQUIRED_ARGUMENT, null, 0 ),
				new LongOpt( "raw-endianness", LongOpt.REQUIRED_ARGUMENT, null, 0 ),
				new LongOpt( "ignorelength", LongOpt.NO_ARGUMENT, null, 0 ),
				new LongOpt( "rate", LongOpt.REQUIRED_ARGUMENT, null, 0 ),
				new LongOpt( "version", LongOpt.NO_ARGUMENT, null, 0 ),
				new LongOpt( "version-short", LongOpt.NO_ARGUMENT, null, 0 ),
				new LongOpt( "comment", LongOpt.REQUIRED_ARGUMENT, null, 0 ),
				new LongOpt( "artist", LongOpt.REQUIRED_ARGUMENT, null, 0 ),
				new LongOpt( "title", LongOpt.REQUIRED_ARGUMENT, null, 0 ),
				new LongOpt( "album", LongOpt.REQUIRED_ARGUMENT, null, 0 ),
				new LongOpt( "date", LongOpt.REQUIRED_ARGUMENT, null, 0 ),
				new LongOpt( "genre", LongOpt.REQUIRED_ARGUMENT, null, 0 ),
				new LongOpt( "picture", LongOpt.REQUIRED_ARGUMENT, null, 0 ),
				new LongOpt( "padding", LongOpt.REQUIRED_ARGUMENT, null, 0 ),
				new LongOpt( "discard-comments", LongOpt.NO_ARGUMENT, null, 0 ),
				new LongOpt( "discard-pictures", LongOpt.NO_ARGUMENT, null, 0 ),
				// new LongOpt( 0, 0, 0, 0}
			};
		/*Settings*/
		boolean  quiet = false;
		int      bitrate = -1;
		int      rate = 48000;
		int      coding_rate = 48000;
		int      frame_size = 960;
		int      chan = 2;
		boolean  with_hard_cbr = false;
		boolean  with_cvbr = false;
		int      expect_loss = 0;
		int      complexity = 10;
		int      downmix = 0;
		// int      opt_ctls = 0;// java: replaced by the opt_ctls_ctlval.length
		int      max_ogg_delay = 48000;  /*48kHz samples*/
		int      comment_padding = 512;
		int      lookahead = 0;

		String inFile = null, outFile = null, range_file = null;
		OutputStream fout = null;
		PrintStream frange = null;
		InputStream fin = null;
		//
		int[] opt_ctls_ctlval = new int[0];// java: opt_ctls_ctlval.length uses as opt_ctls
		// final Jinput_format in_format = null;// java don't need, using java audio spi
		/*I/O*/
		final Joe_enc_opt inopt = new Joe_enc_opt();
		inopt.channels = chan;
		inopt.rate = coding_rate = rate;
		/* 0 dB gain is recommended unless you know what you're doing */
		inopt.gain = 0;
		inopt.samplesize = 16;
		inopt.endianness = 0;
		inopt.rawmode = false;
		inopt.ignorelength = 0;
		inopt.copy_comments = true;
		inopt.copy_pictures = true;
try {
		long start_time = System.currentTimeMillis() / 1000;
		int serialno = new java.util.Random( start_time ).nextInt( 0x8000 );

		final String opus_version = Jcelt.opus_get_version_string();
		/*Vendor string should just be the encoder library,
		the ENCODER comment specifies the tool used.*/
		comment_init( inopt, opus_version );
		comment_add( inopt, "ENCODER", String.format("opusenc from %s %s", Jtools.PACKAGE_NAME, Jtools.PACKAGE_VERSION ) );

		/*Process command-line options*/
		String ENCODER_string = "";
		int cline_size = 0;
		final Getopt g = new Getopt( CLASS_NAME, args, "hV", long_options );
		g.setOpterr( false );
		int c;
		while( (c = g.getopt()) != -1 ) {
			boolean save_cmd = true;
			final String optarg = g.getOptarg();
			switch( c ) {
			case 0:
				final String name = long_options[ g.getLongind() ].getName();// java
				if( name.compareTo("quiet") == 0 ) {// java: switch( string ) starts from jre7
					quiet = true;
				} else if( name.compareTo("bitrate") == 0 ) {
					bitrate = (int)(Float.parseFloat( optarg ) * 1000.f);
				} else if( name.compareTo("hard-cbr") == 0 ) {
					with_hard_cbr = true;
					with_cvbr = false;
				} else if( name.compareTo("cvbr") == 0 ) {
					with_cvbr = true;
					with_hard_cbr = false;
				} else if( name.compareTo("vbr") == 0 ) {
					with_cvbr = false;
					with_hard_cbr = false;
				} else if( name.compareTo("help") == 0 ) {
					usage();
					System.exit( EXIT_SUCCESS );
					return;
				} else if( name.compareTo("version") == 0 ) {
					opustoolsversion( opus_version );
					System.exit( EXIT_SUCCESS );
				} else if( name.compareTo("version-short") == 0 ) {
					opustoolsversion_short( opus_version );
					System.exit( EXIT_SUCCESS );
				} else if( name.compareTo("ignorelength") == 0 ) {
					inopt.ignorelength = 1;
				} else if( name.compareTo("raw") == 0 ) {
					inopt.rawmode = true;
					save_cmd = false;
				} else if( name.compareTo("raw-bits") == 0 ) {
					inopt.rawmode = true;
					inopt.samplesize = Integer.parseInt( optarg );
					save_cmd = false;
					if( inopt.samplesize != 8 && inopt.samplesize != 16 && inopt.samplesize != 24 ) {
						System.err.printf("Invalid bit-depth: %s\n", optarg );
						System.err.printf("--raw-bits must be one of 8, 16, or 24\n");
						System.exit( EXIT_FAILURE );
						return;
					}
				} else if( name.compareTo("raw-rate") == 0 ) {
					inopt.rawmode = true;
					inopt.rate = Integer.parseInt( optarg );
					save_cmd = false;
				} else if( name.compareTo("raw-chan") == 0 ) {
					inopt.rawmode = true;
					inopt.channels = Integer.parseInt( optarg );
					save_cmd = false;
				} else if( name.compareTo("raw-endianness") == 0 ) {
					inopt.rawmode = true;
					inopt.endianness = Integer.parseInt( optarg );
					save_cmd = false;
				} else if( name.compareTo("downmix-mono") == 0 ) {
					downmix = 1;
				} else if( name.compareTo("downmix-stereo") == 0 ) {
					downmix = 2;
				} else if( name.compareTo("no-downmix") == 0 ) {
					downmix = -1;
				} else if( name.compareTo("expect-loss") == 0 ) {
					expect_loss = Integer.parseInt( optarg );
					if( expect_loss > 100 || expect_loss < 0 ) {
						System.err.printf("Invalid expect-loss: %s\n", optarg );
						System.err.printf("Expected loss is a percent and must be 0-100.\n");
						System.exit( EXIT_FAILURE );
						return;
					}
				} else if( name.compareTo("comp") == 0 ||
						name.compareTo("complexity") == 0 ) {
					complexity = Integer.parseInt( optarg );
					if( complexity > 10 || complexity < 0 ) {
						System.err.printf("Invalid complexity: %s\n", optarg );
						System.err.printf("Complexity must be 0-10.\n");
						System.exit( EXIT_FAILURE );
						return;
					}
				} else if( name.compareTo("framesize") == 0 ) {
					if( optarg.compareTo("2.5") == 0 ) {
						frame_size = 120;
					} else if( optarg.compareTo("5") == 0 ) {
						frame_size = 240;
					} else if( optarg.compareTo("10") == 0 ) {
						frame_size = 480;
					} else if( optarg.compareTo("20") == 0 ) {
						frame_size = 960;
					} else if( optarg.compareTo("40") == 0 ) {
						frame_size = 1920;
					} else if( optarg.compareTo("60") == 0 ) {
						frame_size = 2880;
					} else {
						System.err.printf("Invalid framesize: %s\n", optarg );
						System.err.printf("Framesize must be 2.5, 5, 10, 20, 40, or 60.\n");
						System.exit( EXIT_FAILURE );
						return;
					}
				} else if( name.compareTo("max-delay") == 0 ) {
					max_ogg_delay = (int)Math.floor( Double.parseDouble( optarg ) * 48. );
					if( max_ogg_delay < 0 || max_ogg_delay > 48000 ) {
						System.err.printf("Invalid max-delay: %s\n", optarg );
						System.err.printf("max-delay 0-1000 ms.\n");
						System.exit( EXIT_FAILURE );
						return;
					}
				} else if( name.compareTo("serial") == 0 ) {
					serialno = Integer.parseInt( optarg );
				} else if( name.compareTo("set-ctl-int") == 0 ) {
					final int len = optarg.length(), target;
					final int spos = optarg.indexOf('=');
					if( len < 3 || spos < 1 || spos >= len ) {
						System.err.printf( "Invalid set-ctl-int: %s\n", optarg );
						System.err.printf( "Syntax is --set-ctl-int intX = intY or\n");
						System.err.printf( "Syntax is --set-ctl-int intS:intX = intY\n");
						System.exit( EXIT_FAILURE );
						return;
					}
					int tpos = optarg.indexOf(':');
					if( tpos < 0 ) {
						target = -1;
						tpos = -1;
					} else {
						target = Integer.parseInt( optarg );
					}
					if( ( Integer.parseInt( optarg.substring( tpos + 1 ) ) & 1 ) != 0 ) {
						System.err.printf( "Invalid set-ctl-int: %s\n", optarg );
						System.err.printf( "libopus set CTL values are even.\n");
						System.exit( EXIT_FAILURE );
						return;
					}
					if( opt_ctls_ctlval.length == 0 ) {// if( opt_ctls == 0 ) {
						opt_ctls_ctlval = new int[ 3 ];
					} else {
						// opt_ctls_ctlval = Arrays.copyOf( opt_ctls_ctlval, (opt_ctls + 1) * 3 );
						opt_ctls_ctlval = Arrays.copyOf( opt_ctls_ctlval, opt_ctls_ctlval.length + 1 * 3 );
					}
					c = opt_ctls_ctlval.length * 3;// opt_ctls * 3;// java
					opt_ctls_ctlval[ c++ ] = target;
					opt_ctls_ctlval[ c++ ] = Integer.parseInt( optarg.substring( tpos + 1 ) );
					opt_ctls_ctlval[ c   ] = Integer.parseInt( optarg.substring( spos + 1 ) );
					// opt_ctls++;
				} else if( name.compareTo("save-range") == 0 ) {
					try {
						frange = new PrintStream( optarg );
						save_cmd = false;
					} catch(final FileNotFoundException fe) {
						System.err.printf("Could not open save-range file: %s\n", fe.getMessage() );
						System.err.printf("Must provide a writable file name.\n");
						System.exit( EXIT_FAILURE );
						return;
					}
					range_file = optarg;
				} else if( name.compareTo("comment") == 0 ) {
					save_cmd = false;
					if( optarg.indexOf('=') < 0 ) {
						System.err.printf( "Invalid comment: %s\n", optarg );
						System.err.printf( "Comments must be of the form name = value\n");
						System.exit( EXIT_FAILURE );
						return;
					}
					comment_add( inopt, null, optarg );
				} else if( name.compareTo("artist") == 0 ) {
					save_cmd = false;
					comment_add( inopt, "artist", optarg );
				} else if( name.compareTo("title") == 0 ) {
					save_cmd = false;
					comment_add( inopt, "title", optarg );
				} else if( name.compareTo("album") == 0 ) {
					save_cmd = false;
					comment_add( inopt, "album", optarg );
				} else if( name.compareTo("date") == 0 ) {
					save_cmd = false;
					comment_add( inopt, "date", optarg );
				} else if( name.compareTo("genre") == 0 ) {
					save_cmd = false;
					comment_add( inopt, "genre", optarg );
				} else if( name.compareTo("picture") == 0 ) {
					/* final byte[] error_message;
					byte[] picture_data;
					save_cmd = false;
					picture_data = parse_picture_specification( optarg, error_message, seen_file_icons );
					if( picture_data == null ) {
						System.err.printf("Error parsing picture option: %s\n", error_message );
						System.exit( EXIT_FAILURE );
						return;
					}
					comment_add( inopt, "METADATA_BLOCK_PICTURE", picture_data );
					picture_data = null; */
					System.err.printf("picture not implemented\n");// TODO add picture support
					System.exit( EXIT_FAILURE );
				} else if( name.compareTo("padding") == 0 ) {
					comment_padding = Integer.parseInt( optarg );
				} else if( name.compareTo("discard-comments") == 0 ) {
					inopt.copy_comments = false;
					inopt.copy_pictures = false;
				} else if( name.compareTo("discard-pictures") == 0 ) {
					inopt.copy_pictures = false;
				}
				/*Commands whos arguments would leak file paths or just end up as metadata
				should have save_cmd = 0;  to prevent them from being saved in the
				command-line tag.*/
				break;
			case 'h':// FIXME frange not closing here and later on an error
				usage();
				System.exit( EXIT_SUCCESS );
				break;
			case 'V':
				opustoolsversion( opus_version );
				System.exit( EXIT_SUCCESS );
				break;
			case '?':
				usage();
				System.exit( EXIT_FAILURE );
				return;
				// break;
			}// switch
			if( save_cmd && cline_size < ENCODER_STRING_MAX_LENGTH ) {
				ENCODER_string += String.format("%s--%s", cline_size == 0 ? "": " ", long_options[ g.getLongind() ].getName() );
				int ret = ENCODER_string.length();
				if( ret < 0 || ret >= (ENCODER_STRING_MAX_LENGTH - cline_size) ) {
					cline_size = ENCODER_STRING_MAX_LENGTH;
				} else {
					cline_size += ret;
					if( optarg != null ) {
						ENCODER_string += String.format(" %s", optarg );
						ret = ENCODER_string.length();
						if( ret < 0 || ret >= (ENCODER_STRING_MAX_LENGTH - cline_size) ) {
							cline_size = ENCODER_STRING_MAX_LENGTH;
						} else {
							cline_size += ret;
						}
					}
				}
			}
		}// while opt

		final int optind = g.getOptind();
		if( args.length - optind != 2 ) {
			usage();
			System.exit( EXIT_FAILURE );// FIXME frange not closing here and later on an error
			return;
		}
		inFile = args[optind];
		outFile = args[optind + 1];

		if( cline_size > 0 ) {
			comment_add( inopt, "ENCODER_OPTIONS", ENCODER_string );
		}

		if( inFile.compareTo("-") == 0 ) {
			// fin = stdin;
			System.err.print("stdin input not implemented\n" );
			System.exit( EXIT_FAILURE );
			return;
		} else {
			try {
				fin = new BufferedInputStream( new FileInputStream( inFile ), 65536 * 2 );
			} catch(final Exception e) {
				System.err.printf("Can not open input file: %s\n", e.getMessage() );
				System.exit( EXIT_FAILURE );
				return;
			}
		}

		if( inopt.rawmode ) {
			// in_format = raw_format;
			// in_format.open_func( fin, inopt, null, 0 );// TODO raw format supporting
			System.err.print("rawmode input not implemented\n");
			System.exit( EXIT_FAILURE );
			return;
		} else {
			// in_format = open_audio_file( fin, inopt );
			//
			AudioInputStream in = null;
			AudioInputStream din = null;
			try {
				in = AudioSystem.getAudioInputStream( fin );
				if( in != null ) {
					final AudioFormat audio_in_format = in.getFormat();
					final int channels = audio_in_format.getChannels();
					final AudioFormat decoded_format = new AudioFormat(
							AudioFormat.Encoding.PCM_SIGNED,
							audio_in_format.getSampleRate(),
							16, channels, channels * (16 / 8),
							audio_in_format.getSampleRate(),
							false );
					din = AudioSystem.getAudioInputStream( decoded_format, in );
					//
					inopt.rate = (int)audio_in_format.getSampleRate();
					inopt.channels = channels;
					inopt.samplesize = 16;
					inopt.total_samples_per_channel = 0;
					// inopt.readdata = din;
					inopt.read_samples = new Jaudio_spi_reader( din, inopt, false, false );
				}
			} catch(final Exception e) {
				System.err.printf("Error parsing input file: %s, %s\n", inFile, e.getMessage() );
				System.exit( EXIT_FAILURE );
				return;
			} finally {
			}
		}

		/* if( null == in_format ) {
			System.err.printf("Error parsing input file: %s\n", inFile );
			System.exit( EXIT_FAILURE );
			return;
		}*/

		if( downmix == 0 && inopt.channels > 2 && bitrate > 0 && bitrate < (16000 * inopt.channels) ) {
			if( ! quiet ) {
				System.err.printf("Notice: Surround bitrate less than 16kbit/sec/channel, downmixing.\n");
			}
			downmix = inopt.channels > 8 ? 1 : 2;
		}

		if( downmix > 0 && downmix < inopt.channels ) {// FIXME downmix is incorrect name for var
			downmix = Jdownmix.setup_downmix( inopt, downmix );
		} else {
			downmix = 0;
		}

		rate = inopt.rate;
		chan = inopt.channels;
		inopt.skip = 0;

		/* In order to code the complete length we'll need to do a little padding */
		// final long original_samples = 0;// java made member
		// java. setup moved down, to avoid link padder and inopt.
		// final Jopusenc enc = new Jopusenc();
		// Jpadder.setup_padder( inopt, enc );// ( inopt, original_samples );

		if( rate > 24000 ) {
			coding_rate = 48000;
		} else if( rate > 16000 ) {
			coding_rate = 24000;
		} else if( rate > 12000 ) {
			coding_rate = 16000;
		} else if( rate > 8000 ) {
			coding_rate = 12000;
		} else {
			coding_rate = 8000;
		}

		frame_size = frame_size / (48000 / coding_rate);

		/*Scale the resampler complexity, but only for 48000 output because
		the near-cutoff behavior matters a lot more at lower rates.*/
		// java: moved down, to set after padder
		//if( rate != coding_rate ) {
		//	Jresampler.setup_resample( inopt, coding_rate == 48000 ? (complexity + 1) / 2 : 5, coding_rate );
		//}

		if( rate != coding_rate && complexity != 10 && ! quiet ) {
			System.err.printf("Notice: Using resampling with complexity < 10.\n");
			System.err.printf("Opusenc is fastest with 48, 24, 16, 12, or 8kHz input.\n\n");
		}

		/*OggOpus headers*/ /*FIXME: broke forcemono*/
		final JOpusHeader header = new JOpusHeader();
		header.channels = chan;
		header.channel_mapping = header.channels > 8 ? 255 : chan > 2 ? 1 : 0;
		header.input_sample_rate = rate;// FIXME is this correct? may be inopt.rate? sample rate is incorrect if uses resampler
		header.gain = inopt.gain;

		/*Initialize OPUS encoder*/
		/*Framesizes  < 10ms can only use the MDCT modes, so we switch on RESTRICTED_LOWDELAY
		to save the extra 2.5ms of codec lookahead when we'll be using only small frames.*/
		final int[] pret = new int[1];// java
		final Jms_encoder_data_aux aux = new Jms_encoder_data_aux();// java
		JOpusMSEncoder st = JOpusMSEncoder.opus_multistream_surround_encoder_create( coding_rate, chan, header.channel_mapping, aux,
				header.stream_map, frame_size < 480 / (48000 / coding_rate) ? Jopus_defines.OPUS_APPLICATION_RESTRICTED_LOWDELAY : Jopus_defines.OPUS_APPLICATION_AUDIO, pret );
		header.nb_streams = aux.streams;// java
		header.nb_coupled = aux.coupled_streams;// java
		if( pret[0] != Jopus_defines.OPUS_OK ) {
			System.err.printf( "Error cannot create encoder: %s\n", Jcelt.opus_strerror( pret[0] ) );
			System.exit( EXIT_FAILURE );
			return;
		}

		if( bitrate < 0 ) {
			/*Lower default rate for sampling rates [8000 - 44100) by a factor of (rate + 16k) / (64k) */
			bitrate = ( (64000 * header.nb_streams + 32000 * header.nb_coupled ) *
					( Math.min( 48, Math.max( 8, ((rate < 44100 ? rate : 48000) + 1000) / 1000)) + 16) + 32) >> 6;
		}

		if( bitrate > (1024000 * chan) || bitrate < 500 ) {
			System.err.printf("Error: Bitrate %d bits/sec is insane.\nDid you mistake bits for kilobits?\n", bitrate );
			System.err.printf("--bitrate values from 6-256 kbit/sec per channel are meaningful.\n");
			System.exit( EXIT_FAILURE );
			return;
		}
		bitrate = Math.min( chan * 256000, bitrate );

		final Object[] request = new Object[1];// java helper
		int ret = st.opus_multistream_encoder_ctl( Jopus_defines.OPUS_SET_BITRATE, bitrate );
		if( ret != Jopus_defines.OPUS_OK ) {
			System.err.printf("Error OPUS_SET_BITRATE returned: %s\n", Jcelt.opus_strerror( ret ) );
			System.exit( EXIT_FAILURE );
			return;
		}

		st.opus_multistream_encoder_ctl( Jopus_defines.OPUS_SET_VBR, ! with_hard_cbr );
		if( ret != Jopus_defines.OPUS_OK ) {
			System.err.printf("Error OPUS_SET_VBR returned: %s\n", Jcelt.opus_strerror( ret ) );
			System.exit( EXIT_FAILURE );
			return;
		}

		if( ! with_hard_cbr ) {
			ret = st.opus_multistream_encoder_ctl( Jopus_defines.OPUS_SET_VBR_CONSTRAINT, with_cvbr );
			if( ret != Jopus_defines.OPUS_OK ) {
				System.err.printf("Error OPUS_SET_VBR_CONSTRAINT returned: %s\n", Jcelt.opus_strerror( ret ) );
				System.exit( EXIT_FAILURE );
				return;
			}
		}

		ret = st.opus_multistream_encoder_ctl( Jopus_defines.OPUS_SET_COMPLEXITY, complexity );
		if( ret != Jopus_defines.OPUS_OK ) {
			System.err.printf("Error OPUS_SET_COMPLEXITY returned: %s\n", Jcelt.opus_strerror( ret ) );
			System.exit( EXIT_FAILURE );
			return;
		}

		ret = st.opus_multistream_encoder_ctl( Jopus_defines.OPUS_SET_PACKET_LOSS_PERC, expect_loss );
		if( ret != Jopus_defines.OPUS_OK ) {
			System.err.printf("Error OPUS_SET_PACKET_LOSS_PERC returned: %s\n", Jcelt.opus_strerror( ret ) );
			System.exit( EXIT_FAILURE );
			return;
		}

if( Jopus_defines.OPUS_SET_LSB_DEPTH != 0 ) {
		ret = st.opus_multistream_encoder_ctl( Jopus_defines.OPUS_SET_LSB_DEPTH, Math.max( 8, Math.min( 24, inopt.samplesize ) ) );
		if( ret != Jopus_defines.OPUS_OK ) {
			System.err.printf("Warning OPUS_SET_LSB_DEPTH returned: %s\n", Jcelt.opus_strerror( ret ) );
		}
}

		/*This should be the last set of CTLs, except the lookahead get, so it can override the defaults.*/
		for( int i3 = 0; i3 < opt_ctls_ctlval.length/* opt_ctls */; i3 += 3 ) {
			final int target = opt_ctls_ctlval[ i3 ];
			if( target == -1 ) {
				ret = st.opus_multistream_encoder_ctl( opt_ctls_ctlval[ i3 + 1 ], opt_ctls_ctlval[ i3 + 2 ] );
				if( ret != Jopus_defines.OPUS_OK ) {
					System.err.printf("Error opus_multistream_encoder_ctl( st, %d, %d ) returned: %s\n",
							opt_ctls_ctlval[ i3 + 1 ], opt_ctls_ctlval[ i3 + 2 ], Jcelt.opus_strerror( ret ) );
					System.exit( EXIT_FAILURE );
					return;
				}
			} else if( target < header.nb_streams ) {
				st.opus_multistream_encoder_ctl( JOpusMSEncoder.OPUS_MULTISTREAM_GET_ENCODER_STATE, i3 / 3, request );
				final JOpusEncoder oe = (JOpusEncoder)request[0];// java
				ret = oe.opus_encoder_ctl( opt_ctls_ctlval[ i3 + 1 ], opt_ctls_ctlval[ i3 + 2 ] );
				if( ret != Jopus_defines.OPUS_OK ) {
					System.err.printf("Error opus_encoder_ctl( st[%d], %d, %d ) returned: %s\n",
							target, opt_ctls_ctlval[ i3 + 1 ], opt_ctls_ctlval[ i3 + 2 ], Jcelt.opus_strerror( ret ) );
					System.exit( EXIT_FAILURE );
					return;
				}
			} else {
				System.err.printf("Error --set-ctl-int target stream %d is higher than the maximum stream number %d.\n", target, header.nb_streams - 1 );
				System.exit( EXIT_FAILURE );
				return;
			}
		}

		/*We do the lookahead check late so user CTLs can change it*/
		ret = st.opus_multistream_encoder_ctl( Jopus_defines.OPUS_GET_LOOKAHEAD, request );
		lookahead = ((Integer)request[0]).intValue();// java
		if( ret != Jopus_defines.OPUS_OK ) {
			System.err.printf("Error OPUS_GET_LOOKAHEAD returned: %s\n", Jcelt.opus_strerror( ret ) );
			System.exit( EXIT_FAILURE );
			return;
		}
		//
		final Jopusenc enc = new Jopusenc();// java. to hold original_samples
		final Jpadder padder = Jpadder.setup_padder( inopt, enc );// ( inopt, original_samples );
		if( rate != coding_rate ) {
			Jresampler.setup_resample( inopt, coding_rate == 48000 ? (complexity + 1) >> 1 : 5, coding_rate );
		}
		inopt.skip += lookahead;
		/*Regardless of the rate we're coding at the ogg timestamping/skip is
		always timed at 48000.*/
		header.preskip = (int)((double)inopt.skip * (48000. / (double)coding_rate));
		/* Extra samples that need to be read to compensate for the pre-skip */
		padder.set_extra_samples( /* inopt.extraout = */ (int)((double)header.preskip * ((double)rate / 48000.)) );

		if( ! quiet ) {
			System.err.printf("Encoding using %s", opus_version );
			st.opus_multistream_encoder_ctl( Jopus_defines.OPUS_GET_APPLICATION, request );
			final int opus_app = ((Integer)request[0]).intValue();// java
			if( opus_app == Jopus_defines.OPUS_APPLICATION_VOIP ) {
				System.err.printf(" (VoIP)\n");
			} else if( opus_app == Jopus_defines.OPUS_APPLICATION_AUDIO ) {
				System.err.printf(" (audio)\n");
			} else if( opus_app == Jopus_defines.OPUS_APPLICATION_RESTRICTED_LOWDELAY ) {
				System.err.printf(" (low-delay)\n");
			} else {
				System.err.printf(" (unknown)\n");
			}
			System.err.printf("-----------------------------------------------------\n");
			System.err.printf("   Input: %.6gkHz %d channel%s\n", header.input_sample_rate / 1000., chan, chan < 2 ? "": "s");
			System.err.printf("  Output: %d channel%s (", header.channels, header.channels < 2 ? "" : "s");
			if( header.nb_coupled > 0 ) {
				System.err.printf("%d coupled", header.nb_coupled << 1 );
			}
			if( header.nb_streams - header.nb_coupled > 0 ) {
				System.err.printf("%s%d uncoupled", header.nb_coupled > 0 ? ",  " : "", header.nb_streams - header.nb_coupled );
			}
			System.err.printf(")\n          %.2gms packets, %.6gkbit/sec%s\n",
					frame_size / (coding_rate / 1000.), bitrate / 1000., with_hard_cbr ? " CBR" : with_cvbr ? " CVBR" : " VBR");
			System.err.printf(" Preskip: %d\n", header.preskip );

			if( frange != null ) {
				System.err.printf("         Writing final range file %s\n", range_file );
			}
			System.err.printf("\n");
		}

		if( outFile.compareTo("-") == 0 ) {
			// fout = stdout;
			System.err.printf("stdout output not implemented %s\n" );
			System.exit( EXIT_FAILURE );
			return;
		} else {
			try {
				fout = new FileOutputStream( outFile );
			} catch(final Exception e) {
				System.err.printf("Can not open output file: %s\n", e.getMessage() );
				System.exit( EXIT_FAILURE );
				return;
			}
		}

		/*Initialize Ogg stream struct*/
		final Jogg_stream_state   os = new Jogg_stream_state();
		final Jogg_page           og = new Jogg_page();
		final Jogg_packet         op = new Jogg_packet();
		if( os.ogg_stream_init( serialno ) == -1 ) {
			System.err.printf("Error: stream init failed\n");
			System.exit( EXIT_FAILURE );
			return;
		}

		/*Counters*/
		long  nb_encoded = 0;
		long  bytes_written = 0;
		long  pages_out = 0;
		long  total_bytes = 0;
		int   peak_bytes = 0;
		long  last_spin = 0;
		/*Write header*/
		{
			final byte header_data[] = new byte[19 + 255];// FIXME header.stream map has size 255
			final int packet_size = header.opus_header_to_packet( header_data, 100 );
			op.packet_base = header_data;
			op.packet = 0;
			op.bytes = packet_size;
			op.b_o_s = true;
			op.e_o_s = false;
			op.granulepos = 0;
			op.packetno = 0;
			os.ogg_stream_packetin( op );

			while( ( ret = os.ogg_stream_flush( og ) ) != 0 ) {
				if( 0 == ret ) {
					break;
				}
				ret = oe_write_page( og, fout );
				if( ret != og.header_len + og.body_len ) {
					System.err.printf("Error: failed writing header to output stream\n");
					System.exit( EXIT_FAILURE );
					return;
				}
				bytes_written += ret;
				pages_out++;
			}

			comment_pad( inopt, comment_padding );
			op.packet_base = inopt.comments;
			op.packet = 0;
			op.bytes = inopt.comments_length;
			op.b_o_s = false;
			op.e_o_s = false;
			op.granulepos = 0;
			op.packetno = 1;
			os.ogg_stream_packetin( op );
		}

		/* writing the rest of the opus header packets */
		while( ( ret = os.ogg_stream_flush( og ) ) != 0 ) {
			if( 0 == ret ) {
				break;
			}
			ret = oe_write_page( og, fout );
			if( ret != og.header_len + og.body_len ) {
				System.err.printf("Error: failed writing header to output stream\n");
				System.exit( EXIT_FAILURE );
				return;
			}
			bytes_written += ret;
			pages_out++;
		}

		inopt.comments = null;

		final float[] input = new float[ frame_size * chan ];
		/* if( input == null ) {
			System.err.printf("Error: couldn't allocate sample buffer.\n");
			System.exit( EXIT_FAILURE );
			return;
		}*/

		/*Main encoding loop (one frame per iteration) */
		int min_bytes, max_frame_bytes;
		min_bytes = max_frame_bytes = (1275 * 3 + 7) * header.nb_streams;
		final byte[] packet = new byte[ max_frame_bytes ];
		/* if( packet == null ) {
			System.err.printf("Error allocating packet buffer.\n");
			System.exit( EXIT_FAILURE );
			return;
		}*/
		int last_spin_len = 0;
		boolean eos = false;
		long last_granulepos = 0;
		long enc_granulepos = 0;
		int  last_segments = 0;
		int nb_samples = -1;
		int id = -1;// FIXME better set to 1 to remove op.packetno = 2 + id;
		while( ! op.e_o_s ) {
			id++;

			if( nb_samples < 0 ) {
				nb_samples = inopt.read_samples.audio_read_func( /* inopt.readdata,*/ input, 0, frame_size );
				op.e_o_s = nb_samples < frame_size;
			}
			op.e_o_s |= eos;

			if( start_time == 0 ) {
				start_time = System.currentTimeMillis();
			}

			final int cur_frame_size = frame_size;// FIXME the same, can be used frame_size

			/*No fancy end padding, just fill with zeros for now.*/
			if( nb_samples < cur_frame_size ) {
				for( int i = nb_samples * chan, ie = cur_frame_size * chan; i < ie; i++ ) {
					input[i] = 0;
				}
			}

			/*Encode current frame*/
			// VG_UNDEF( packet, max_frame_bytes );
			// VG_CHECK( input, sizeof( float ) *chan*cur_frame_size );
			final int nbBytes = st.opus_multistream_encode_float( input, cur_frame_size, packet, max_frame_bytes );
			if( nbBytes < 0 ) {
				System.err.printf( "Encoding failed: %s. Aborting.\n", Jcelt.opus_strerror( nbBytes ) );
				break;
			}

			// VG_CHECK( packet, nbBytes );
			// VG_UNDEF( input, sizeof( float ) *chan*cur_frame_size );
			nb_encoded += cur_frame_size;
			enc_granulepos += cur_frame_size * 48000 / coding_rate;
			total_bytes += nbBytes;
			final int size_segments = (nbBytes + 255) / 255;
			peak_bytes = Math.max( nbBytes, peak_bytes );
			min_bytes = Math.min( nbBytes, min_bytes );

			if( frange != null ) {
				final long rngs[] = new long[256];
				for( int i = 0; i < header.nb_streams; i++ ) {
					ret = st.opus_multistream_encoder_ctl( JOpusMSEncoder.OPUS_MULTISTREAM_GET_ENCODER_STATE, i, request );
					final JOpusEncoder oe = (JOpusEncoder)request[0];// java
					ret = oe.opus_encoder_ctl( Jopus_defines.OPUS_GET_FINAL_RANGE, request );
					rngs[i] = ((Long)request[0]).longValue();// java
				}
				Jdiag_range.save_range( frange, cur_frame_size * (48000 / coding_rate), packet, 0, nbBytes,
								rngs, header.nb_streams );
			}

			/* Flush early if adding this packet would make us end up with a
			continued page which we wouldn't have otherwise. */
			while( (((size_segments <= 255) && (last_segments + size_segments > 255)) ||
					(enc_granulepos - last_granulepos > max_ogg_delay)) &&
					os.ogg_stream_flush_fill( og, 255 * 255 ) != 0 ) {
				if( og.ogg_page_packets() != 0 ) {
					last_granulepos = og.ogg_page_granulepos();
				}
				last_segments -= ((int)og.header_base[ og.header + 26 ]) & 0xff;
				ret = oe_write_page( og, fout );
				if( ret != og.header_len + og.body_len ) {
					System.err.printf("Error: failed writing data to output stream\n");
					System.exit( EXIT_FAILURE );
					return;
				}
				bytes_written += ret;
				pages_out++;
			}

			/* The downside of early reading is if the input is an exact
			multiple of the frame_size you'll get an extra frame that needs
			to get cropped off. The downside of late reading is added delay.
			If your ogg_delay is 120ms or less we'll assume you want the
			low delay behavior. */
			if( ( ! op.e_o_s ) && max_ogg_delay > 5760 ) {
				nb_samples = inopt.read_samples.audio_read_func( /* inopt.readdata,*/ input, 0, frame_size );
				if( nb_samples < frame_size ) {
					eos = true;
				}
				if( nb_samples == 0 ) {
					op.e_o_s = true;
				}
			} else {
				nb_samples = -1;
			}

			op.packet_base = packet;
			op.packet = 0;
			op.bytes = nbBytes;
			op.b_o_s = false;
			op.granulepos = enc_granulepos;
			if( op.e_o_s ) {
				/* We compute the final GP as ceil(len*48k/input_rate). When a resampling
				decoder does the matching floor(len*input/48k) conversion the length will
				be exactly the same as the input. */
				op.granulepos = ((enc.original_samples * 48000 + rate - 1) / rate) + header.preskip;
			}
			op.packetno = 2 + id;
			os.ogg_stream_packetin( op );
			last_segments += size_segments;

			/* If the stream is over or we're sure that the delayed flush will fire,
			go ahead and flush now to avoid adding delay. */
			while( 0 != (( op.e_o_s || ( enc_granulepos + (frame_size * 48000 / coding_rate) - last_granulepos > max_ogg_delay ) || (last_segments >= 255) ) ?
							os.ogg_stream_flush_fill( og, 255 * 255 ) :
							os.ogg_stream_pageout_fill( og, 255 * 255 )) ) {
				if( og.ogg_page_packets() != 0 ) {
					last_granulepos = og.ogg_page_granulepos();
				}
				last_segments -= ((int)og.header_base[ og.header + 26 ]) & 0xff;
				ret = oe_write_page( og, fout );
				if( ret != og.header_len + og.body_len ) {
					System.err.printf("Error: failed writing data to output stream\n");
					System.exit( EXIT_FAILURE );
					return;
				}
				bytes_written += ret;
				pages_out++;
			}

			if( ! quiet ) {
				final long stop_time = System.currentTimeMillis() / 1000;
				if( stop_time > last_spin ) {
					double estbitrate;
					final double coded_seconds = nb_encoded / (double)coding_rate;
					final double wall_time = (double)(stop_time - start_time) + 1e-6;
					final char spinner[] = {'|', '/', '-', '\\'};
					if( ! with_hard_cbr ) {
						final double tweight = 1. / (1. + Math.exp( -((coded_seconds / 10.) - 3.) ));
						estbitrate = ((double)total_bytes * 8.0 / coded_seconds ) * tweight + bitrate * (1. - tweight);
					} else {
						estbitrate = (nbBytes << 3) * ( (double)coding_rate / frame_size );
					}
					System.err.printf("\r");
					for( int i = 0; i < last_spin_len; i++ ) {
						System.err.printf(" ");
					}
					String sbuf;
					if( inopt.total_samples_per_channel > 0  &&  inopt.total_samples_per_channel < nb_encoded ) {
						sbuf = String.format("\r[%c] %02d%% ", spinner[ (int)last_spin & 3 ],
								(int)Math.floor( nb_encoded / (double)( inopt.total_samples_per_channel + inopt.skip ) * 100. ) );
					} else {
						sbuf = String.format("\r[%c] ", spinner[ (int)last_spin & 3 ] );
					}
					// last_spin_len = sbuf.length();
					sbuf += String.format("%02d:%02d:%02d.%02d %4.3gx realtime, %5.4gkbit/s",
							(int)(coded_seconds / 3600), (int)(coded_seconds / 60) % 60,
							(int)(coded_seconds) % 60, (int)(coded_seconds * 100) % 100,
							coded_seconds / wall_time, estbitrate / 1000. );
					System.err.printf("%s", sbuf );
					System.err.flush();
					last_spin_len = sbuf.length();
					last_spin = stop_time;
				}
			}
		}// while op eos
		final long stop_time = System.currentTimeMillis() / 1000;

		for( int i = 0; i < last_spin_len; i++ ) {
			System.err.printf(" ");
		}
		if( last_spin_len != 0 ) {
			System.err.printf("\r");
		}

		if( ! quiet ) {
			final double coded_seconds = nb_encoded / (double)coding_rate;
			final double wall_time = (double)(stop_time - start_time) + 1e-6;
			System.err.printf("Encoding complete                                    \n");
			System.err.printf("-----------------------------------------------------\n");
			System.err.printf("       Encoded:");
			print_time( coded_seconds );
			System.err.printf("\n       Runtime:");
			print_time( wall_time );
			System.err.printf("\n                (%.4gx realtime)\n", coded_seconds / wall_time );
			System.err.printf("         Wrote: %d bytes, %d packets, %d pages\n", bytes_written, id + 1, pages_out );
			System.err.printf("       Bitrate: %.6gkbit/s (without overhead)\n",
								total_bytes * 8.0 / ( coded_seconds ) / 1000.0 );
			System.err.printf(" Instant rates: %.6gkbit/s to %.6gkbit/s\n                (%d to %d bytes per packet)\n",
							min_bytes * 8 * ( (double)coding_rate / frame_size / 1000. ),
							peak_bytes * 8 * ( (double)coding_rate / frame_size / 1000. ), min_bytes,peak_bytes );
			System.err.printf("      Overhead: %.3g%% (container + metadata)\n", (bytes_written - total_bytes) / (double)bytes_written * 100. );
			System.err.printf("\n");
		}

		st = null;
		os.ogg_stream_clear();
		// packet = null;
		// input = null;
		// if( opt_ctls != 0 ) {
			opt_ctls_ctlval = null;
		//}

		if( rate != coding_rate ) {
			Jresampler.clear_resample( inopt );
		}
		Jpadder.clear_padder( inopt );
		if( downmix != 0 ) {
			Jdownmix.clear_downmix( inopt );
		}
		// in_format.close_func( inopt.readdata );
		inopt.read_samples.close();
} catch(final Exception e) {
	e.printStackTrace();
	System.exit( EXIT_FAILURE );
	return;
} finally {
		if( fin != null ) {
			try { fin.close(); } catch( final IOException e ) {}
		}
		if( fout != null ) {
			try { fout.close(); } catch( final IOException e ) {}
		}
		if( frange != null ) {
			frange.close();
		}
}
		System.exit( EXIT_SUCCESS );
		return;
	}

	/*
	Comments will be stored in the Vorbis style.
	It is describled in the "Structure" section of
	http://www.xiph.org/ogg/vorbis/doc/v-comment.html

	However, Opus and other non-vorbis formats omit the "framing_bit".

	The comment header is decoded as follows:
	1 )  [vendor_length] = read an unsigned integer of 32 bits
	2 )  [vendor_string] = read a UTF-8 vector as [vendor_length] octets
	3 )  [user_comment_list_length] = read an unsigned integer of 32 bits
	4 )  iterate [user_comment_list_length] times {
		5 )  [length] = read an unsigned integer of 32 bits
		6 )  this iteration's user comment = read a UTF-8 vector as [length] octets
		}
	7 )  done.
	*/

	private static final int readint( final byte[] buf, int base ) {
		int v = buf[base++] & 0xff;
		v |= ( buf[base++] << 8 ) & 0xff00;
		v |= ( buf[base++] << 16 ) & 0xff0000;
		v |= ( buf[base] << 24 ) & 0xff000000;
		return v;
	}

	private static final void writeint( final byte[] buf, int base, final int val ) {
		buf[base++] = (byte)val;
		buf[base++] = (byte)( val >> 8 );
		buf[base++] = (byte)( val >> 16 );
		buf[base] = (byte)( val >> 24 );
	}

	private static final void comment_init( final Joe_enc_opt inopt,// java comments and length replaced by inopt
			// final byte[] comments, int[] length,
			final String vendor_string )
	{
		/*The 'vendor' field should be the actual encoding library used.*/
		final int vendor_length = vendor_string.length();
		final int user_comment_list_length = 0;
		final int len = 8 + 4 + vendor_length + 4;
		final byte[] p = new byte[ len ];
		/* if( p == null ) {
			System.err.printf("malloc failed in comment_init()\n");
			System.exit( EXIT_FAILURE );
			return;
		}*/
		System.arraycopy( "OpusTags".getBytes(), 0, p, 0, 8 );
		writeint( p, 8, vendor_length );
		System.arraycopy( vendor_string.getBytes(), 0, p, 12, vendor_length );
		writeint( p, 12 + vendor_length, user_comment_list_length );

		inopt.comments_length = len;
		inopt.comments = p;
	}

	private static final int strlen(final byte[] str, int offset) {
		do {
			if( str[offset] == '\0' ) {
				return offset;
			}
			offset++;
		} while( offset < str.length );
		return offset;
	}
	private static final void comment_add( final Joe_enc_opt inopt,// java comments and length replaced by inopt
			// final byte[][]comments, final int[][] length,
			final String tag, final String val ) {
		try {
			comment_add( inopt, tag, val.getBytes("UTF-8") );
		} catch( final UnsupportedEncodingException e ) {
		}
	}
	/**
	 *
	 * @param inopt [out] byte array data, comment_length
	 * @param tag string only with ASCII characters
	 * @param val UTF-8 encoded string or binary data
	 */
	private static final void comment_add( final Joe_enc_opt inopt,// java comments and length replaced by inopt
			// final byte[][]comments, final int[][] length,
			final String tag, final byte[] val )
	{
		byte[] p = inopt.comments;
		final int vendor_length = readint( p, 8 );
		final int user_comment_list_length = readint( p, 8 + 4 + vendor_length );
		int tag_len = ( tag != null ? tag.length() + 1 : 0 );// +1 for '='
		final int val_len = strlen( val, 0 );
		final int len = inopt.comments_length + 4 + tag_len + val_len;

		p = Arrays.copyOf( p, len );
		if( p == null ) {
			System.err.printf( "realloc failed in comment_add()\n");
			System.exit( EXIT_FAILURE );
			return;
		}

		writeint( p, inopt.comments_length, tag_len + val_len );      /* length of comment */
		if( tag != null ) {
			/* comment tag */
			System.arraycopy( tag.getBytes(), 0, p, inopt.comments_length + 4, --tag_len );// java: tag_len - 1, because tag array has not 0 at the end
			p[ inopt.comments_length + 4 + tag_len++/* - 1*/ ] = '=';            /* separator */
		}
		System.arraycopy( val, 0, p, inopt.comments_length + 4 + tag_len, val_len ); /* comment */
		writeint( p, 8 + 4 + vendor_length, user_comment_list_length + 1 );

		inopt.comments_length = len;
		inopt.comments = p;
	}

	private static final void comment_pad(final Joe_enc_opt inopt,// java comments and length replaced by inopt
			// byte[][] comments, int[] length,
			final int amount )
	{
		if( amount > 0 ) {
			byte[] p = inopt.comments;
			/*Make sure there is at least amount worth of padding free, and
			round up to the maximum that fits in the current ogg segments.*/
			final int newlen = (inopt.comments_length + amount + 255) / 255 * 255 - 1;
			p = Arrays.copyOf( p, newlen );
			/* if( p == null ) {
				System.err.printf("realloc failed in comment_pad()\n");
				System.exit( EXIT_FAILURE );
				return;
			}
			 for( int i = inopt.comments_length; i < newlen; i++ ) {// java: already zeroed
				p[i] = 0;
			}*/
			inopt.comments = p;
			inopt.comments_length = newlen;
		}
	}

	// interface Isamples
	private long original_samples = 0;
	@Override
	public void addSamples(final int samples) {
		original_samples += (long)samples;
	}
}