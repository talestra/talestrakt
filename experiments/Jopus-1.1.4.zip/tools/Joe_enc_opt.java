package tools;

final class Joe_enc_opt {
	Jaudio_read_func read_samples;
	// Object readdata;
	long total_samples_per_channel;
	boolean rawmode;
	int channels;
	int rate;
	int gain;
	int samplesize;
	int endianness;
	byte[] infilename;
	int ignorelength;
	int skip;
	// int extraout;// java removed to avoid link with the padder
	byte[] comments;
	int comments_length;
	boolean copy_comments;
	boolean copy_pictures;
}
