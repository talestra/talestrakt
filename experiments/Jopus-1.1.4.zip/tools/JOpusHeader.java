package tools;

import java.util.Arrays;

/** Header contents:
  - "OpusHead" (64 bits)
  - version number (8 bits)
  - Channels C (8 bits)
  - Pre-skip (16 bits)
  - Sampling rate (32 bits)
  - Gain in dB (16 bits, S7.8)
  - Mapping (8 bits, 0=single stream (mono/stereo) 1=Vorbis mapping,
			 2..254: reserved, 255: multistream with no mapping)

  - if( mapping != 0)
	 - N = totel number of streams (8 bits)
	 - M = number of paired streams (8 bits)
	 - C times channel origin
		  - if( C < 2*M)
			 - stream = byte/2
			 - if( byte&0x1 == 0)
				 - left
			   else
				 - right
		  - else
			 - stream = byte-M
*/
final class JOpusHeader {
	/** This is just here because it's a convenient file linked by both opusenc and
	   opusdec (to guarantee this maps stays in sync). */
	static final int wav_permute_matrix[][] =// [8][8] =
		{
			{ 0 },              /* 1.0 mono   */
			{ 0, 1 },            /* 2.0 stereo */
			{ 0, 2, 1 },          /* 3.0 channel ('wide') stereo */
			{ 0, 1, 2, 3 },        /* 4.0 discrete quadraphonic */
			{ 0, 2, 1, 3, 4 },      /* 5.0 surround */
			{ 0, 2, 1, 4, 5, 3 },    /* 5.1 surround */
			{ 0, 2, 1, 5, 6, 4, 3 },  /* 6.1 surround */
			{ 0, 2, 1, 6, 7, 4, 5, 3 } /* 7.1 surround (classic theater 8-track) */
		};
	//
	int version;
	/** Number of channels: 1..255 */
	int channels;
	int preskip;
	int input_sample_rate;
	int gain; /* in dB S7.8 should be zero whenever possible */
	int channel_mapping;
	/* The rest is only used if channel_mapping != 0 */
	int nb_streams;
	int nb_coupled;
	final char stream_map[] = new char[255];
	//
	JOpusHeader() {
	}
	//
	private static final class JPacket {
		private final byte[] data;
		private final int maxlen;
		private int pos;
		//
		private JPacket(final byte[] b, final int off, final int len) {
			data = b;
			pos = off;
			maxlen = len;
		}
		private boolean write_chars(final byte[] str, final int nb_chars)
		{
			if( this.pos > this.maxlen - nb_chars ) {
				return false;
			}
			int j = this.pos;
			for( int i = 0; i < nb_chars; i++ ) {
				this.data[ j++ ] = str[i];
			}
			this.pos = j;
			return true;
		}
		private boolean write_char(final byte val)// java added
		{
			if( this.pos > this.maxlen - 1 ) {
				return false;
			}
			this.data[ this.pos++ ] = val;
			return true;
		}
		private final boolean write_uint32(final int val)
		{
			if( this.pos > this.maxlen - 4) {
				return false;
			}
			int i = this.pos;// java
			this.data[ i++ ] = (byte)(val      );
			this.data[ i++ ] = (byte)(val >> 8 );
			this.data[ i++ ] = (byte)(val >> 16);
			this.data[ i++ ] = (byte)(val >> 24);
			this.pos = i;
			return true;
		}

		private final boolean write_uint16(final int val)// short val
		{
			if( this.pos > this.maxlen - 2 ) {
				return false;
			}
			int i = this.pos;
			this.data[i++] = (byte)(val    );
			this.data[i++] = (byte)(val >> 8);
			this.pos = i;
			return true;
		}
	};

	private static final class JROPacket {
		private final byte[] data;
		private final int maxlen;
		private int pos;
		//
		private JROPacket(final byte[] b, final int off, final int len) {
			data = b;
			pos = off;
			maxlen = len;
		}
		private int read_uint32() throws ArrayIndexOutOfBoundsException
		{
			if( this.pos > this.maxlen - 4 ) {
				throw new ArrayIndexOutOfBoundsException( this.pos );// return 0;
			}
			int i = this.pos;
			int val =  (int)this.data[i++] & 0xff;
			val |= ((int)this.data[i++] & 0xff) <<  8;
			val |= ((int)this.data[i++] & 0xff) << 16;
			val |= ((int)this.data[i++] & 0xff) << 24;
			this.pos = i;
			// return 1;
			return val;
		}

		private int read_uint16() throws ArrayIndexOutOfBoundsException
		{
			if( this.pos > this.maxlen - 2 ) {
				throw new ArrayIndexOutOfBoundsException( this.pos );// return 0;
			}
			int i = this.pos;
			int val = (int)this.data[i++] & 0xff;
			val |= ((int)this.data[i++] & 0xff) << 8;
			this.pos = i;
			// return 1;
			return val;
		}

		private void read_chars(final byte[] str, final int nb_chars)
		{
			if( this.pos > this.maxlen - nb_chars ) {
				throw new ArrayIndexOutOfBoundsException( this.pos );// return 0;
			}
			for( int i = 0; i < nb_chars; i++ ) {
				str[i] = this.data[this.pos++];
			}
			// return 1;
		}
		private int read_char()
		{
			if( this.pos > this.maxlen - 1 ) {
				throw new ArrayIndexOutOfBoundsException( this.pos );// return 0;
			}
			return this.data[this.pos++] & 0xff;
		}
	};

	final boolean opus_header_parse(final byte[] packet, final int offset, final int len)
	{
		try {
			final JROPacket p = new JROPacket( packet, offset, len );

			final byte str[] = new byte[8];// str[8] = 0;// java already zeroed FIXME why 9? why need 0 at end?
			if( len < 19 ) {
				return false;
			}
			p.read_chars( str, 8 );
			if( ! Arrays.equals( str, "OpusHead".getBytes() ) ) {
				return false;
			}

			this.version = p.read_char();
			if( (this.version & 240) != 0 ) {
				return false;
			}

			this.channels = p.read_char();
			if( this.channels == 0) {
				return false;
			}

			this.preskip = p.read_uint16();

			this.input_sample_rate = p.read_uint32();

			this.gain = p.read_uint16();

			this.channel_mapping = p.read_char();

			if( this.channel_mapping != 0 )
			{
				int ch = p.read_char();

				if( ch < 1 ) {
					return false;
				}
				this.nb_streams = ch;

				ch = p.read_char();

				if( ch > this.nb_streams || (ch + this.nb_streams) > 255 ) {
					return false;
				}
				this.nb_coupled = ch;

				/* Multi-stream support */
				for( int i = 0; i < this.channels; i++ )
				{
					ch = p.read_char();
					if( ch > (this.nb_streams + this.nb_coupled) && ch != 255 ) {
						return false;
					}
					this.stream_map[i] = (char)ch;
				}
			} else {
				if( this.channels > 2 ) {
					return false;
				}
				this.nb_streams = 1;
				this.nb_coupled = this.channels > 1 ? 1 : 0;
				this.stream_map[0] = 0;
				this.stream_map[1] = 1;
			}
			/*For version 0/1 we know there won't be any more data
			so reject any that have data past the end.*/
			if( (this.version==0 || this.version==1) && p.pos != len) {
				return false;
			}
			return true;
		} catch(final ArrayIndexOutOfBoundsException e) {
			return false;
		}
	}

	final int opus_header_to_packet(final byte[] packet, final int len)
	{
		final JPacket p = new JPacket( packet, 0, len );

		if( len < 19 ) {
			return 0;
		}
		if( ! p.write_chars( "OpusHead".getBytes(), 8 ) ) {
			return 0;
		}
		/* Version is 1 */
		if( ! p.write_char( (byte)1 ) ) {
			return 0;
		}

		if( ! p.write_char( (byte)this.channels )) {
			return 0;
		}

		if( ! p.write_uint16( this.preskip ) ) {
			return 0;
		}

		if( ! p.write_uint32( this.input_sample_rate ) ) {
			return 0;
		}

		if( ! p.write_uint16( this.gain ) ) {
			return 0;
		}

		if( ! p.write_char( (byte)this.channel_mapping ) ) {
			return 0;
		}

		if( this.channel_mapping != 0 )
		{
			if( ! p.write_char( (byte)this.nb_streams ) ) {
				return 0;
			}

			if( ! p.write_char( (byte)this.nb_coupled ) ) {
				return 0;
			}

			/* Multi-stream support */
			for( int i = 0; i < this.channels; i++ )
			{
				if( ! p.write_char( (byte)this.stream_map[i] ) ) {// FIXME why no write_chars(&p, h.stream_map, this.channels)?
					return 0;
				}
			}
		}

		return p.pos;
	}
}
