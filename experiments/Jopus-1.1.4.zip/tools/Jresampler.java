package tools;

import java.io.IOException;

final class Jresampler implements Jaudio_read_func {
	private JSpeexResampler resampler;
	private Jaudio_read_func real_reader;
	// void *real_readdata;
	private float[] bufs;
	private int channels;
	private int bufpos;
	private int bufsize;
	// private boolean done;// FIXME unused
	//
	private Jresampler() {
	}
	static final int setup_resample(final Joe_enc_opt opt, final int complexity, final int outfreq) throws IllegalArgumentException {
		final Jresampler rs = new Jresampler();
		rs.bufsize = 5760 * 2; /* Have at least two output frames worth, just in case of ugly ratios */
		rs.bufpos = 0;

		rs.real_reader = opt.read_samples;
		// rs.real_readdata = opt.readdata;
		rs.channels = opt.channels;
		// rs.done = false;
		rs.resampler = JSpeexResampler.speex_resampler_init( rs.channels, opt.rate, outfreq, complexity );
		// if(err!=0)fprintf(stderr, _("resampler error: %s\n"), speex_resampler_strerror(err));

		opt.skip += rs.resampler.speex_resampler_get_output_latency();

		rs.bufs = new float[ rs.bufsize * opt.channels ];

		opt.read_samples = rs;// read_resampled;
		// opt.readdata = rs;
		if( opt.total_samples_per_channel != 0 ) {
			opt.total_samples_per_channel = (int)((float)opt.total_samples_per_channel *
							((float)outfreq / (float)opt.rate));
		}
		opt.rate = outfreq;

		return 0;
	}
	static final void clear_resample(final Joe_enc_opt opt) {
		final Jresampler rs = (Jresampler)opt.read_samples;// opt.readdata;
		opt.read_samples = rs.real_reader;
		// opt.readdata = rs.real_readdata;
		rs.resampler = null;
		rs.bufs = null;
		// rs = null;
	}
	// final int read_resampled(final float[] buffer, final int samples) {
	@Override
	public int audio_read_func(final float[] buffer, final int offset, final int samples) throws IOException {
		int out_samples = 0;
		final float[] pcmbuf = this.bufs;
		int inbuf = this.bufpos;
		final int nchannels = this.channels;// java
		while( out_samples < samples ) {
			int out_len = samples - out_samples;
			int reading = this.bufsize - inbuf;
			if( reading > 1024 ) {
				reading = 1024;
			}
			final int ret = this.real_reader.audio_read_func( pcmbuf, inbuf * nchannels, reading );
			inbuf += ret;
			int in_len = inbuf;
			final long tmp = this.resampler.speex_resampler_process_interleaved_float( pcmbuf, 0, in_len, buffer, offset + out_samples * nchannels, out_len );
			out_len = (int)tmp;
			in_len = (int)(tmp >> 32);
			out_samples += out_len;
			if( ret == 0 && in_len == 0 ) {
				for( int i = offset + out_samples * nchannels, ie = offset + samples * nchannels; i < ie; i++ ) {
					buffer[i] = 0;
				}
				this.bufpos = inbuf;
				return out_samples;
			}
			for( int i = 0, ie = nchannels * (inbuf - in_len), j = nchannels * in_len; i < ie; i++, j++ ) {
				pcmbuf[i] = pcmbuf[j];
			}
			inbuf -= in_len;
		}
		this.bufpos = inbuf;
		return out_samples;
	}

	@Override
	public void close() {
	}
}
