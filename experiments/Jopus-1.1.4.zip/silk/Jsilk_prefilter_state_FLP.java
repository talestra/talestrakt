package silk;

// structs_FLP.h

/** Prefilter state */
final class Jsilk_prefilter_state_FLP {
	private final float sLTP_shp[] = new float[ Jdefine.LTP_BUF_LENGTH ];
	final float sAR_shp[] = new float[ Jdefine.MAX_SHAPE_LPC_ORDER + 1 ];
	private int         sLTP_shp_buf_idx;
	private float       sLF_AR_shp;
	private float       sLF_MA_shp;
	float       sHarmHP;
	private int         rand_seed;
	int         lagPrev;
	//
	final void clear() {
		float[] buff = sLTP_shp;
		for( int i = 0, end = buff.length; i < end; i++ ) {
			buff[i] = 0;
		}
		buff = sAR_shp;
		for( int i = 0, end = buff.length; i < end; i++ ) {
			buff[i] = 0;
		}
		sLTP_shp_buf_idx = 0;
		sLF_AR_shp = 0;
		sLF_MA_shp = 0;
		sHarmHP = 0;
		rand_seed = 0;
		lagPrev = 0;
	}
	final void copyFrom(final Jsilk_prefilter_state_FLP p) {
		System.arraycopy( p.sLTP_shp, 0, sLTP_shp, 0, Jdefine.LTP_BUF_LENGTH );
		System.arraycopy( p.sAR_shp, 0, sAR_shp, 0, Jdefine.MAX_SHAPE_LPC_ORDER + 1 );
		sLTP_shp_buf_idx = p.sLTP_shp_buf_idx;
		sLF_AR_shp = p.sLF_AR_shp;
		sLF_MA_shp = p.sLF_MA_shp;
		sHarmHP = p.sHarmHP;
		rand_seed = p.rand_seed;
		lagPrev = p.lagPrev;
	}
	//
	// start prefilter_FLP
	/**
	 * Prefilter for finding Quantizer input signal
	 *
	 * @param P I/O state
	 * @param st_res I
	 * @param xw O
	 * @param HarmShapeFIR I
	 * @param Tilt I
	 * @param LF_MA_shp I
	 * @param LF_AR_shp I
	 * @param lag I
	 * @param length
	 */
	final void silk_prefilt_FLP(
			final float st_res[], int roffset,
			final float xw[], int xoffset,
			final float[] HarmShapeFIR, final float Tilt, final float LF_MA_shp, final float LF_AR_shp, final int lag, int length)
	{
		/* To speed up use temp variables instead of using the struct */
		final float[] LTP_shp_buf = this.sLTP_shp;
		int LTP_shp_buf_idx = this.sLTP_shp_buf_idx;
		float sLF_AR_shp_val    = this.sLF_AR_shp;
		float sLF_MA_shp_val    = this.sLF_MA_shp;

		length += roffset;// java
		while( roffset < length ) {// java changed
			float n_LTP;
			if( lag > 0 ) {
				// silk_assert( Jdefine.HARM_SHAPE_FIR_TAPS == 3 );
				final int idx = lag + LTP_shp_buf_idx;
				n_LTP  = LTP_shp_buf[ ( idx - Jdefine.HARM_SHAPE_FIR_TAPS / 2 - 1) & Jdefine.LTP_MASK ] * HarmShapeFIR[ 0 ];
				n_LTP += LTP_shp_buf[ ( idx - Jdefine.HARM_SHAPE_FIR_TAPS / 2    ) & Jdefine.LTP_MASK ] * HarmShapeFIR[ 1 ];
				n_LTP += LTP_shp_buf[ ( idx - Jdefine.HARM_SHAPE_FIR_TAPS / 2 + 1) & Jdefine.LTP_MASK ] * HarmShapeFIR[ 2 ];
			} else {
				n_LTP = 0;
			}

			final float n_Tilt = sLF_AR_shp_val * Tilt;
			final float n_LF   = sLF_AR_shp_val * LF_AR_shp + sLF_MA_shp_val * LF_MA_shp;

			sLF_AR_shp_val = st_res[ roffset++ ] - n_Tilt;
			sLF_MA_shp_val = sLF_AR_shp_val - n_LF;

			LTP_shp_buf_idx = ( LTP_shp_buf_idx - 1 ) & Jdefine.LTP_MASK;
			LTP_shp_buf[ LTP_shp_buf_idx ] = sLF_MA_shp_val;

			xw[ xoffset++ ] = sLF_MA_shp_val - n_LTP;
		}
		/* Copy temp variable back to state */
		this.sLF_AR_shp       = sLF_AR_shp_val;
		this.sLF_MA_shp       = sLF_MA_shp_val;
		this.sLTP_shp_buf_idx = LTP_shp_buf_idx;
	}
	// end start prefilter_FLP
}
