package opus;

import celt.JAnalysisInfo;
import celt.JCELTEncoder;
import celt.JCELTMode;
import celt.Jcelt;
import celt.Jcelt_codec_API;
import celt.Jec_enc;
import celt.Jfloat_cast;
import silk.Jmacros;
import silk.Jsilk_EncControlStruct;
import silk.Jsilk_encoder;
import silk.Jtuning_parameters;

/* Copyright (c) 2010-2011 Xiph.Org Foundation, Skype Limited
   Written by Jean-Marc Valin and Koen Vos */

// opus_encoder.c

/** @defgroup opus_encoder Opus Encoder
 * @{
 *
 * @brief This page describes the process and functions used to encode Opus.
 *
 * Since Opus is a stateful codec, the encoding process starts with creating an encoder
 * state. This can be done with:
 *
 * @code
 * int          error;
 * OpusEncoder *enc;
 * enc = opus_encoder_create(Fs, channels, application, &error);
 * @endcode
 *
 * From this point, @c enc can be used for encoding an audio stream. An encoder state
 * @b must @b not be used for more than one stream at the same time. Similarly, the encoder
 * state @b must @b not be re-initialized for each frame.
 *
 * While opus_encoder_create() allocates memory for the state, it's also possible
 * to initialize pre-allocated memory:
 *
 * @code
 * int          size;
 * int          error;
 * OpusEncoder *enc;
 * size = opus_encoder_get_size(channels);
 * enc = malloc(size);
 * error = opus_encoder_init(enc, Fs, channels, application);
 * @endcode
 *
 * where opus_encoder_get_size() returns the required size for the encoder state. Note that
 * future versions of this code may change the size, so no assuptions should be made about it.
 *
 * The encoder state is always continuous in memory and only a shallow copy is sufficient
 * to copy it (e.g. memcpy())
 *
 * It is possible to change some of the encoder's settings using the opus_encoder_ctl()
 * interface. All these settings already default to the recommended value, so they should
 * only be changed when necessary. The most common settings one may want to change are:
 *
 * @code
 * opus_encoder_ctl(enc, OPUS_SET_BITRATE(bitrate));
 * opus_encoder_ctl(enc, OPUS_SET_COMPLEXITY(complexity));
 * opus_encoder_ctl(enc, OPUS_SET_SIGNAL(signal_type));
 * @endcode
 *
 * where
 *
 * @arg bitrate is in bits per second (b/s)
 * @arg complexity is a value from 1 to 10, where 1 is the lowest complexity and 10 is the highest
 * @arg signal_type is either OPUS_AUTO (default), OPUS_SIGNAL_VOICE, or OPUS_SIGNAL_MUSIC
 *
 * See @ref opus_encoderctls and @ref opus_genericctls for a complete list of parameters that can be set or queried. Most parameters can be set or changed at any time during a stream.
 *
 * To encode a frame, opus_encode() or opus_encode_float() must be called with exactly one frame (2.5, 5, 10, 20, 40 or 60 ms) of audio data:
 * @code
 * len = opus_encode(enc, audio_frame, frame_size, packet, max_packet);
 * @endcode
 *
 * where
 * <ul>
 * <li>audio_frame is the audio data in opus_int16 (or float for opus_encode_float())</li>
 * <li>frame_size is the duration of the frame in samples (per channel)</li>
 * <li>packet is the byte array to which the compressed data is written</li>
 * <li>max_packet is the maximum number of bytes that can be written in the packet (4000 bytes is recommended).
 *     Do not use max_packet to control VBR target bitrate, instead use the #OPUS_SET_BITRATE CTL.</li>
 * </ul>
 *
 * opus_encode() and opus_encode_float() return the number of bytes actually written to the packet.
 * The return value <b>can be negative</b>, which indicates that an error has occurred. If the return value
 * is 2 bytes or less, then the packet does not need to be transmitted (DTX).
 *
 * Once the encoder state if no longer needed, it can be destroyed with
 *
 * @code
 * opus_encoder_destroy(enc);
 * @endcode
 *
 * If the encoder was created with opus_encoder_init() rather than opus_encoder_create(),
 * then no action is required aside from potentially freeing the memory that was manually
 * allocated for it (calling free(enc) for the example above)
 *
 */
public final class JOpusEncoder {
	// private static final String CLASS_NAME = "JOpusEncoder";

	private static final int MAX_ENCODER_BUFFER = 480;

	private static final class JStereoWidthState {
		private float XX, XY, YY;
		private float smoothed_width;
		private float max_follower;
		//
		private final void clear() {
			XX = 0;
			XY = 0;
			YY = 0;
			smoothed_width = 0;
			max_follower = 0;
		}
		private final void copyFrom(final JStereoWidthState s) {
			XX = s.XX;
			XY = s.XY;
			YY = s.YY;
			smoothed_width = s.smoothed_width;
			max_follower = s.max_follower;
		}
	}

//struct OpusEncoder {
	//int          celt_enc_offset;// java changed to JCELTEncoder celt_enc = new JCELTEncoder();
	//int          silk_enc_offset;// java changed to Jsilk_encoder silk_enc = new Jsilk_encoder();
	private Jsilk_encoder silk_enc = null;// new Jsilk_encoder();// java added
	private JCELTEncoder celt_enc = null;// new JCELTEncoder();// java added
	private final Jsilk_EncControlStruct silk_mode = new Jsilk_EncControlStruct();
	private int          application;
	private int          channels;
	private int          delay_compensation;
	private int          force_channels;
	private int          signal_type;
	private int          user_bandwidth;
	private int          max_bandwidth;
	private int          user_forced_mode;
	private int          voice_ratio;
	private int          Fs;
	private boolean      use_vbr;
	private boolean      vbr_constraint;
	private int          variable_duration;
	private int          bitrate_bps;
	private int          user_bitrate_bps;
	private int          lsb_depth;
	private int          encoder_buffer;
	private boolean          lfe;
	// int          arch;// java not using
// #ifndef DISABLE_FLOAT_API
	private final JTonalityAnalysisState analysis = new JTonalityAnalysisState();
// #endif

// #define OPUS_ENCODER_RESET_START stream_channels
	private int          stream_channels;
	private short        hybrid_stereo_width_Q14;
	private int          variable_HP_smth2_Q15;
	private float        prev_HB_gain;
	private final float  hp_mem[] = new float[4];
	private int          mode;
	private int          prev_mode;
	private int          prev_channels;
	private int          prev_framesize;
	private int          bandwidth;
	private boolean      silk_bw_switch;
	/* Sampling rate (at the API level) */
	private boolean      first;
	private float[]      energy_masking;
	private final JStereoWidthState width_mem = new JStereoWidthState();
	private final float  delay_buffer[] = new float[MAX_ENCODER_BUFFER * 2];
// #ifndef DISABLE_FLOAT_API
	private int          detected_bandwidth;
// #endif
	private long         rangeFinal;// uint32
//};
// end of struct
	//
	/**
	 * Default costructor
	 */
	public JOpusEncoder() {
	}
	/**
	 * java. to replace code:
	 * <pre>
	 * inr decsize = JOpusDecoder.opus_decoder_get_size( 1 );
	 * OpusDecoder *dec = (OpusDecoder*)malloc( decsize );
	 * </pre>
	 * @param channels
	 * @throws IllegalArgumentException
	 */
	public JOpusEncoder(final int channels) throws IllegalArgumentException {
		if( channels < 1 || channels > 2 ) {
			throw new IllegalArgumentException();
		}
		silk_enc = new Jsilk_encoder();
		celt_enc = new JCELTEncoder( channels );
	}
	private final void clear(final boolean isFull) {
		if( isFull ) {
			silk_enc = null;
			celt_enc = null;
			silk_mode.clear();
			application = 0;
			channels = 0;
			delay_compensation = 0;
			force_channels = 0;
			signal_type = 0;
			user_bandwidth = 0;
			max_bandwidth = 0;
			user_forced_mode = 0;
			voice_ratio = 0;
			Fs = 0;
			use_vbr = false;
			vbr_constraint = false;
			variable_duration = 0;
			bitrate_bps = 0;
			user_bitrate_bps = 0;
			lsb_depth = 0;
			encoder_buffer = 0;
			lfe = false;
			// arch = 0;// java not using
// #ifndef DISABLE_FLOAT_API
			analysis.clear( true );
// #endif
		}
		stream_channels = 0;
		hybrid_stereo_width_Q14 = 0;
		variable_HP_smth2_Q15 = 0;
		prev_HB_gain = 0;
		hp_mem[0] = 0; hp_mem[1] = 0; hp_mem[2] = 0; hp_mem[3] = 0;
		mode = 0;
		prev_mode = 0;
		prev_channels = 0;
		prev_framesize = 0;
		bandwidth = 0;
		silk_bw_switch = false;
		first = false;
		energy_masking = null;
		width_mem.clear();
		final float[] fbuff = delay_buffer;
		int i = MAX_ENCODER_BUFFER * 2;
		do {
			fbuff[--i] = 0;
		} while( i > 0  );
// #ifndef DISABLE_FLOAT_API
		detected_bandwidth = 0;
// #endif
		rangeFinal = 0;
	}
	public final void copyFrom(final JOpusEncoder e) {
		silk_enc.copyFrom( e.silk_enc );
		celt_enc.copyFrom( e.celt_enc );
		silk_mode.copyFrom( e.silk_mode );
		application = e.application;
		channels = e.channels;
		delay_compensation = e.delay_compensation;
		force_channels = e.force_channels;
		signal_type = e.signal_type;
		user_bandwidth = e.user_bandwidth;
		max_bandwidth = e.max_bandwidth;
		user_forced_mode = e.user_forced_mode;
		voice_ratio = e.voice_ratio;
		Fs = e.Fs;
		use_vbr = e.use_vbr;
		vbr_constraint = e.vbr_constraint;
		variable_duration = e.variable_duration;
		bitrate_bps = e.bitrate_bps;
		user_bitrate_bps = e.user_bitrate_bps;
		lsb_depth = e.lsb_depth;
		encoder_buffer = e.encoder_buffer;
		lfe = e.lfe;
		// arch = 0;// java not using
// #ifndef DISABLE_FLOAT_API
		analysis.copyFrom( e.analysis );
// #endif
		stream_channels = e.stream_channels;
		hybrid_stereo_width_Q14 = e.hybrid_stereo_width_Q14;
		variable_HP_smth2_Q15 = e.variable_HP_smth2_Q15;
		prev_HB_gain = e.prev_HB_gain;
		hp_mem[0] = e.hp_mem[0]; hp_mem[1] = e.hp_mem[1]; hp_mem[2] = e.hp_mem[2]; hp_mem[3] = e.hp_mem[3];
		mode = e.mode;
		prev_mode = e.prev_mode;
		prev_channels = e.prev_channels;
		prev_framesize = e.prev_framesize;
		bandwidth = e.bandwidth;
		silk_bw_switch = e.silk_bw_switch;
		first = e.first;
		energy_masking = e.energy_masking;
		width_mem.copyFrom( e.width_mem );
		System.arraycopy( e.delay_buffer, 0, delay_buffer, 0, MAX_ENCODER_BUFFER * 2 );
// #ifndef DISABLE_FLOAT_API
		detected_bandwidth = 0;
// #endif
		rangeFinal = 0;
	}

	/* Transition tables for the voice and music. First column is the
	   middle (memoriless) threshold. The second column is the hysteresis
	   (difference with the middle) */
	private static final int mono_voice_bandwidth_thresholds[/* 8 */] = {
		11000, 1000, /* NB<.MB */
		14000, 1000, /* MB<.WB */
		17000, 1000, /* WB<.SWB */
		21000, 2000, /* SWB<.FB */
	};
	private static final int mono_music_bandwidth_thresholds[/* 8 */] = {
		12000, 1000, /* NB<.MB */
		15000, 1000, /* MB<.WB */
		18000, 2000, /* WB<.SWB */
		22000, 2000, /* SWB<.FB */
	};
	private static final int stereo_voice_bandwidth_thresholds[/* 8 */] = {
		11000, 1000, /* NB<.MB */
		14000, 1000, /* MB<.WB */
		21000, 2000, /* WB<.SWB */
		28000, 2000, /* SWB<.FB */
	};
	private static final int stereo_music_bandwidth_thresholds[/* 8 */] = {
		12000, 1000, /* NB<.MB */
		18000, 2000, /* MB<.WB */
		21000, 2000, /* WB<.SWB */
		30000, 2000, /* SWB<.FB */
	};
	/* Threshold bit-rates for switching between mono and stereo */
	private static final int stereo_voice_threshold = 30000;
	private static final int stereo_music_threshold = 30000;

	/** Threshold bit-rate for switching between SILK/hybrid and CELT-only */
	private static final int mode_thresholds[/* 2 */][/* 2 */] = {
		/* voice */ /* music */
		{  64000,      16000}, /* mono */
		{  36000,      16000}, /* stereo */
	};

	/** Gets the size of an <code>OpusEncoder</code> structure.
	  * @param[in] channels <tt>int</tt>: Number of channels.
	  *                                   This must be 1 or 2.
	  * @returns The size in bytes.
	  */
	/*private static final int opus_encoder_get_size(final int channels)// java not using
	{
		int silkEncSizeBytes, celtEncSizeBytes;
		int ret;
		if( channels < 1 || channels > 2 ) {
			return 0;
		}
		int ret = silk_Get_Encoder_Size( &silkEncSizeBytes );
		if( ret ) {
			return 0;
		}
		silkEncSizeBytes = align( silkEncSizeBytes );
		celtEncSizeBytes = celt_encoder_get_size( channels );
		return align( sizeof( JOpusEncoder ) ) + silkEncSizeBytes + celtEncSizeBytes;
	}*/

	/** Initializes a previously allocated encoder state
	  * The memory pointed to by st must be at least the size returned by opus_encoder_get_size().
	  * This is intended for applications which use their own allocator instead of malloc.
	  * @see opus_encoder_create(),opus_encoder_get_size()
	  * To reset a previously initialized state, use the #OPUS_RESET_STATE CTL.
	  * @param st [in] <tt>OpusEncoder*</tt>: Encoder state
	  * @param Fsr [in] <tt>opus_int32</tt>: Sampling rate of input signal (Hz)
	  *                                     This must be one of 8000, 12000, 16000,
	  *                                     24000, or 48000.
	  * @param nchannels [in] <tt>int</tt>: Number of channels (1 or 2) in input signal
	  * @param appmode [in] <tt>int</tt>: Coding mode (OPUS_APPLICATION_VOIP/OPUS_APPLICATION_AUDIO/OPUS_APPLICATION_RESTRICTED_LOWDELAY)
	  * @retval #OPUS_OK Success or @ref opus_errorcodes
	  */
	public final int opus_encoder_init(final int Fsr, final int nchannels, final int appmode)
	{
		if( (Fsr != 48000 && Fsr != 24000 && Fsr != 16000 && Fsr != 12000 && Fsr != 8000) || (nchannels != 1 && nchannels != 2) ||
				(appmode != Jopus_defines.OPUS_APPLICATION_VOIP && appmode != Jopus_defines.OPUS_APPLICATION_AUDIO
				&& appmode != Jopus_defines.OPUS_APPLICATION_RESTRICTED_LOWDELAY) ) {
			return Jopus_defines.OPUS_BAD_ARG;
		}

		// OPUS_CLEAR( (char*)st, opus_encoder_get_size( channels ) );
		clear( true );
		/* Create SILK encoder */
		//int ret = silk_Get_Encoder_Size( &silkEncSizeBytes );
		//if( ret ) {
		//	return Jopus_defines.OPUS_BAD_ARG;
		//}
		//final int silkEncSizeBytes = align( silkEncSizeBytes );
		//st.silk_enc_offset = align( sizeof( OpusEncoder ) );
		//st.celt_enc_offset = st.silk_enc_offset + silkEncSizeBytes;
		// final Jsilk_encoder silk_enc = (char*)st + st.silk_enc_offset;// java changed: added silk_enc
		// final JCELTEncoder celt_enc = (JCELTEncoder)((char*)st + st.celt_enc_offset);// java changed: added celt_enc
		this.silk_enc = new Jsilk_encoder();
		this.celt_enc = new JCELTEncoder();

		this.stream_channels = this.channels = nchannels;

		this.Fs = Fsr;

		// st.arch = opus_select_arch();

		final int ret = this.silk_enc.silk_InitEncoder( this.silk_mode );
		if( 0 != ret ) {
			return Jopus_defines.OPUS_INTERNAL_ERROR;
		}

		/* default SILK parameters */
		this.silk_mode.nChannelsAPI              = nchannels;
		this.silk_mode.nChannelsInternal         = nchannels;
		this.silk_mode.API_sampleRate            = this.Fs;
		this.silk_mode.maxInternalSampleRate     = 16000;
		this.silk_mode.minInternalSampleRate     = 8000;
		this.silk_mode.desiredInternalSampleRate = 16000;
		this.silk_mode.payloadSize_ms            = 20;
		this.silk_mode.bitRate                   = 25000;
		this.silk_mode.packetLossPercentage      = 0;
		this.silk_mode.complexity                = 9;
		this.silk_mode.useInBandFEC              = false;
		this.silk_mode.useDTX                    = false;
		this.silk_mode.useCBR                    = false;
		this.silk_mode.reducedDependency         = false;

		/* Create CELT encoder */
		/* Initialize CELT encoder */
		final int err = this.celt_enc.celt_encoder_init( Fsr, nchannels );//, st.arch );
		if( err != Jopus_defines.OPUS_OK ) {
			return Jopus_defines.OPUS_INTERNAL_ERROR;
		}

		this.celt_enc.celt_encoder_ctl( Jcelt.CELT_SET_SIGNALLING, false );
		this.celt_enc.celt_encoder_ctl( Jopus_defines.OPUS_SET_COMPLEXITY, this.silk_mode.complexity );

		this.use_vbr = true;
		/* Makes constrained VBR the default (safer for real-time use) */
		this.vbr_constraint = true;
		this.user_bitrate_bps = Jopus_defines.OPUS_AUTO;
		this.bitrate_bps = 3000 + Fsr * nchannels;
		this.application = appmode;
		this.signal_type = Jopus_defines.OPUS_AUTO;
		this.user_bandwidth = Jopus_defines.OPUS_AUTO;
		this.max_bandwidth = Jopus_defines.OPUS_BANDWIDTH_FULLBAND;
		this.force_channels = Jopus_defines.OPUS_AUTO;
		this.user_forced_mode = Jopus_defines.OPUS_AUTO;
		this.voice_ratio = -1;
		this.encoder_buffer = this.Fs / 100;
		this.lsb_depth = 24;
		this.variable_duration = Jopus_defines.OPUS_FRAMESIZE_ARG;

		/* Delay compensation of 4 ms (2.5 ms for SILK's extra look-ahead
		   + 1.5 ms for SILK resamplers and stereo prediction) */
		this.delay_compensation = this.Fs / 250;

		this.hybrid_stereo_width_Q14 = 1 << 14;
		this.prev_HB_gain = Jfloat_cast.Q15ONE;
		this.variable_HP_smth2_Q15 = Jmacros.silk_lin2log( Jtuning_parameters.VARIABLE_HP_MIN_CUTOFF_HZ ) << 8;
		this.first = true;
		this.mode = Jopus_private.MODE_HYBRID;
		this.bandwidth = Jopus_defines.OPUS_BANDWIDTH_FULLBAND;

// #ifndef DISABLE_FLOAT_API
		this.analysis.tonality_analysis_init();
// #endif

		return Jopus_defines.OPUS_OK;
	}

	/**
	 * java: return type is changed from unsigned char to int
	 */
	private static final int gen_toc(final int mode, int framerate, final int bandwidth, final int channels)
	{
		int period = 0;
		while( framerate < 400 )
		{
			framerate <<= 1;
			period++;
		}
		int toc;
		if( mode == Jopus_private.MODE_SILK_ONLY )
		{
			toc = (bandwidth - Jopus_defines.OPUS_BANDWIDTH_NARROWBAND) << 5;
			toc |= (period - 2) << 3;
		} else if( mode == Jopus_private.MODE_CELT_ONLY )
		{
			int tmp = bandwidth - Jopus_defines.OPUS_BANDWIDTH_MEDIUMBAND;
			if( tmp < 0 ) {
				tmp = 0;
			}
			toc = 0x80;
			toc |= tmp << 5;
			toc |= period << 3;
		} else /* Hybrid */
		{
			toc = 0x60;
			toc |= (bandwidth - Jopus_defines.OPUS_BANDWIDTH_SUPERWIDEBAND) << 4;
			toc |= (period - 2) << 3;
		}
		if( channels == 2 ) {
			toc |= 1 << 2;
		}
		return toc;
	}

// #ifndef FIXED_POINT
	/**
	 *
	 * @param in I:    Input signal
	 * @param B_Q28 I:    MA coefficients [3]
	 * @param A_Q28 I:    AR coefficients [2]
	 * @param S I/O:  State vector [2]
	 * @param out O:    Output signal
	 * @param len I:    Signal length (must be even)
	 * @param stride
	 */
	private static final void silk_biquad_float(final float[] in, final int inoffset,// java
			final int[] B_Q28, final int[] A_Q28,
			final float[] S, final int soffset,// java
			final float[] out, final int outoffset,// java
			int len, final int stride
		)
	{
		/* DIRECT FORM II TRANSPOSED (uses 2 element state vector) */
		final float A[] = new float[2];
		final float B[] = new float[3];

		A[0] = ((float)A_Q28[0] * (1.f / ((float)(1 << 28))));
		A[1] = ((float)A_Q28[1] * (1.f / ((float)(1 << 28))));
		B[0] = ((float)B_Q28[0] * (1.f / ((float)(1 << 28))));
		B[1] = ((float)B_Q28[1] * (1.f / ((float)(1 << 28))));
		B[2] = ((float)B_Q28[2] * (1.f / ((float)(1 << 28))));

		/* Negate A_Q28 values and split in two parts */

		len *= stride;// java
		for( int k = 0; k < len; k += stride ) {
			/* S[ 0 ], S[ 1 ]: Q12 */
			final float inval = in[inoffset + k];
			final float vout = S[soffset] + B[0] * inval;

			S[soffset    ] = S[soffset] + B[1] * inval - vout * A[0];
			S[soffset + 1] =              B[2] * inval - vout * A[1] + Jfloat_cast.VERY_SMALL;

			/* Scale back to Q0 and saturate */
			out[outoffset + k] = vout;
		}
	}
// #endif

	private static final void hp_cutoff(final float[] in, int inoffset,// java
			final int cutoff_Hz,
			final float[] out, int outoffset,// java
			final float[] hp_mem, final int len, final int channels, final int Fs)
	{
		final int B_Q28[] = new int[ 3 ];
		final int A_Q28[] = new int[ 2 ];

		// silk_assert( cutoff_Hz <= silk_int32_MAX / SILK_FIX_CONST( 1.5 * 3.14159 / 1000, 19 ) );
		// FIXME why not PI?
		// Fc_Q19 = (SILK_FIX_CONST( 1.5 * 3.14159 / 1000., 19 ) * cutoff_Hz ) / (Fs / 1000);
		final int Fc_Q19 = (((int)( (1.5 * 3.14159 / 1000.) * (1 << 19) + 0.5 )) * cutoff_Hz ) / (Fs / 1000);
		// silk_assert( Fc_Q19 > 0 && Fc_Q19 < 32768 );
		// r_Q28 = SILK_FIX_CONST( 1.0, 28 ) - SILK_FIX_CONST( 0.92, 9 ) * Fc_Q19;
		final int r_Q28 = ((int)( 1.0 * (1 << 28) + 0.5 )) - ((int)( 0.92 * (1 << 9) + 0.5 )) * Fc_Q19;

		/* b = r * [ 1; -2; 1 ]; */
		/* a = [ 1; -2 * r * ( 1 - 0.5 * Fc^2 ); r^2 ]; */
		B_Q28[ 0 ] = r_Q28;
		B_Q28[ 1 ] = (-r_Q28) << 1;
		B_Q28[ 2 ] = r_Q28;

		/* -r * ( 2 - Fc * Fc ); */
		final long r_Q22 = r_Q28 >> 6;
		// A_Q28[ 0 ] = Jmacros.silk_SMULWW( r_Q22, Jmacros.silk_SMULWW( Fc_Q19, Fc_Q19 ) - SILK_FIX_CONST( 2.0, 22 ) );
		A_Q28[ 0 ] = (int)((r_Q22 * ((((long)Fc_Q19 * Fc_Q19) >> 16) - ((long)(2.0 * (1 << 22) + 0.5)))) >> 16);
		A_Q28[ 1 ] = (int)((r_Q22 * r_Q22) >> 16);

/* #ifdef FIXED_POINT
		silk_biquad_alt( in, B_Q28, A_Q28, hp_mem, out, len, channels );
		if( channels == 2 ) {
			silk_biquad_alt( in + 1, B_Q28, A_Q28, hp_mem + 2, out + 1, len, channels );
		}
#else */
		silk_biquad_float( in, inoffset, B_Q28, A_Q28, hp_mem, 0, out, outoffset, len, channels );
		if( channels == 2 ) {
			silk_biquad_float( in, ++inoffset, B_Q28, A_Q28, hp_mem, 2, out, ++outoffset, len, channels );
		}
// #endif
	}

/* #ifdef FIXED_POINT
	private static final void dc_reject(final short[] in, final int cutoff_Hz, final short[] out, final int[] hp_mem,
						final int len, final int channels, final int Fs)
	{
		int c, i;
		int shift;

		// Approximates -round(log2(4.*cutoff_Hz/Fs))
		shift = celt_ilog2( Fs / (cutoff_Hz * 3) );
		for( c = 0; c < channels; c++ )
		{
			for( i = 0; i < len; i++ )
			{
				int x, tmp, y;
				x = SHL32( EXTEND32( in[channels * i + c]), 15 );
				// First stage
				tmp = x - hp_mem[2 * c];
				hp_mem[2 * c] = hp_mem[2 * c] + PSHR32( x - hp_mem[2 * c], shift );
				// Second stage
				y = tmp - hp_mem[2 * c + 1];
				hp_mem[2 * c + 1] = hp_mem[2 * c + 1] + PSHR32( tmp - hp_mem[2 * c + 1], shift );
				out[channels * i + c] = EXTRACT16( SATURATE( PSHR32( y, 15 ), 32767 ) );
			}
		}
	}

#else */
	private static final void dc_reject(final float[] in, final int inoffset,// java
			final int cutoff_Hz,
			final float[] out, final int outoffset,// java
			final float[] hp_mem, int len, final int channels, final int Fs)
	{
		len *= channels;// java
		final float coef = 4.0f * (float)cutoff_Hz / (float)Fs;
		for( int c = 0; c < channels; c++, len++ )
		{
			final int c2 = c << 1;// java
			for( int i = c; i < len; i += channels )
			{
				final float x = in[inoffset + i];
				/* First stage */
				float v = hp_mem[c2];// java
				final float tmp = x - v;
				hp_mem[c2] = v + coef * (x - v) + Jfloat_cast.VERY_SMALL;
				/* Second stage */
				v = hp_mem[c2 + 1];// java
				final float y = tmp - v;
				hp_mem[c2 + 1] = v + coef * (tmp - v) + Jfloat_cast.VERY_SMALL;
				out[outoffset + i] = y;
			}
		}
	}
// #endif

	private static final void stereo_fade(final float[] in, final float[] out, float g1, float g2,
			final int overlap48, int frame_size, final int channels, final float[] window, final int Fs)
	{
		int overlap;
		int inc;
		inc = 48000 / Fs;
		overlap = overlap48 / inc;
		g1 = Jfloat_cast.Q15ONE - g1;
		g2 = Jfloat_cast.Q15ONE - g2;
		int i, ic;
		for( i = 0, ic = 0, overlap *= inc; i < overlap; i += inc, ic += channels )
		{
			float w = window[i];
			w *= w;// java
			final float g = w * g2 + (Jfloat_cast.Q15ONE - w) * g1;
			float diff = .5f * (in[ic] - in[ic + 1]);
			diff *= g;
			out[ic] -= diff;
			out[ic + 1] += diff;
		}
		for( frame_size *= channels; ic < frame_size; ic += channels )
		{
			float diff = .5f * (in[ic] - in[ic + 1]);
			diff *= g2;
			out[ic] -= diff;
			out[ic + 1] += diff;
		}
	}

	private static final void gain_fade(final float[] in, final int inoffset,// java
			final float[] out, final int outoffset,// java
			final float g1, final float g2,
			final int overlap48, int frame_size, final int channels, final float[] window, final int Fs)
	{
		final int inc = 48000 / Fs;
		int overlap = overlap48 / inc;
		if( channels == 1 )
		{
			for( int i = 0; i < overlap; i++ )
			{
				float w = window[i * inc];
				w *= w;
				final float g = (w * g2) + (Jfloat_cast.Q15ONE - w) * g1;
				out[outoffset + i] = g * in[inoffset + i];
			}
		} else {
			for( int i = 0; i < overlap; i++ )
			{
				float w = window[i * inc];
				w *= w;
				final float g = (w * g2) + (Jfloat_cast.Q15ONE - w) * g1;
				final int i2 = i << 1;// java
				int oi = outoffset + i2;// java
				int ii = inoffset + i2;// java
				out[oi++] = g * in[ii++];
				out[oi] = g * in[ii];
			}
		}
		int c = 0;
		overlap *= channels;// java
		frame_size *= channels;// java
		frame_size += inoffset;// java
		do {
			for( int oi = outoffset + overlap, ii = inoffset + overlap; ii < frame_size; oi += channels, ii += channels )
			{
				out[oi] = g2 * in[ii];
			}
			overlap++;// java
			frame_size++;// java
		}
		while( ++c < channels );
	}

	/** Allocates and initializes an encoder state.
	 * There are three coding modes:
	 *
	 * @ref OPUS_APPLICATION_VOIP gives best quality at a given bitrate for voice
	 *    signals. It enhances the  input signal by high-pass filtering and
	 *    emphasizing formants and harmonics. Optionally  it includes in-band
	 *    forward error correction to protect against packet loss. Use this
	 *    mode for typical VoIP applications. Because of the enhancement,
	 *    even at high bitrates the output may sound different from the input.
	 *
	 * @ref OPUS_APPLICATION_AUDIO gives best quality at a given bitrate for most
	 *    non-voice signals like music. Use this mode for music and mixed
	 *    (music/voice) content, broadcast, and applications requiring less
	 *    than 15 ms of coding delay.
	 *
	 * @ref OPUS_APPLICATION_RESTRICTED_LOWDELAY configures low-delay mode that
	 *    disables the speech-optimized mode in exchange for slightly reduced delay.
	 *    This mode can only be set on an newly initialized or freshly reset encoder
	 *    because it changes the codec delay.
	 *
	 * This is useful when the caller knows that the speech-optimized modes will not be needed (use with caution).
	 * @param [in] Fs <tt>opus_int32</tt>: Sampling rate of input signal (Hz)
	 *                                     This must be one of 8000, 12000, 16000,
	 *                                     24000, or 48000.
	 * @param [in] channels <tt>int</tt>: Number of channels (1 or 2) in input signal
	 * @param [in] application <tt>int</tt>: Coding mode (@ref OPUS_APPLICATION_VOIP/@ref OPUS_APPLICATION_AUDIO/@ref OPUS_APPLICATION_RESTRICTED_LOWDELAY)
	 * @param [out] error <tt>int*</tt>: @ref opus_errorcodes
	 * @note Regardless of the sampling rate and number channels selected, the Opus encoder
	 * can switch to a lower audio bandwidth or number of channels if the bitrate
	 * selected is too low. This also means that it is safe to always use 48 kHz stereo input
	 * and let the encoder optimize the encoding.
	 */
	public static final JOpusEncoder opus_encoder_create(final int Fs, final int channels, final int application, final int[] error)
	{
		if( (Fs != 48000 && Fs != 24000 && Fs != 16000 && Fs != 12000 && Fs != 8000) || (channels != 1 && channels != 2) ||
			(application != Jopus_defines.OPUS_APPLICATION_VOIP && application != Jopus_defines.OPUS_APPLICATION_AUDIO
			&& application != Jopus_defines.OPUS_APPLICATION_RESTRICTED_LOWDELAY) )
		{
			if( null != error ) {
				error[0] = Jopus_defines.OPUS_BAD_ARG;
			}
			return null;
		}
		// st = (JOpusEncoder)opus_alloc( opus_encoder_get_size( channels ) );
		JOpusEncoder st = new JOpusEncoder();
		/* if( st == null )
		{
			if( null != error ) {
				error[0] = Jopus_defines.OPUS_ALLOC_FAIL;
			}
			return null;
		}*/
		final int ret = st.opus_encoder_init( Fs, channels, application );
		if( null != error ) {
			error[0] = ret;
		}
		if( ret != Jopus_defines.OPUS_OK )
		{
			// opus_free( st );
			st = null;
		}
		return st;
	}

	private final int user_bitrate_to_bitrate(int frame_size, final int max_data_bytes)
	{
		if( 0 == frame_size ) {
			frame_size = this.Fs / 400;
		}
		if( this.user_bitrate_bps == Jopus_defines.OPUS_AUTO ) {
			return 60 * this.Fs / frame_size + this.Fs * this.channels;
		} else if( this.user_bitrate_bps == Jopus_defines.OPUS_BITRATE_MAX ) {
			return (max_data_bytes << 3) * this.Fs / frame_size;
		}// else {
			return this.user_bitrate_bps;
		// }
	}

// #ifndef DISABLE_FLOAT_API
	/** Don't use more than 60 ms for the frame size analysis */
	private static final int MAX_DYNAMIC_FRAMESIZE = 24;
	/** Estimates how much the bitrate will be boosted based on the sub-frame energy */
	private static final float transient_boost(final float[] E, final int eoffset,// java
			final float[] E_1, final int eoffset1,// java
			final int LM, final int maxM)
	{
		float sumE = 0, sumE_1 = 0;

		int M = (1 << LM) + 1;
		M = maxM < M ? maxM : M;
		for( int i = 0; i < M; i++ )
		{
			sumE += E[eoffset + i];
			sumE_1 += E_1[eoffset1 + i];
		}
		float metric = sumE * sumE_1 / (M * M);
		/*if( LM==3)
		printf("%f\n", metric);*/
		/*return metric>10 ? 1 : 0;*/
		/*return MAX16(0,1-exp(-.25*(metric-2.)));*/
		metric = .05f * (metric - 2f);
		metric = (float)Math.sqrt( (double)(0 >= metric ? 0 : metric) );
		return (1f <= metric ? 1f : metric);
	}

/* Viterbi decoding trying to find the best frame size combination using look-ahead

   State numbering:
    0: unused
    1:  2.5 ms
    2:  5 ms (#1)
    3:  5 ms (#2)
    4: 10 ms (#1)
    5: 10 ms (#2)
    6: 10 ms (#3)
    7: 10 ms (#4)
    8: 20 ms (#1)
    9: 20 ms (#2)
   10: 20 ms (#3)
   11: 20 ms (#4)
   12: 20 ms (#5)
   13: 20 ms (#6)
   14: 20 ms (#7)
   15: 20 ms (#8)
*/
	private static final int transient_viterbi(final float[] E, final float[] E_1, final int N, final int frame_cost, final int rate)
	{
		final float cost[][] = new float[MAX_DYNAMIC_FRAMESIZE][16];
		final int states[][] = new int[MAX_DYNAMIC_FRAMESIZE][16];
		float factor;
		/* Take into account that we damp VBR in the 32 kb/s to 64 kb/s range. */
		if( rate < 80 ) {
			factor = 0;
		} else if( rate > 160 ) {
			factor = 1f;
		} else {
			factor = (rate - 80.f) / 80.f;
		}
		/* Makes variable framesize less aggressive at lower bitrates, but I can't
		   find any valid theoretical justification for this (other than it seems
		   to help) */
		for( int i = 0; i < 16; i++ )
		{
			/* Impossible state */
			states[0][i] = -1;
			cost[0][i] = 1e10f;
		}
		for( int i = 0; i < 4; i++ )
		{
			final int j = 1 << i;// java
			cost[0][j] = (frame_cost + rate * j) * (1 + factor * transient_boost( E, 0, E_1, 0, i, N + 1 ));
			states[0][j] = i;
		}
		for( int i = 1; i < N; i++ )
		{
			/* Follow continuations */
			for( int j = 2; j < 16; j++ )
			{
				cost[i][j] = cost[i - 1][j - 1];
				states[i][j] = j - 1;
			}

			/* New frames */
			for( int j = 0; j < 4; j++ )
			{
				final int j1 = 1 << j;// java
				states[i][j1] = 1;
				float min_cost = cost[i - 1][1];
				for( int k = 1; k < 4; k++ )
				{
					final int v = (1 << (k + 1)) - 1;// java
					final float tmp = cost[i - 1][v];
					if( tmp < min_cost )
					{
						states[i][j1] = v;
						min_cost = tmp;
					}
				}
				final float curr_cost = (frame_cost + rate * j1) * (1 + factor * transient_boost( E, i, E_1, i, j, N - i + 1 ));
				cost[i][j1] = min_cost;
				/* If part of the frame is outside the analysis window, only count part of the cost */
				cost[i][j1] += ( N - i < j1 ) ?
								curr_cost * (float)(N - i) / j1
								:
								curr_cost;
			}
		}

		int best_state = 1;
		float best_cost = cost[N - 1][1];
		/* Find best end state (doesn't force a frame to end at N-1) */
		for( int i = 2; i < 16; i++ )
		{
			if( cost[N - 1][i] < best_cost )
			{
				best_cost = cost[N - 1][i];
				best_state = i;
			}
		}

		/* Follow transitions back */
		for( int i = N - 1; i >= 0; i-- )
		{
			/*printf("%d ", best_state);*/
			best_state = states[i][best_state];
		}
		/*printf("%d\n", best_state);*/
		return best_state;
	}

	private static final int optimize_framesize(final Object x, final int xoffset,// java
			int len, final int C, final int Fs,
			final int bitrate, final float tonality, final float[] mem, final int buffering,
			final Idownmix downmix)//final downmix_func downmix)
	{
		final float e[] = new float[MAX_DYNAMIC_FRAMESIZE + 4];
		final float e_1[] = new float[MAX_DYNAMIC_FRAMESIZE + 3];

		final int subframe = Fs / 400;

		e[0] = mem[0];
		e_1[0] = 1.f / (Jfloat_cast.EPSILON + mem[0]);
		int pos, offset;
		if( 0 != buffering )
		{
			/* Consider the CELT delay when not in restricted-lowdelay */
			/* We assume the buffering is between 2.5 and 5 ms */
			offset = (subframe << 1) - buffering;
			// celt_assert( offset >= 0 && offset <= subframe );
			len -= offset;
			e[1] = mem[1];
			e_1[1] = 1.f / (Jfloat_cast.EPSILON + mem[1]);
			e[2] = mem[2];
			e_1[2] = 1.f / (Jfloat_cast.EPSILON + mem[2]);
			pos = 3;
		} else {
			pos = 1;
			offset = 0;
		}
		int N = len / subframe;
		N = N < MAX_DYNAMIC_FRAMESIZE ? N : MAX_DYNAMIC_FRAMESIZE;
		final float[] sub = new float[subframe];
		/* Just silencing a warning, it's really initialized later */
		float memx = 0;
		int i;
		for( i = 0; i < N; i++, pos++ )
		{
			downmix.downmix( x, xoffset, sub, 0, subframe, i * subframe + offset, 0, -2, C );
			if( i == 0 ) {
				memx = sub[0];
			}
			float tmp = Jfloat_cast.EPSILON;
			for( int j = 0; j < subframe; j++ )
			{
				final float tmpx = sub[j];
				tmp += (tmpx - memx) * (float)(tmpx - memx);
				memx = tmpx;
			}
			e[pos] = tmp;
			e_1[pos] = 1.f / tmp;
		}
		/* Hack to get 20 ms working with APPLICATION_AUDIO
		   The real problem is that the corresponding memory needs to use 1.5 ms
		   from this frame and 1 ms from the next frame */
		e[/* i + */pos] = e[/*i + */pos - 1];// FIXME why using i, not N?
		if( 0 != buffering ) {
			N += 2;
			N = MAX_DYNAMIC_FRAMESIZE < N ? MAX_DYNAMIC_FRAMESIZE : N;
		}
		final int bestLM = transient_viterbi( e, e_1, N, (int)((1.f + .5f * tonality) * (float)(60 * C + 40)), bitrate / 400 );
		mem[0] = e[1 << bestLM];
		if( 0 != buffering )
		{
			i = (1 << bestLM) + 1;// java
			mem[1] = e[i++];
			mem[2] = e[i];
		}
		return bestLM;
	}

// #endif

/* #ifndef DISABLE_FLOAT_API
#ifdef FIXED_POINT
#define PCM2VAL(x) FLOAT2INT16(x)
#else
#define PCM2VAL(x) SCALEIN(x)
#endif */
	private static final class Jdownmix_float extends Idownmix {

		@Override
		void downmix(final Object _x, final int xoffset, final float[] sub, final int suboffset, int subframe, final int offset, final int c1, final int c2, final int C) {
			final float[] x = (float[])_x;
			subframe += suboffset;// java
			for( int j = suboffset, joc = xoffset + offset * C + c1; j < subframe; j++, joc += C ) {
				sub[j] = x[joc] * Jfloat_cast.CELT_SIG_SCALE;
			}
			if( c2 > -1 )
			{
				for( int j = suboffset, joc = xoffset + offset * C + c2; j < subframe; j++, joc += C ) {
					sub[j] += x[joc] * Jfloat_cast.CELT_SIG_SCALE;
				}
			} else if( c2 == -2 )
			{
				for( int c = 1; c < C; c++ )
				{
					for( int j = suboffset, joc = xoffset + offset * C + c; j < subframe; j++, joc += C ) {
						sub[j] += x[joc] * Jfloat_cast.CELT_SIG_SCALE;
					}
				}
			}
	/* #ifdef FIXED_POINT
			scale = (1 << SIG_SHIFT);
	#else */
			float scale = 1.f;
	// #endif
			if( C == -2 ) {
				scale /= C;
			} else {
				scale /= 2f;
			}
			for( int j = suboffset; j < subframe; j++ ) {
				sub[j] *= scale;
			}
		}

	}
	static final Jdownmix_float downmix_float = new Jdownmix_float();
/*
	private static final void downmix_float(final float[] x, final float[] sub, final int subframe, final int offset, final int c1, final int c2, final int C)
	{
		for( int j = 0, joc = offset * C + c1; j < subframe; j++, joc += C ) {
			sub[j] = x[joc] * Jfloat_cast.CELT_SIG_SCALE;
		}
		if( c2 > -1 )
		{
			for( int j = 0, joc = offset * C + c2; j < subframe; j++, joc += C ) {
				sub[j] += x[joc] * Jfloat_cast.CELT_SIG_SCALE;
			}
		} else if( c2 == -2 )
		{
			for( int c = 1; c < C; c++ )
			{
				for( int j = 0, joc = offset * C + c; j < subframe; j++, joc += C ) {
					sub[j] += x[joc] * Jfloat_cast.CELT_SIG_SCALE;
				}
			}
		}
// #ifdef FIXED_POINT
//		scale = (1 << SIG_SHIFT);
//#else
		float scale = 1.f;
// #endif
		if( C == -2 ) {
			scale /= C;
		} else {
			scale /= 2f;
		}
		for( int j = 0; j < subframe; j++ ) {
			sub[j] *= scale;
		}
	}
*/
// #endif

	private static final class Jdownmix_int extends Idownmix {

		@Override
		void downmix(final Object _x, final int xoffset, final float[] sub, final int suboffset, int subframe, final int offset, final int c1, final int c2, final int C) {
			final short[] x = (short[])_x;
			subframe += suboffset;// java
			for( int j = suboffset, joc = xoffset + offset * C + c1; j < subframe; j++, joc += C ) {
				sub[j] = (float)x[joc];
			}
			if( c2 > -1 )
			{
				for( int j = suboffset, joc = xoffset + offset * C + c2; j < subframe; j++, joc += C ) {
					sub[j] += (float)x[joc];
				}
			} else if( c2 == -2 )
			{
				for( int c = 1; c < C; c++ )
				{
					for( int j = suboffset, joc = xoffset + offset * C + c; j < subframe; j++, joc += C ) {
						sub[j] += (float)x[joc];
					}
				}
			}
	/* #ifdef FIXED_POINT
			scale = (1 << SIG_SHIFT);
	#else */
			float scale = 1.f / 32768f;
	// #endif
			if( C == -2 ) {
				scale /= -2f;// java: changed to -2f to avoid casting C;
			} else {
				scale /= 2f;// FIXME may be * 0.5f is better way?
			}
			for( int j = suboffset; j < subframe; j++ ) {
				sub[j] *= scale;
			}
		}

	}
	static final Jdownmix_int downmix_int = new Jdownmix_int();
/*
	private static final void downmix_int(final short[] x, final float[] sub, final int subframe, final int offset, final int c1, final int c2, final int C)
	{
		for( int j = 0, joc = offset * C + c1; j < subframe; j++, joc += C ) {
			sub[j] = (float)x[joc];
		}
		if( c2 > -1 )
		{
			for( int j = 0, joc = offset * C + c2; j < subframe; j++, joc += C ) {
				sub[j] += (float)x[joc];
			}
		} else if( c2 == -2 )
		{
			for( int c = 1; c < C; c++ )
			{
				for( int j = 0, joc = offset * C + c; j < subframe; j++, joc += C ) {
					sub[j] += (float)x[joc];
				}
			}
		}
// #ifdef FIXED_POINT
//		scale = (1 << SIG_SHIFT);
// #else
		float scale = 1.f / 32768f;
// #endif
		if( C == -2 ) {
			scale /= C;
		} else {
			scale /= 2f;
		}
		for( int j = 0; j < subframe; j++ ) {
			sub[j] *= scale;
		}
	}
*/
	private static final int frame_size_select(final int frame_size, final int variable_duration, final int Fs)
	{
		int new_size;
		if( frame_size < Fs / 400 ) {
			return -1;
		}
		if( variable_duration == Jopus_defines.OPUS_FRAMESIZE_ARG ) {
			new_size = frame_size;
		} else if( variable_duration == Jcelt.OPUS_FRAMESIZE_VARIABLE ) {
			new_size = Fs / 50;
		} else if( variable_duration >= Jopus_defines.OPUS_FRAMESIZE_2_5_MS && variable_duration <= Jopus_defines.OPUS_FRAMESIZE_60_MS ) {
			new_size = 3 * Fs / 50;
			final int v = (Fs / 400) << (variable_duration - Jopus_defines.OPUS_FRAMESIZE_2_5_MS);
			new_size = new_size < v ? new_size : v;
		} else {
			return -1;
		}
		if( new_size > frame_size ) {
			return -1;
		}
		if( 400 * new_size != Fs && 200 * new_size != Fs && 100 * new_size != Fs &&
			50 * new_size != Fs  && 25 * new_size != Fs && 50 * new_size != 3 * Fs ) {
			return -1;
		}
		return new_size;
	}

	static final int compute_frame_size(final Object analysis_pcm, final int pcmoffset,// java
			int frame_size,
			final int variable_duration, final int C, final int Fs, final int bitrate_bps,
			final int delay_compensation, final Idownmix downmix// downmix_func downmix
// #ifndef DISABLE_FLOAT_API
			, final float[] subframe_mem
// #endif
			)
	{
// #ifndef DISABLE_FLOAT_API
		if( variable_duration == Jcelt.OPUS_FRAMESIZE_VARIABLE && frame_size >= Fs / 200 )
		{
			int LM = 3;
			LM = optimize_framesize( analysis_pcm, pcmoffset, frame_size, C, Fs, bitrate_bps,
					0, subframe_mem, delay_compensation, downmix );
			while( (Fs / 400 << LM) > frame_size ) {
				LM--;
			}
			frame_size = (Fs / 400 << LM);
		} else
/* #else
		(void)analysis_pcm;
		(void)C;
		(void)bitrate_bps;
		(void)delay_compensation;
		(void)downmix;
#endif */
		{
			frame_size = frame_size_select( frame_size, variable_duration, Fs );
		}
		if( frame_size < 0 ) {
			return -1;
		}
		return frame_size;
	}

	private static final float compute_stereo_width(final float[] pcm, final int pcmoffset,// java
			int frame_size, final int Fs, final JStereoWidthState mem)
	{
		float xx, xy, yy;
		final int frame_rate = Fs / frame_size;
		final float short_alpha = Jfloat_cast.Q15ONE - 25 * Jfloat_cast.Q15ONE / (50 > frame_rate ? 50 : frame_rate);
		xx = xy = yy = 0;
		/* Unroll by 4. The frame size is always a multiple of 4 *except* for
		 2.5 ms frames at 12 kHz. Since this setting is very rare (and very
		 stupid), we just discard the last two samples. */
		frame_size -= 3;
		frame_size <<= 1;// java
		for( int i2 = 0; i2 < frame_size; /* i2 += 4 * 2 */ )
		{
			float x = pcm[i2++];
			float y = pcm[i2++];
			float pxx = x * x;
			float pxy = x * y;
			float pyy = y * y;
			x = pcm[i2++];
			y = pcm[i2++];
			pxx += x * x;
			pxy += x * y;
			pyy += y * y;
			x = pcm[i2++];
			y = pcm[i2++];
			pxx += x * x;
			pxy += x * y;
			pyy += y * y;
			x = pcm[i2++];
			y = pcm[i2++];
			pxx += x * x;
			pxy += x * y;
			pyy += y * y;

			xx += pxx;
			xy += pxy;
			yy += pyy;
		}
		mem.XX += short_alpha * (xx - mem.XX);
		mem.XY += short_alpha * (xy - mem.XY);
		mem.YY += short_alpha * (yy - mem.YY);
		mem.XX = 0 > mem.XX ? 0 : mem.XX;
		mem.XY = 0 > mem.XY ? 0 : mem.XY;
		mem.YY = 0 > mem.YY ? 0 : mem.YY;

		if( (mem.XX > mem.YY ? mem.XX : mem.YY) > 8e-4f )
		{
			final float sqrt_xx = (float)Math.sqrt( (double)mem.XX );
			final float sqrt_yy = (float)Math.sqrt( (double)mem.YY );
			final float qrrt_xx = (float)Math.sqrt( (double)sqrt_xx );
			final float qrrt_yy = (float)Math.sqrt( (double)sqrt_yy );
			/* Inter-channel correlation */
			float v = sqrt_xx * sqrt_yy;// java
			mem.XY = mem.XY <= v ? mem.XY : v;
			final float corr = mem.XY / (Jfloat_cast.EPSILON + sqrt_xx * sqrt_yy);
			/* Approximate loudness difference */
			v = qrrt_xx - qrrt_yy;// java
			if( v < 0 ) {
				v = -v;
			}
			final float ldiff = Jfloat_cast.Q15ONE * v / (Jfloat_cast.EPSILON + qrrt_xx + qrrt_yy);
			final float width = (float)Math.sqrt( (double)(1.f - corr * corr) ) * ldiff;
			/* Smoothing over one second */
			mem.smoothed_width += (width - mem.smoothed_width) / frame_rate;
			/* Peak follower */
			v = mem.max_follower - .02f / frame_rate;// java
			mem.max_follower = v > mem.smoothed_width ? v : mem.smoothed_width;
		}
		/*printf("%f %f %f %f %f ", corr/(float)Q15ONE, ldiff/(float)Q15ONE, width/(float)Q15ONE, mem.smoothed_width/(float)Q15ONE, mem.max_follower/(float)Q15ONE);*/
		final float v = 20 * mem.max_follower;// java
		return (Jfloat_cast.Q15ONE < v ? Jfloat_cast.Q15ONE : v);
	}

	final int opus_encode_native(
			final float[] pcm, final int pcmoffset,// java
			final int frame_size,
			final byte[] data, int doffset,// java
			final int out_data_bytes, int lsbdepth,
			final Object analysis_pcm, final int aoffset,// java
			final int analysis_size, final int c1, final int c2,
			final int analysis_channels, final Idownmix/*downmix_func*/ downmix, final boolean float_api)
	{
		int ret = 0;
		// ALLOC_STACK;

		int max_data_bytes = 1276 < out_data_bytes ? 1276 : out_data_bytes; /* Max number of bytes we're allowed to use */

		this.rangeFinal = 0;
		if( (0 == this.variable_duration && 400 * frame_size != this.Fs && 200 * frame_size != this.Fs && 100 * frame_size != this.Fs &&
				50 * frame_size != this.Fs && 25 * frame_size != this.Fs && 50 * frame_size != 3 * this.Fs )
				|| (400 * frame_size < this.Fs)
				|| max_data_bytes <= 0
				)
		{
			// RESTORE_STACK;
			return Jopus_defines.OPUS_BAD_ARG;
		}
		final Jsilk_encoder silkenc = this.silk_enc;
		final JCELTEncoder celtenc = this.celt_enc;
		final int delay_comp = (this.application == Jopus_defines.OPUS_APPLICATION_RESTRICTED_LOWDELAY) ? 0 : this.delay_compensation;

		lsbdepth = lsbdepth < this.lsb_depth ? lsbdepth : this.lsb_depth;

		final Object[] request = new Object[1];// java helper
		celtenc.celt_encoder_ctl( Jcelt.CELT_GET_MODE, request );
		final JCELTMode celt_mode = (JCELTMode)request[0];// java
// #ifndef DISABLE_FLOAT_API
		final JAnalysisInfo analysis_info = new JAnalysisInfo();
		int analysis_read_pos_bak = -1;
		int analysis_read_subframe_bak = -1;
		analysis_info.valid = false;
/* #ifdef FIXED_POINT
		if( st.silk_mode.complexity >= 10  &&  st.Fs == 48000 )
#else */
		if( this.silk_mode.complexity >= 7 && this.Fs == 48000 )
// #endif
		{
			analysis_read_pos_bak = this.analysis.read_pos;
			analysis_read_subframe_bak = this.analysis.read_subframe;
			this.analysis.run_analysis( celt_mode, analysis_pcm, aoffset, analysis_size, frame_size,
					c1, c2, analysis_channels, this.Fs,
					lsbdepth, downmix, analysis_info );
		}
/* #else
		(void)analysis_pcm;
		(void)analysis_size;
#endif */

		this.voice_ratio = -1;

// #ifndef DISABLE_FLOAT_API
		this.detected_bandwidth = 0;
		if( analysis_info.valid )
		{
			int analysis_bandwidth;
			if( this.signal_type == Jopus_defines.OPUS_AUTO ) {
				this.voice_ratio = (int)Math.floor( (double)(.5f + 100f * (1f - analysis_info.music_prob)) );
			}

			analysis_bandwidth = analysis_info.bandwidth;
			if( analysis_bandwidth <= 12 ) {
				this.detected_bandwidth = Jopus_defines.OPUS_BANDWIDTH_NARROWBAND;
			} else if( analysis_bandwidth <= 14 ) {
				this.detected_bandwidth = Jopus_defines.OPUS_BANDWIDTH_MEDIUMBAND;
			} else if( analysis_bandwidth <= 16 ) {
				this.detected_bandwidth = Jopus_defines.OPUS_BANDWIDTH_WIDEBAND;
			} else if( analysis_bandwidth <= 18 ) {
				this.detected_bandwidth = Jopus_defines.OPUS_BANDWIDTH_SUPERWIDEBAND;
			} else {
				this.detected_bandwidth = Jopus_defines.OPUS_BANDWIDTH_FULLBAND;
			}
		}
// #endif

		final float stereo_width = (this.channels == 2 && this.force_channels != 1) ?
					compute_stereo_width( pcm, pcmoffset, frame_size, this.Fs, this.width_mem ) : 0;

		final int total_buffer = delay_comp;
		this.bitrate_bps = user_bitrate_to_bitrate( frame_size, max_data_bytes );

		final int frame_rate = this.Fs / frame_size;
		if( ! this.use_vbr )
		{
			/* Multiply by 3 to make sure the division is exact. */
			final int frame_rate3 = 3 * this.Fs / frame_size;
			/* We need to make sure that "int" values always fit in 16 bits. */
			int cbrBytes = (((3 * this.bitrate_bps) >> 3) + (frame_rate3 >> 1)) / frame_rate3;
			cbrBytes = ( cbrBytes <= max_data_bytes ? cbrBytes : max_data_bytes );
			this.bitrate_bps = ((cbrBytes * frame_rate3) << 3) / 3;
			max_data_bytes = cbrBytes;
		}
		if( max_data_bytes < 3 || this.bitrate_bps < ((3 * frame_rate) << 3)
			|| (frame_rate < 50 && (max_data_bytes * frame_rate < 300 || this.bitrate_bps < 2400)) )
		{
			/*If the space is too low to do something useful, emit 'PLC' frames.*/
			int tocmode = this.mode;
			int bw = this.bandwidth == 0 ? Jopus_defines.OPUS_BANDWIDTH_NARROWBAND : this.bandwidth;
			if( tocmode == 0 ) {
				tocmode = Jopus_private.MODE_SILK_ONLY;
			}
			if( frame_rate > 100 ) {
				tocmode = Jopus_private.MODE_CELT_ONLY;
			}
			if( frame_rate < 50 ) {
				tocmode = Jopus_private.MODE_SILK_ONLY;
			}
			if( tocmode == Jopus_private.MODE_SILK_ONLY && bw > Jopus_defines.OPUS_BANDWIDTH_WIDEBAND ) {
				bw = Jopus_defines.OPUS_BANDWIDTH_WIDEBAND;
			} else if( tocmode == Jopus_private.MODE_CELT_ONLY && bw == Jopus_defines.OPUS_BANDWIDTH_MEDIUMBAND ) {
				bw = Jopus_defines.OPUS_BANDWIDTH_NARROWBAND;
			} else if( tocmode == Jopus_private.MODE_HYBRID && bw <= Jopus_defines.OPUS_BANDWIDTH_SUPERWIDEBAND ) {
				bw = Jopus_defines.OPUS_BANDWIDTH_SUPERWIDEBAND;
			}
			data[doffset] = (byte)gen_toc( tocmode, frame_rate, bw, this.stream_channels );
			ret = 1;
			if( ! this.use_vbr )
			{
				ret = JOpusRepacketizer.opus_packet_pad( data, doffset, ret, max_data_bytes );
				if( ret == Jopus_defines.OPUS_OK ) {
					ret = max_data_bytes;
				}
			}
			// RESTORE_STACK;
			return ret;
		}
		final int max_rate = (frame_rate * max_data_bytes) << 3; /* Max bitrate we're allowed to use */

		/* Equivalent 20-ms rate for mode/channel/bandwidth decisions */
		int equiv_rate = this.bitrate_bps - (40 * this.channels + 20) * (this.Fs / frame_size - 50);

		int voice_est; /* Probability of voice in Q7 */
		if( this.signal_type == Jopus_defines.OPUS_SIGNAL_VOICE ) {
			voice_est = 127;
		} else if( this.signal_type == Jopus_defines.OPUS_SIGNAL_MUSIC ) {
			voice_est = 0;
		} else if( this.voice_ratio >= 0 )
		{
			voice_est = this.voice_ratio * 327 >> 8;
				/* For AUDIO, never be more than 90% confident of having speech */
				if( this.application == Jopus_defines.OPUS_APPLICATION_AUDIO ) {
					voice_est = voice_est < 115 ? voice_est : 115;
				}
		} else if( this.application == Jopus_defines.OPUS_APPLICATION_VOIP) {
			voice_est = 115;
		} else {
			voice_est = 48;
		}

		if( this.force_channels != Jopus_defines.OPUS_AUTO && this.channels == 2 )
		{
			this.stream_channels = this.force_channels;
		} else {
/* #ifdef FUZZING
			// Random mono/stereo decision
			if( st.channels == 2 && (rand() & 0x1F) == 0 )
				st.stream_channels = 3 - st.stream_channels;
#else */
			/* Rate-dependent mono-stereo decision */
			if( this.channels == 2 )
			{
				int stereo_threshold = stereo_music_threshold + ((voice_est * voice_est * (stereo_voice_threshold - stereo_music_threshold)) >> 14);
				if( this.stream_channels == 2 ) {
					stereo_threshold -= 1000;
				} else {
					stereo_threshold += 1000;
				}
				this.stream_channels = (equiv_rate > stereo_threshold) ? 2 : 1;
			} else {
				this.stream_channels = this.channels;
			}
// #endif
		}
		equiv_rate = this.bitrate_bps - (40 * this.stream_channels + 20) * (this.Fs / frame_size - 50);

		/* Mode selection depending on application and signal type */
		if( this.application == Jopus_defines.OPUS_APPLICATION_RESTRICTED_LOWDELAY )
		{
			this.mode = Jopus_private.MODE_CELT_ONLY;
		} else if( this.user_forced_mode == Jopus_defines.OPUS_AUTO )
		{
/* #ifdef FUZZING
			// Random mode switching
			if( (rand() & 0xF) == 0 )
			{
				if( (rand() & 0x1) == 0 )
					st.mode = MODE_CELT_ONLY;
				else
					st.mode = MODE_SILK_ONLY;
			} else {
				if( st.prev_mode == MODE_CELT_ONLY )
					st.mode = MODE_CELT_ONLY;
				else
					st.mode = MODE_SILK_ONLY;
			}
#else */
			/* Interpolate based on stereo width */
			final int mode_voice = (int)((Jfloat_cast.Q15ONE - stereo_width) * mode_thresholds[0][0]
									+ stereo_width * mode_thresholds[1][0] );
			final int mode_music = (int)((Jfloat_cast.Q15ONE - stereo_width) * mode_thresholds[1][1]
									+ stereo_width * mode_thresholds[1][1]);
			/* Interpolate based on speech/music probability */
			int threshold = mode_music + ((voice_est * voice_est * (mode_voice - mode_music)) >> 14);
			/* Bias towards SILK for VoIP because of some useful features */
			if( this.application == Jopus_defines.OPUS_APPLICATION_VOIP ) {
				threshold += 8000;
			}

			/*printf("%f %d\n", stereo_width/(float)Q15ONE, threshold);*/
			/* Hysteresis */
			if( this.prev_mode == Jopus_private.MODE_CELT_ONLY ) {
				threshold -= 4000;
			} else if( this.prev_mode > 0 ) {
				threshold += 4000;
			}

			this.mode = (equiv_rate >= threshold) ? Jopus_private.MODE_CELT_ONLY : Jopus_private.MODE_SILK_ONLY;

			/* When FEC is enabled and there's enough packet loss, use SILK */
			if( this.silk_mode.useInBandFEC && this.silk_mode.packetLossPercentage > (128 - voice_est) >> 4 ) {
				this.mode = Jopus_private.MODE_SILK_ONLY;
			}
			/* When encoding voice and DTX is enabled, set the encoder to SILK mode (at least for now) */
			if( this.silk_mode.useDTX && voice_est > 100 ) {
				this.mode = Jopus_private.MODE_SILK_ONLY;
			}
// #endif
		} else {
			this.mode = this.user_forced_mode;
		}

		/* Override the chosen mode to make sure we meet the requested frame size */
		if( this.mode != Jopus_private.MODE_CELT_ONLY && frame_size < this.Fs / 100 ) {
			this.mode = Jopus_private.MODE_CELT_ONLY;
		}
		if( this.lfe ) {
			this.mode = Jopus_private.MODE_CELT_ONLY;
		}
		/* If max_data_bytes represents less than 8 kb/s, switch to CELT-only mode */
		if( max_data_bytes < (frame_rate > 50 ? 12000 : 8000) * frame_size / (this.Fs * 8) ) {
			this.mode = Jopus_private.MODE_CELT_ONLY;
		}

		if( this.stream_channels == 1 && this.prev_channels == 2 && ! this.silk_mode.toMono
			&& this.mode != Jopus_private.MODE_CELT_ONLY && this.prev_mode != Jopus_private.MODE_CELT_ONLY )
		{
			/* Delay stereo.mono transition by two frames so that SILK can do a smooth downmix */
			this.silk_mode.toMono = true;
			this.stream_channels = 2;
		} else {
			this.silk_mode.toMono = false;
		}

		boolean to_celt = false;
		boolean redundancy = false;
		boolean celt_to_silk = false;
		if( this.prev_mode > 0 &&
			((this.mode != Jopus_private.MODE_CELT_ONLY && this.prev_mode == Jopus_private.MODE_CELT_ONLY) ||
			(this.mode == Jopus_private.MODE_CELT_ONLY && this.prev_mode != Jopus_private.MODE_CELT_ONLY)) )
		{
			redundancy = true;
			celt_to_silk = (this.mode != Jopus_private.MODE_CELT_ONLY);
			if( ! celt_to_silk )
			{
				/* Switch to SILK/hybrid if frame size is 10 ms or more*/
				if( frame_size >= this.Fs / 100 )
				{
					this.mode = this.prev_mode;
					to_celt = true;
				} else {
					redundancy = false;
				}
			}
		}
		boolean prefill = false;
		/* For the first frame at a new SILK bandwidth */
		if( this.silk_bw_switch )
		{
			redundancy = true;
			celt_to_silk = true;
			this.silk_bw_switch = false;
			prefill = true;
		}

		int redundancy_bytes = 0; /* Number of bytes to use for redundancy frame */
		if( redundancy )
		{
			/* Fair share of the max size allowed */
			redundancy_bytes = max_data_bytes * (this.Fs / 200) / (frame_size + this.Fs / 200);
			redundancy_bytes = 257 < redundancy_bytes ? 257 : redundancy_bytes;
			/* For VBR, target the actual bitrate (subject to the limit above) */
			if( this.use_vbr ) {
				final int v = this.bitrate_bps / 1600;// java
				redundancy_bytes = redundancy_bytes < v ? redundancy_bytes : v;
			}
		}

		if( this.mode != Jopus_private.MODE_CELT_ONLY && this.prev_mode == Jopus_private.MODE_CELT_ONLY )
		{
			final Jsilk_EncControlStruct dummy = new Jsilk_EncControlStruct();
			silkenc.silk_InitEncoder( /*, st.arch*/ dummy );
			prefill = true;
		}

		/* Automatic (rate-dependent) bandwidth selection */
		if( this.mode == Jopus_private.MODE_CELT_ONLY || this.first || this.silk_mode.allowBandwidthSwitch )
		{
			final int[] voice_bandwidth_thresholds, music_bandwidth_thresholds;
			final int bandwidth_thresholds[] = new int[8];
			int band = Jopus_defines.OPUS_BANDWIDTH_FULLBAND;

			int equiv_rate2 = equiv_rate;
			if( this.mode != Jopus_private.MODE_CELT_ONLY )
			{
				/* Adjust the threshold +/- 10% depending on complexity */
				equiv_rate2 = equiv_rate2 * (45 + this.silk_mode.complexity) / 50;
				/* CBR is less efficient by ~1 kb/s */
				if( ! this.use_vbr ) {
					equiv_rate2 -= 1000;
				}
			}
			if( this.channels == 2 && this.force_channels != 1 )
			{
				voice_bandwidth_thresholds = stereo_voice_bandwidth_thresholds;
				music_bandwidth_thresholds = stereo_music_bandwidth_thresholds;
			} else {
				voice_bandwidth_thresholds = mono_voice_bandwidth_thresholds;
				music_bandwidth_thresholds = mono_music_bandwidth_thresholds;
			}
			/* Interpolate bandwidth thresholds depending on voice estimation */
			for( int i = 0; i < 8; i++ )
			{
				bandwidth_thresholds[i] = music_bandwidth_thresholds[i]
						+ ((voice_est * voice_est * (voice_bandwidth_thresholds[i] - music_bandwidth_thresholds[i])) >> 14);
			}
			do {
				int i = (band - Jopus_defines.OPUS_BANDWIDTH_MEDIUMBAND) << 1;// java
				int threshold = bandwidth_thresholds[i++];
				final int hysteresis = bandwidth_thresholds[i];
				if( ! this.first )
				{
					if( this.bandwidth >= band ) {
						threshold -= hysteresis;
					} else {
						threshold += hysteresis;
					}
				}
				if( equiv_rate2 >= threshold ) {
					break;
				}
			} while( --band > Jopus_defines.OPUS_BANDWIDTH_NARROWBAND );
			this.bandwidth = band;
			/* Prevents any transition to SWB/FB until the SILK layer has fully
			   switched to WB mode and turned the variable LP filter off */
			if( ! this.first && this.mode != Jopus_private.MODE_CELT_ONLY && ! this.silk_mode.inWBmodeWithoutVariableLP && this.bandwidth > Jopus_defines.OPUS_BANDWIDTH_WIDEBAND ) {
				this.bandwidth = Jopus_defines.OPUS_BANDWIDTH_WIDEBAND;
			}
		}

		if( this.bandwidth > this.max_bandwidth ) {
			this.bandwidth = this.max_bandwidth;
		}

		if( this.user_bandwidth != Jopus_defines.OPUS_AUTO ) {
			this.bandwidth = this.user_bandwidth;
		}

		/* This prevents us from using hybrid at unsafe CBR/max rates */
		if( this.mode != Jopus_private.MODE_CELT_ONLY && max_rate < 15000 )
		{
			this.bandwidth = this.bandwidth < Jopus_defines.OPUS_BANDWIDTH_WIDEBAND ? this.bandwidth : Jopus_defines.OPUS_BANDWIDTH_WIDEBAND;
		}

		/* Prevents Opus from wasting bits on frequencies that are above
		   the Nyquist rate of the input signal */
		if( this.Fs <= 24000 && this.bandwidth > Jopus_defines.OPUS_BANDWIDTH_SUPERWIDEBAND ) {
			this.bandwidth = Jopus_defines.OPUS_BANDWIDTH_SUPERWIDEBAND;
		}
		if( this.Fs <= 16000 && this.bandwidth > Jopus_defines.OPUS_BANDWIDTH_WIDEBAND ) {
			this.bandwidth = Jopus_defines.OPUS_BANDWIDTH_WIDEBAND;
		}
		if( this.Fs <= 12000 && this.bandwidth > Jopus_defines.OPUS_BANDWIDTH_MEDIUMBAND ) {
			this.bandwidth = Jopus_defines.OPUS_BANDWIDTH_MEDIUMBAND;
		}
		if( this.Fs <= 8000 && this.bandwidth > Jopus_defines.OPUS_BANDWIDTH_NARROWBAND ) {
			this.bandwidth = Jopus_defines.OPUS_BANDWIDTH_NARROWBAND;
		}
// #ifndef DISABLE_FLOAT_API
		/* Use detected bandwidth to reduce the encoded bandwidth. */
		if( 0 != this.detected_bandwidth && this.user_bandwidth == Jopus_defines.OPUS_AUTO )
		{
			int min_detected_bandwidth;
			/* Makes bandwidth detection more conservative just in case the detector
			   gets it wrong when we could have coded a high bandwidth transparently.
			   When operating in SILK/hybrid mode, we don't go below wideband to avoid
			   more complicated switches that require redundancy. */
			if( equiv_rate <= 18000 * this.stream_channels && this.mode == Jopus_private.MODE_CELT_ONLY ) {
				min_detected_bandwidth = Jopus_defines.OPUS_BANDWIDTH_NARROWBAND;
			} else if( equiv_rate <= 24000 * this.stream_channels && this.mode == Jopus_private.MODE_CELT_ONLY ) {
				min_detected_bandwidth = Jopus_defines.OPUS_BANDWIDTH_MEDIUMBAND;
			} else if( equiv_rate <= 30000 * this.stream_channels ) {
				min_detected_bandwidth = Jopus_defines.OPUS_BANDWIDTH_WIDEBAND;
			} else if( equiv_rate <= 44000 * this.stream_channels ) {
				min_detected_bandwidth = Jopus_defines.OPUS_BANDWIDTH_SUPERWIDEBAND;
			} else {
				min_detected_bandwidth = Jopus_defines.OPUS_BANDWIDTH_FULLBAND;
			}

			this.detected_bandwidth = this.detected_bandwidth > min_detected_bandwidth ? this.detected_bandwidth : min_detected_bandwidth;
			this.bandwidth = this.bandwidth < this.detected_bandwidth ? this.bandwidth : this.detected_bandwidth;
		}
// #endif
		celtenc.celt_encoder_ctl( Jopus_defines.OPUS_SET_LSB_DEPTH, lsbdepth );

		/* CELT mode doesn't support mediumband, use wideband instead */
		if( this.mode == Jopus_private.MODE_CELT_ONLY && this.bandwidth == Jopus_defines.OPUS_BANDWIDTH_MEDIUMBAND ) {
			this.bandwidth = Jopus_defines.OPUS_BANDWIDTH_WIDEBAND;
		}
		if( this.lfe ) {
			this.bandwidth = Jopus_defines.OPUS_BANDWIDTH_NARROWBAND;
		}

		/* Can't support higher than wideband for >20 ms frames */
		if( frame_size > this.Fs / 50 && (this.mode == Jopus_private.MODE_CELT_ONLY || this.bandwidth > Jopus_defines.OPUS_BANDWIDTH_WIDEBAND) )
		{
// #ifndef DISABLE_FLOAT_API
			if( analysis_read_pos_bak != -1 )
			{
				this.analysis.read_pos = analysis_read_pos_bak;
				this.analysis.read_subframe = analysis_read_subframe_bak;
			}
// #endif

			final int nb_frames = frame_size > this.Fs / 25 ? 3 : 2;
			int bytes_per_frame = (out_data_bytes - 3) / nb_frames;
			bytes_per_frame = ( 1276 <= bytes_per_frame ? 1276 : bytes_per_frame );

			final byte[] tmp_data = new byte[nb_frames * bytes_per_frame];

			final JOpusRepacketizer rp = new JOpusRepacketizer().opus_repacketizer_init();

			final int bak_mode = this.user_forced_mode;
			final int bak_bandwidth = this.user_bandwidth;
			final int bak_channels = this.force_channels;

			this.user_forced_mode = this.mode;
			this.user_bandwidth = this.bandwidth;
			this.force_channels = this.stream_channels;
			final boolean bak_to_mono = this.silk_mode.toMono;

			this.force_channels = bak_to_mono ? 1 : this.stream_channels;

			for( int i = 0; i < nb_frames; i++ )
			{
				this.silk_mode.toMono = false;
				/* When switching from SILK/Hybrid to CELT, only ask for a switch at the last frame */
				if( to_celt && i == nb_frames - 1 ) {
					this.user_forced_mode = Jopus_private.MODE_CELT_ONLY;
				}
				final int tmp_len = opus_encode_native( pcm, pcmoffset + i * (this.channels * this.Fs / 50), this.Fs / 50,
						tmp_data, i * bytes_per_frame, bytes_per_frame, lsbdepth,
						null, 0, 0, c1, c2, analysis_channels, downmix, float_api);
				if( tmp_len < 0 )
				{
					// RESTORE_STACK;
					return Jopus_defines.OPUS_INTERNAL_ERROR;
				}
				ret = rp.opus_repacketizer_cat( tmp_data, i * bytes_per_frame, tmp_len );
				if( ret < 0 )
				{
					// RESTORE_STACK;
					return Jopus_defines.OPUS_INTERNAL_ERROR;
				}
			}
			int repacketize_len;
			if( this.use_vbr ) {
				repacketize_len = out_data_bytes;
			} else {
				repacketize_len = 3 * this.bitrate_bps / (3 * 8 * 50 / nb_frames);
				repacketize_len = repacketize_len < out_data_bytes ? repacketize_len : out_data_bytes;
			}
			ret = rp.opus_repacketizer_out_range_impl( 0, nb_frames, data, doffset, repacketize_len, false, ! this.use_vbr );
			if( ret < 0 )
			{
				// RESTORE_STACK;
				return Jopus_defines.OPUS_INTERNAL_ERROR;
			}
			this.user_forced_mode = bak_mode;
			this.user_bandwidth = bak_bandwidth;
			this.force_channels = bak_channels;
			this.silk_mode.toMono = bak_to_mono;
			// RESTORE_STACK;
			return ret;
		}
		int curr_bandwidth = this.bandwidth;

		/* Chooses the appropriate mode for speech
		   *NEVER* switch to/from CELT-only mode here as this will invalidate some assumptions */
		if( this.mode == Jopus_private.MODE_SILK_ONLY && curr_bandwidth > Jopus_defines.OPUS_BANDWIDTH_WIDEBAND ) {
			this.mode = Jopus_private.MODE_HYBRID;
		}
		if( this.mode == Jopus_private.MODE_HYBRID && curr_bandwidth <= Jopus_defines.OPUS_BANDWIDTH_WIDEBAND ) {
			this.mode = Jopus_private.MODE_SILK_ONLY;
		}

		/* printf("%d %d %d %d\n", st.bitrate_bps, st.stream_channels, st.mode, curr_bandwidth); */
		int v = max_data_bytes - redundancy_bytes;// java
		int bytes_target = this.bitrate_bps * frame_size / (this.Fs * 8);
		bytes_target = ( v <= bytes_target ? v : bytes_target ) - 1;

		doffset++;// data += 1;

		final Jec_enc enc = new Jec_enc();
		enc.ec_enc_init( data, doffset, max_data_bytes - 1 );

		final float[] pcm_buf = new float[(total_buffer + frame_size) * this.channels];
		// OPUS_COPY( pcm_buf, &st.delay_buffer[(st.encoder_buffer - total_buffer) * st.channels], total_buffer * st.channels );
		System.arraycopy( this.delay_buffer, (this.encoder_buffer - total_buffer) * this.channels, pcm_buf, 0, total_buffer * this.channels );

		final int hp_freq_smth1 = ( this.mode == Jopus_private.MODE_CELT_ONLY ) ?
					Jmacros.silk_lin2log( Jtuning_parameters.VARIABLE_HP_MIN_CUTOFF_HZ ) << 8
					:
					silkenc.state_Fxx[0].sCmn.variable_HP_smth1_Q15;

		// this.variable_HP_smth2_Q15 = Jmacros.silk_SMLAWB( this.variable_HP_smth2_Q15,
		//		hp_freq_smth1 - this.variable_HP_smth2_Q15, SILK_FIX_CONST( Jtuning_parameters.VARIABLE_HP_SMTH_COEF2, 16 ) );
		this.variable_HP_smth2_Q15 += (int)(((hp_freq_smth1 - this.variable_HP_smth2_Q15) *
							(long)(Jtuning_parameters.VARIABLE_HP_SMTH_COEF2 * (1 << 16 ) + 0.5f)) >> 16);
		/* convert from log scale to Hertz */
		final int cutoff_Hz = Jmacros.silk_log2lin( this.variable_HP_smth2_Q15 >> 8 );

		if( this.application == Jopus_defines.OPUS_APPLICATION_VOIP )
		{
			hp_cutoff( pcm, pcmoffset, cutoff_Hz, pcm_buf, total_buffer * this.channels, this.hp_mem, frame_size, this.channels, this.Fs );
		} else {
			dc_reject( pcm, pcmoffset, 3, pcm_buf, total_buffer * this.channels, this.hp_mem, frame_size, this.channels, this.Fs );
		}
// #ifndef FIXED_POINT
		if( float_api )
		{
			final float sum = Jcelt_codec_API.celt_inner_prod( pcm_buf, total_buffer * this.channels, pcm_buf, total_buffer * this.channels, frame_size * this.channels );//, st.arch );
			/* This should filter out both NaNs and ridiculous signals that could
			   cause NaNs further down. */
			if( !(sum < 1e9f) || Float.isNaN( sum ) )
			{
				// OPUS_CLEAR( &pcm_buf[total_buffer * st.channels], frame_size * st.channels );
				for( int i = total_buffer * this.channels, ie = i + frame_size * this.channels; i < ie; i++ ) {
					pcm_buf[i] = i;
				}
				this.hp_mem[0] = this.hp_mem[1] = this.hp_mem[2] = this.hp_mem[3] = 0;
			}
		}
// #endif

		/* SILK processing */
		float HB_gain = Jfloat_cast.Q15ONE;
		if( this.mode != Jopus_private.MODE_CELT_ONLY )
		{
/* #ifdef FIXED_POINT
			const opus_int16 *pcm_silk;
#else */
			final short[] pcm_silk = new short[this.channels * frame_size];
// #endif

			/* Distribute bits between SILK and CELT */
			final int total_bitRate = (bytes_target * frame_rate) << 3;
			if( this.mode == Jopus_private.MODE_HYBRID ) {
				int HB_gain_ref;
				/* Base rate for SILK */
				this.silk_mode.bitRate = this.stream_channels * (5000 + (this.Fs == 100 * frame_size ? 1000 : 0));
				if( curr_bandwidth == Jopus_defines.OPUS_BANDWIDTH_SUPERWIDEBAND ) {
					/* SILK gets 2/3 of the remaining bits */
					this.silk_mode.bitRate += ((total_bitRate - this.silk_mode.bitRate) << 1) / 3;
				} else { /* FULLBAND */
					/* SILK gets 3/5 of the remaining bits */
					this.silk_mode.bitRate += (total_bitRate - this.silk_mode.bitRate) * 3 / 5;
				}
				/* Don't let SILK use more than 80% */
				if( this.silk_mode.bitRate > (total_bitRate << 2) / 5 ) {
					this.silk_mode.bitRate = (total_bitRate << 2) / 5;
				}
				if( null == this.energy_masking )
				{
					/* Increasingly attenuate high band when it gets allocated fewer bits */
					final int celt_rate = total_bitRate - this.silk_mode.bitRate;
					HB_gain_ref = (curr_bandwidth == Jopus_defines.OPUS_BANDWIDTH_SUPERWIDEBAND) ? 3000 : 3600;
					HB_gain = (float)celt_rate / (float)(celt_rate + this.stream_channels * HB_gain_ref);
					HB_gain = HB_gain < Jfloat_cast.Q15ONE * 6 / 7 ? HB_gain +Jfloat_cast. Q15ONE / 7 : Jfloat_cast.Q15ONE;
				}
			} else {
				/* SILK gets all bits */
				this.silk_mode.bitRate = total_bitRate;
			}

			/* Surround masking for SILK */
			if( null != this.energy_masking && this.use_vbr && ! this.lfe )
			{
				float mask_sum = 0;
				int end = 17;
				float srate = 16000f;// FIXME why int16?
				if( this.bandwidth == Jopus_defines.OPUS_BANDWIDTH_NARROWBAND )
				{
					end = 13;
					srate = 8000f;
				} else if( this.bandwidth == Jopus_defines.OPUS_BANDWIDTH_MEDIUMBAND )
				{
					end = 15;
					srate = 12000f;
				}
				for( int c = 0; c < this.channels; c++ )
				{
					for( int i = 0; i < end; i++ )
					{
						//float mask = MAX16( MIN16( st.energy_masking[21 * c + i], .5f), -2.0f );
						float mask = this.energy_masking[21 * c + i];
						mask = mask <= .5f ? mask : .5f;
						mask = mask >= -2.0f ? mask : -2.0f;
						if( mask > 0 ) {
							mask *= .5f;
						}
						mask_sum += mask;
					}
				}
				/* Conservative rate reduction, we cut the masking in half */
				float masking_depth = mask_sum / end * this.channels;
				masking_depth += .2f;
				int rate_offset = (int)(srate * masking_depth);
				v = -2 * this.silk_mode.bitRate / 3;// java
				rate_offset = rate_offset >= v ? rate_offset : v;
				/* Split the rate change between the SILK and CELT part for hybrid. */
				if( this.bandwidth == Jopus_defines.OPUS_BANDWIDTH_SUPERWIDEBAND || this.bandwidth == Jopus_defines.OPUS_BANDWIDTH_FULLBAND ) {
					this.silk_mode.bitRate += 3 * rate_offset / 5;
				} else {
					this.silk_mode.bitRate += rate_offset;
				}
				bytes_target += rate_offset * frame_size / (this.Fs << 3);
			}

			this.silk_mode.payloadSize_ms = 1000 * frame_size / this.Fs;
			this.silk_mode.nChannelsAPI = this.channels;
			this.silk_mode.nChannelsInternal = this.stream_channels;
			if( curr_bandwidth == Jopus_defines.OPUS_BANDWIDTH_NARROWBAND ) {
				this.silk_mode.desiredInternalSampleRate = 8000;
			} else if( curr_bandwidth == Jopus_defines.OPUS_BANDWIDTH_MEDIUMBAND ) {
				this.silk_mode.desiredInternalSampleRate = 12000;
			} else {
				// silk_assert( st.mode == MODE_HYBRID || curr_bandwidth == Jopus_defines.OPUS_BANDWIDTH_WIDEBAND );
				this.silk_mode.desiredInternalSampleRate = 16000;
			}
			if( this.mode == Jopus_private.MODE_HYBRID ) {
				/* Don't allow bandwidth reduction at lowest bitrates in hybrid mode */
				this.silk_mode.minInternalSampleRate = 16000;
			} else {
				this.silk_mode.minInternalSampleRate = 8000;
			}

			if( this.mode == Jopus_private.MODE_SILK_ONLY )
			{
				int effective_max_rate = max_rate;
				this.silk_mode.maxInternalSampleRate = 16000;
				if( frame_rate > 50 ) {
					effective_max_rate = (effective_max_rate << 1) / 3;
				}
				if( effective_max_rate < 13000 )
				{
					this.silk_mode.maxInternalSampleRate = 12000;
					this.silk_mode.desiredInternalSampleRate = 12000 < this.silk_mode.desiredInternalSampleRate ? 12000 : this.silk_mode.desiredInternalSampleRate;
				}
				if( effective_max_rate < 9600 )
				{
					this.silk_mode.maxInternalSampleRate = 8000;
					this.silk_mode.desiredInternalSampleRate = 8000 < this.silk_mode.desiredInternalSampleRate ? 8000 : this.silk_mode.desiredInternalSampleRate;
				}
			} else {
				this.silk_mode.maxInternalSampleRate = 16000;
			}

			this.silk_mode.useCBR = ! this.use_vbr;

			/* Call SILK encoder for the low band */
			int nBytes = max_data_bytes - 1 - redundancy_bytes;
			nBytes = 1275 <= nBytes ? 1275 : nBytes;

			this.silk_mode.maxBits = nBytes << 3;
			/* Only allow up to 90% of the bits for hybrid mode*/
			if( this.mode == Jopus_private.MODE_HYBRID ) {
				this.silk_mode.maxBits = this.silk_mode.maxBits * 9 / 10;
			}
			if( this.silk_mode.useCBR )
			{
				this.silk_mode.maxBits = (this.silk_mode.bitRate * frame_size / (this.Fs << 3)) << 3;
				/* Reduce the initial target to make it easier to reach the CBR rate */
				v = this.silk_mode.bitRate - 2000;// java
				this.silk_mode.bitRate = 1 >= v ? 1 : v;
			}

			final int[] data_holder = new int[1];// java helper
			if( prefill )
			{
				/* Use a smooth onset for the SILK prefill to avoid the encoder trying to encode
				   a discontinuity. The exact location is what we need to avoid leaving any "gap"
				   in the audio when mixing with the redundant CELT frame. Here we can afford to
				   overwrite st.delay_buffer because the only thing that uses it before it gets
				   rewritten is tmp_prefill[] and even then only the part after the ramp really
				   gets used (rather than sent to the encoder and discarded) */
				final int prefill_offset = this.channels * (this.encoder_buffer - this.delay_compensation - this.Fs / 400);
				gain_fade( this.delay_buffer, prefill_offset, this.delay_buffer, prefill_offset,
						0, Jfloat_cast.Q15ONE, celt_mode.overlap, this.Fs / 400, this.channels, celt_mode.window, this.Fs );
				// OPUS_CLEAR( st.delay_buffer, prefill_offset );
				for( int i = 0; i < prefill_offset; i++ ) {
					this.delay_buffer[i] = 0;
				}
/* #ifdef FIXED_POINT
				pcm_silk = st.delay_buffer;
#else */
				for( int i = 0, ie = this.encoder_buffer * this.channels; i < ie; i++ ) {
					pcm_silk[i] = Jfloat_cast.FLOAT2INT16( this.delay_buffer[i] );
				}
// #endif
				data_holder[0] = 0;// final int zero = 0;
				silkenc.silk_Encode( this.silk_mode, pcm_silk, this.encoder_buffer, null, data_holder/* &zero*/, true );
			}

/* #ifdef FIXED_POINT
			pcm_silk = pcm_buf + total_buffer * st.channels;
#else */
			for( int i = 0, ie = frame_size * this.channels, bi = total_buffer * this.channels; i < ie; i++, bi++ ) {
				pcm_silk[i] = Jfloat_cast.FLOAT2INT16( pcm_buf[bi] );
			}
// #endif
			data_holder[0] = nBytes;// java
			ret = silkenc.silk_Encode( this.silk_mode, pcm_silk, frame_size, enc, data_holder/*&nBytes*/, false );
			nBytes = data_holder[0];// java
			if( 0 != ret ) {
				/*fprintf (stderr, "SILK encode error: %d\n", ret);*/
				/* Handle error */
				// RESTORE_STACK;
				return Jopus_defines.OPUS_INTERNAL_ERROR;
			}
			if( nBytes == 0 )
			{
				this.rangeFinal = 0;
				data[--doffset] = (byte)gen_toc( this.mode, this.Fs / frame_size, curr_bandwidth, this.stream_channels );
				// RESTORE_STACK;
				return 1;
			}
			/* Extract SILK internal bandwidth for signaling in first byte */
			if( this.mode == Jopus_private.MODE_SILK_ONLY ) {
				if( this.silk_mode.internalSampleRate == 8000 ) {
					curr_bandwidth = Jopus_defines.OPUS_BANDWIDTH_NARROWBAND;
				} else if( this.silk_mode.internalSampleRate == 12000 ) {
					curr_bandwidth = Jopus_defines.OPUS_BANDWIDTH_MEDIUMBAND;
				} else if( this.silk_mode.internalSampleRate == 16000 ) {
					curr_bandwidth = Jopus_defines.OPUS_BANDWIDTH_WIDEBAND;
				}
			} else {
				// silk_assert( st.silk_mode.internalSampleRate == 16000 );
			}

			this.silk_mode.opusCanSwitch = this.silk_mode.switchReady;
			/* FIXME: How do we allocate the redundancy for CBR? */
			if( this.silk_mode.opusCanSwitch )
			{
				redundancy = true;
				celt_to_silk = false;
				this.silk_bw_switch = true;
			}
		}

		/* CELT processing */
		{
			int endband = 21;

			switch( curr_bandwidth )
			{
			case Jopus_defines.OPUS_BANDWIDTH_NARROWBAND:
				endband = 13;
				break;
			case Jopus_defines.OPUS_BANDWIDTH_MEDIUMBAND:
			case Jopus_defines.OPUS_BANDWIDTH_WIDEBAND:
				endband = 17;
				break;
			case Jopus_defines.OPUS_BANDWIDTH_SUPERWIDEBAND:
				endband = 19;
				break;
			case Jopus_defines.OPUS_BANDWIDTH_FULLBAND:
				endband = 21;
				break;
			}
			celtenc.celt_encoder_ctl( Jcelt.CELT_SET_END_BAND, endband );
			celtenc.celt_encoder_ctl( Jcelt.CELT_SET_CHANNELS, this.stream_channels );
		}
		celtenc.celt_encoder_ctl( Jopus_defines.OPUS_SET_BITRATE, Jopus_defines.OPUS_BITRATE_MAX );
		int nb_compr_bytes;
		if( this.mode != Jopus_private.MODE_SILK_ONLY )
		{
			int celt_pred = 2;
			celtenc.celt_encoder_ctl( Jopus_defines.OPUS_SET_VBR, false );
			/* We may still decide to disable prediction later */
			if( this.silk_mode.reducedDependency ) {
				celt_pred = 0;
			}
			celtenc.celt_encoder_ctl( Jcelt.CELT_SET_PREDICTION, celt_pred );

			if( this.mode == Jopus_private.MODE_HYBRID )
			{
				int len = (enc.ec_tell() + 7) >> 3;
				if( redundancy ) {
					len += this.mode == Jopus_private.MODE_HYBRID ? 3 : 1;
				}
				if( this.use_vbr ) {
					nb_compr_bytes = len + bytes_target - (this.silk_mode.bitRate * frame_size) / (this.Fs << 3);
				} else {
					/* check if SILK used up too much */
					nb_compr_bytes = len > bytes_target ? len : bytes_target;
				}
			} else {
				if( this.use_vbr )
				{
					int bonus = 0;
// #ifndef DISABLE_FLOAT_API
					if( this.variable_duration == Jcelt.OPUS_FRAMESIZE_VARIABLE && frame_size != this.Fs / 50 )
					{
						bonus = (60 * this.stream_channels + 40) * (this.Fs / frame_size - 50);
						if( analysis_info.valid ) {
							bonus = (int)(bonus * (1.f + .5f * analysis_info.tonality));
						}
					}
// #endif
					celtenc.celt_encoder_ctl( Jopus_defines.OPUS_SET_VBR, true );
					celtenc.celt_encoder_ctl( Jopus_defines.OPUS_SET_VBR_CONSTRAINT, this.vbr_constraint );
					celtenc.celt_encoder_ctl( Jopus_defines.OPUS_SET_BITRATE, this.bitrate_bps + bonus );
					nb_compr_bytes = max_data_bytes - 1 - redundancy_bytes;
				} else {
					nb_compr_bytes = bytes_target;
				}
			}

		} else {
			nb_compr_bytes = 0;
		}

		final float[] tmp_prefill = new float[this.channels * this.Fs / 400];
		if( this.mode != Jopus_private.MODE_SILK_ONLY  &&  this.mode != this.prev_mode && this.prev_mode > 0 )
		{
			// OPUS_COPY(tmp_prefill, &st.delay_buffer[(st.encoder_buffer-total_buffer-st.Fs/400)*st.channels], st.channels*st.Fs/400);
			System.arraycopy( this.delay_buffer, (this.encoder_buffer - total_buffer - this.Fs / 400) * this.channels, tmp_prefill, 0, this.channels * this.Fs / 400 );
		}

		if( this.channels * (this.encoder_buffer - (frame_size + total_buffer)) > 0 )
		{
			//OPUS_MOVE( st.delay_buffer, &st.delay_buffer[st.channels * frame_size], st.channels * (st.encoder_buffer - frame_size - total_buffer) );
			System.arraycopy( this.delay_buffer, this.channels * frame_size, this.delay_buffer, 0, this.channels * (this.encoder_buffer - frame_size - total_buffer) );
			//OPUS_COPY( &st.delay_buffer[st.channels * (st.encoder_buffer - frame_size - total_buffer)], &pcm_buf[0], (frame_size + total_buffer) * st.channels);
			System.arraycopy( pcm_buf, 0, this.delay_buffer, this.channels * (this.encoder_buffer - frame_size - total_buffer), (frame_size + total_buffer) * this.channels );
		} else {
			//OPUS_COPY( st.delay_buffer, &pcm_buf[(frame_size + total_buffer - st.encoder_buffer) * st.channels], st.encoder_buffer * st.channels );
			System.arraycopy( pcm_buf, (frame_size + total_buffer - this.encoder_buffer) * this.channels, this.delay_buffer, 0, this.encoder_buffer * this.channels );
		}
		/* gain_fade() and stereo_fade() need to be after the buffer copying
		   because we don't want any of this to affect the SILK part */
		if( this.prev_HB_gain < Jfloat_cast.Q15ONE || HB_gain < Jfloat_cast.Q15ONE ) {
			gain_fade( pcm_buf, 0, pcm_buf, 0,
					this.prev_HB_gain, HB_gain, celt_mode.overlap, frame_size, this.channels, celt_mode.window, this.Fs );
		}
		this.prev_HB_gain = HB_gain;
		if( this.mode != Jopus_private.MODE_HYBRID || this.stream_channels == 1 ) {
			v = equiv_rate - 30000;// java
			v = 0 >= v ? 0 : (v << 1);
			this.silk_mode.stereoWidth_Q14 = (1 << 14) <= v ? (1 << 14) : v;
		}
		if( null == this.energy_masking && this.channels == 2 ) {
			/* Apply stereo width reduction (at low bitrates) */
			if( this.hybrid_stereo_width_Q14 < (1 << 14) || this.silk_mode.stereoWidth_Q14 < (1 << 14) ) {
				float g1 = (float)this.hybrid_stereo_width_Q14;
				float g2 = (float)this.silk_mode.stereoWidth_Q14;
/* #ifdef FIXED_POINT
				g1 = g1 == 16384 ? Q15ONE : SHL16( g1, 1 );
				g2 = g2 == 16384 ? Q15ONE : SHL16( g2, 1 );
#else */
				g1 *= (1.f / 16384f);
				g2 *= (1.f / 16384f);
// #endif
				stereo_fade( pcm_buf, pcm_buf, g1, g2, celt_mode.overlap,
							frame_size, this.channels, celt_mode.window, this.Fs );
				this.hybrid_stereo_width_Q14 = (short)this.silk_mode.stereoWidth_Q14;// FIXME int -> int16
			}
		}

		if( this.mode != Jopus_private.MODE_CELT_ONLY && enc.ec_tell() + 17 + (this.mode == Jopus_private.MODE_HYBRID ? 20 : 0) <= ((max_data_bytes - 1) << 3) )
		{
			/* For SILK mode, the redundancy is inferred from the length */
			if( this.mode == Jopus_private.MODE_HYBRID && (redundancy || enc.ec_tell() + 37 <= (nb_compr_bytes << 3)) ) {
				enc.ec_enc_bit_logp( redundancy, 12 );
			}
			if( redundancy )
			{
				int max_redundancy;
				enc.ec_enc_bit_logp( celt_to_silk, 1 );
				max_redundancy = ( this.mode == Jopus_private.MODE_HYBRID ) ?
								(max_data_bytes - 1) - nb_compr_bytes
								:
								(max_data_bytes - 1) - ((enc.ec_tell() + 7) >> 3);
				/* Target the same bit-rate for redundancy as for the rest,
				   up to a max of 257 bytes */
				redundancy_bytes = this.bitrate_bps / 1600;
				redundancy_bytes = max_redundancy <= redundancy_bytes ? max_redundancy : redundancy_bytes;
				redundancy_bytes = 2 >= redundancy_bytes ? 2 : redundancy_bytes;
				redundancy_bytes = 257 <= redundancy_bytes ? 257 : redundancy_bytes;
				if( this.mode == Jopus_private.MODE_HYBRID ) {
					enc.ec_enc_uint( redundancy_bytes - 2, 256 );
				}
			}
		} else {
			redundancy = false;
		}

		if( ! redundancy )
		{
			this.silk_bw_switch = false;
			redundancy_bytes = 0;
		}

		int start_band = 0;
		if( this.mode != Jopus_private.MODE_CELT_ONLY ) {
			start_band = 17;
		}

		if( this.mode == Jopus_private.MODE_SILK_ONLY )
		{
			ret = (enc.ec_tell() + 7) >> 3;
			enc.ec_enc_done();
			nb_compr_bytes = ret;
		} else {
			v = (max_data_bytes - 1) - redundancy_bytes;// java
			nb_compr_bytes = v <= nb_compr_bytes ? v : nb_compr_bytes;
			enc.ec_enc_shrink( nb_compr_bytes );
		}

// #ifndef DISABLE_FLOAT_API
		if( redundancy || this.mode != Jopus_private.MODE_SILK_ONLY ) {
			celtenc.celt_encoder_ctl( Jcelt.CELT_SET_ANALYSIS, analysis_info );
		}
// #endif

		long redundant_rng = 0;
		/* 5 ms redundant frame for CELT.SILK */
		if( redundancy && celt_to_silk )
		{
			celtenc.celt_encoder_ctl( Jcelt.CELT_SET_START_BAND, 0 );
			celtenc.celt_encoder_ctl( Jopus_defines.OPUS_SET_VBR, false );
			final int err = celtenc.celt_encode_with_ec( pcm_buf, 0, this.Fs / 200, data, doffset + nb_compr_bytes, redundancy_bytes, null );
			if( err < 0 )
			{
				// RESTORE_STACK;
				return Jopus_defines.OPUS_INTERNAL_ERROR;
			}
			celtenc.celt_encoder_ctl( Jopus_defines.OPUS_GET_FINAL_RANGE, request );
			redundant_rng = ((Long)request[0]).longValue();// java
			celtenc.celt_encoder_ctl( Jopus_defines.OPUS_RESET_STATE );
		}

		celtenc.celt_encoder_ctl( Jcelt.CELT_SET_START_BAND, start_band );

		if( this.mode != Jopus_private.MODE_SILK_ONLY )
		{
			if( this.mode != this.prev_mode && this.prev_mode > 0 )
			{
				celtenc.celt_encoder_ctl( Jopus_defines.OPUS_RESET_STATE );

				/* Prefilling */
				final byte dummy[] = new byte[2];
				celtenc.celt_encode_with_ec( tmp_prefill, 0, this.Fs / 400, dummy, 0, 2, null );
				celtenc.celt_encoder_ctl( Jcelt.CELT_SET_PREDICTION, 0 );
			}
			/* If false, we already busted the budget and we'll end up with a "PLC packet" */
			if( enc.ec_tell() <= 8 * nb_compr_bytes )
			{
				ret = celtenc.celt_encode_with_ec( pcm_buf, 0, frame_size, null, 0, nb_compr_bytes, enc );
				if( ret < 0 )
				{
					// RESTORE_STACK;
					return Jopus_defines.OPUS_INTERNAL_ERROR;
				}
			}
		}

		/* 5 ms redundant frame for SILK.CELT */
		if( redundancy  && ! celt_to_silk )
		{
			final int N2 = this.Fs / 200;
			final int N4 = N2 >> 1;// this.Fs / 400;

			celtenc.celt_encoder_ctl( Jopus_defines.OPUS_RESET_STATE );
			celtenc.celt_encoder_ctl( Jcelt.CELT_SET_START_BAND, 0 );
			celtenc.celt_encoder_ctl( Jcelt.CELT_SET_PREDICTION, 0 );

			/* NOTE: We could speed this up slightly (at the expense of code size) by just adding a function that prefills the buffer */
			final byte dummy[] = new byte[2];
			celtenc.celt_encode_with_ec( pcm_buf, this.channels * (frame_size - N2 - N4), N4, dummy, 0, 2, null );

			final int err = celtenc.celt_encode_with_ec( pcm_buf, this.channels * (frame_size - N2), N2, data, doffset + nb_compr_bytes, redundancy_bytes, null );
			if( err < 0 )
			{
				// RESTORE_STACK;
				return Jopus_defines.OPUS_INTERNAL_ERROR;
			}
			celtenc.celt_encoder_ctl( Jopus_defines.OPUS_GET_FINAL_RANGE, request );
			redundant_rng = ((Long)request[0]).longValue();// java
		}

		/* Signalling the mode in the first byte */
		doffset--;// data--;
		data[doffset] = (byte)gen_toc( this.mode, this.Fs / frame_size, curr_bandwidth, this.stream_channels );

		this.rangeFinal = enc.rng ^ redundant_rng;

		if( to_celt ) {
			this.prev_mode = Jopus_private.MODE_CELT_ONLY;
		} else {
			this.prev_mode = this.mode;
		}
		this.prev_channels = this.stream_channels;
		this.prev_framesize = frame_size;

		this.first = false;

		/* In the unlikely case that the SILK encoder busted its target, tell
		   the decoder to call the PLC */
		if( enc.ec_tell() > ((max_data_bytes - 1) << 3) )
		{
			if( max_data_bytes < 2 )
			{
				// RESTORE_STACK;
				return Jopus_defines.OPUS_BUFFER_TOO_SMALL;
			}
			data[doffset + 1] = 0;
			ret = 1;
			this.rangeFinal = 0;
		} else if( this.mode == Jopus_private.MODE_SILK_ONLY && ! redundancy )
		{
			/*When in LPC only mode it's perfectly
			  reasonable to strip off trailing zero bytes as
			  the required range decoder behavior is to
			  fill these in. This can't be done when the MDCT
			  modes are used because the decoder needs to know
			  the actual length for allocation purposes.*/
			while( ret > 2 && data[doffset + ret] == 0 ) {
				ret--;
			}
		}
		/* Count ToC and redundancy */
		ret += 1 + redundancy_bytes;
		if( ! this.use_vbr )
		{
			if( JOpusRepacketizer.opus_packet_pad( data, doffset, ret, max_data_bytes ) != Jopus_defines.OPUS_OK )

			{
				// RESTORE_STACK;
				return Jopus_defines.OPUS_INTERNAL_ERROR;
			}
			ret = max_data_bytes;
		}
		// RESTORE_STACK;
		return ret;
	}

// #ifdef FIXED_POINT

// #ifndef DISABLE_FLOAT_API
	/** Encodes an Opus frame from floating point input.
	 * @param [in] st <tt>OpusEncoder*</tt>: Encoder state
	 * @param [in] pcm <tt>float*</tt>: Input in float format (interleaved if 2 channels), with a normal range of +/-1.0.
	 *          Samples with a range beyond +/-1.0 are supported but will
	 *          be clipped by decoders using the integer API and should
	 *          only be used if it is known that the far end supports
	 *          extended dynamic range.
	 *          length is frame_size*channels*sizeof(float)
	 * @param [in] frame_size <tt>int</tt>: Number of samples per channel in the
	 *                                      input signal.
	 *                                      This must be an Opus frame size for
	 *                                      the encoder's sampling rate.
	 *                                      For example, at 48 kHz the permitted
	 *                                      values are 120, 240, 480, 960, 1920,
	 *                                      and 2880.
	 *                                      Passing in a duration of less than
	 *                                      10 ms (480 samples at 48 kHz) will
	 *                                      prevent the encoder from using the LPC
	 *                                      or hybrid modes.
	 * @param [out] data <tt>unsigned char*</tt>: Output payload.
	 *                                            This must contain storage for at
	 *                                            least \a max_data_bytes.
	 * @param [in] max_data_bytes <tt>opus_int32</tt>: Size of the allocated
	 *                                                 memory for the output
	 *                                                 payload. This may be
	 *                                                 used to impose an upper limit on
	 *                                                 the instant bitrate, but should
	 *                                                 not be used as the only bitrate
	 *                                                 control. Use #OPUS_SET_BITRATE to
	 *                                                 control the bitrate.
	 * @returns The length of the encoded packet (in bytes) on success or a
	 *          negative error code (see @ref opus_errorcodes) on failure.
 */
/*	private static final int opus_encode_float(final JOpusEncoder st, final float[] pcm, final int analysis_frame_size,
		unsigned char *data, int max_data_bytes)
	{
		int i, ret;
		int frame_size;
		int delay_compensation;
		VARDECL( opus_int16, in );
		ALLOC_STACK;

		if( st.application == OPUS_APPLICATION_RESTRICTED_LOWDELAY )
			delay_compensation = 0;
		else
			delay_compensation = st.delay_compensation;
		frame_size = compute_frame_size( pcm, analysis_frame_size,
						st.variable_duration, st.channels, st.Fs, st.bitrate_bps,
						delay_compensation, downmix_float, st.analysis.subframe_mem );

		ALLOC( in, frame_size * st.channels, short );

		for( i = 0; i < frame_size * st.channels; i++ )
			in[i] = FLOAT2INT16( pcm[i] );
		ret = opus_encode_native( st, in, frame_size, data, max_data_bytes, 16,
						pcm, analysis_frame_size, 0, -2, st.channels, downmix_float, 1 );
		RESTORE_STACK;
		return ret;
	}
#endif */

	/** Encodes an Opus frame.
	 * @param [in] st <tt>OpusEncoder*</tt>: Encoder state
	 * @param [in] pcm <tt>opus_int16*</tt>: Input signal (interleaved if 2 channels). length is frame_size*channels*sizeof(opus_int16)
	 * @param [in] frame_size <tt>int</tt>: Number of samples per channel in the
	 *                                      input signal.
	 *                                      This must be an Opus frame size for
	 *                                      the encoder's sampling rate.
	 *                                      For example, at 48 kHz the permitted
	 *                                      values are 120, 240, 480, 960, 1920,
	 *                                      and 2880.
	 *                                      Passing in a duration of less than
	 *                                      10 ms (480 samples at 48 kHz) will
	 *                                      prevent the encoder from using the LPC
	 *                                      or hybrid modes.
	 * @param [out] data <tt>unsigned char*</tt>: Output payload.
	 *                                            This must contain storage for at
	 *                                            least \a max_data_bytes.
	 * @param [in] max_data_bytes <tt>opus_int32</tt>: Size of the allocated
	 *                                                 memory for the output
	 *                                                 payload. This may be
	 *                                                 used to impose an upper limit on
	 *                                                 the instant bitrate, but should
	 *                                                 not be used as the only bitrate
	 *                                                 control. Use #OPUS_SET_BITRATE to
	 *                                                 control the bitrate.
	 * @returns The length of the encoded packet (in bytes) on success or a
	 *          negative error code (see @ref opus_errorcodes) on failure.
	 */
/*	private static final opus_int32 opus_encode(final JOpusEncoder st, final short[] pcm, final int analysis_frame_size,
			unsigned char *data, int out_data_bytes)
	{
		int frame_size;
		int delay_compensation;
		if( st.application == OPUS_APPLICATION_RESTRICTED_LOWDELAY )
			delay_compensation = 0;
		else
			delay_compensation = st.delay_compensation;
		frame_size = compute_frame_size( pcm, analysis_frame_size,
				st.variable_duration, st.channels, st.Fs, st.bitrate_bps,
				delay_compensation, downmix_int
#ifndef DISABLE_FLOAT_API
				, st.analysis.subframe_mem
#endif
				);
		return opus_encode_native( st, pcm, frame_size, data, out_data_bytes, 16,
				pcm, analysis_frame_size, 0, -2, st.channels, downmix_int, 0 );
	}

#else */
	/** Encodes an Opus frame.
	  * @param [in] st <tt>OpusEncoder*</tt>: Encoder state
	  * @param [in] pcm <tt>opus_int16*</tt>: Input signal (interleaved if 2 channels). length is frame_size*channels*sizeof(opus_int16)
	  * @param [in] frame_size <tt>int</tt>: Number of samples per channel in the
	  *                                      input signal.
	  *                                      This must be an Opus frame size for
	  *                                      the encoder's sampling rate.
	  *                                      For example, at 48 kHz the permitted
	  *                                      values are 120, 240, 480, 960, 1920,
	  *                                      and 2880.
	  *                                      Passing in a duration of less than
	  *                                      10 ms (480 samples at 48 kHz) will
	  *                                      prevent the encoder from using the LPC
	  *                                      or hybrid modes.
	  * @param [out] data <tt>unsigned char*</tt>: Output payload.
	  *                                            This must contain storage for at
	  *                                            least \a max_data_bytes.
	  * @param [in] max_data_bytes <tt>opus_int32</tt>: Size of the allocated
	  *                                                 memory for the output
	  *                                                 payload. This may be
	  *                                                 used to impose an upper limit on
	  *                                                 the instant bitrate, but should
	  *                                                 not be used as the only bitrate
	  *                                                 control. Use #OPUS_SET_BITRATE to
	  *                                                 control the bitrate.
	  * @returns The length of the encoded packet (in bytes) on success or a
	  *          negative error code (see @ref opus_errorcodes) on failure.
	  */
	public final int opus_encode(final short[] pcm, final int pcmoffset,// java
				final int analysis_frame_size,
				final byte[] data, final int max_data_bytes)
	{
		// ALLOC_STACK;

		final int delay_comp = this.application == Jopus_defines.OPUS_APPLICATION_RESTRICTED_LOWDELAY ? 0 : this.delay_compensation;
		final int frame_size = compute_frame_size( pcm, pcmoffset, analysis_frame_size,
				this.variable_duration, this.channels, this.Fs, this.bitrate_bps,
				delay_comp, downmix_int, this.analysis.subframe_mem );

		final float[] in = new float[frame_size * this.channels];

		for( int i = 0, ie = frame_size * this.channels, j = pcmoffset; i < ie; i++ ) {
			in[i] = (1.0f / 32768f) * pcm[j++];
		}
		final int ret = opus_encode_native( in, 0, frame_size, data, 0, max_data_bytes, 16,
					pcm, pcmoffset, analysis_frame_size, 0, -2, this.channels, downmix_int, false );
		// RESTORE_STACK;
		return ret;
	}

	/** Encodes an Opus frame from floating point input.
	 * @param [in] st <tt>OpusEncoder*</tt>: Encoder state
	 * @param [in] pcm <tt>float*</tt>: Input in float format (interleaved if 2 channels), with a normal range of +/-1.0.
	 *          Samples with a range beyond +/-1.0 are supported but will
	 *          be clipped by decoders using the integer API and should
	 *          only be used if it is known that the far end supports
	 *          extended dynamic range.
	 *          length is frame_size*channels*sizeof(float)
	 * @param [in] frame_size <tt>int</tt>: Number of samples per channel in the
	 *                                      input signal.
	 *                                      This must be an Opus frame size for
	 *                                      the encoder's sampling rate.
	 *                                      For example, at 48 kHz the permitted
	 *                                      values are 120, 240, 480, 960, 1920,
	 *                                      and 2880.
	 *                                      Passing in a duration of less than
	 *                                      10 ms (480 samples at 48 kHz) will
	 *                                      prevent the encoder from using the LPC
	 *                                      or hybrid modes.
	 * @param [out] data <tt>unsigned char*</tt>: Output payload.
	 *                                            This must contain storage for at
	 *                                            least \a max_data_bytes.
	 * @param [in] max_data_bytes <tt>opus_int32</tt>: Size of the allocated
	 *                                                 memory for the output
	 *                                                 payload. This may be
	 *                                                 used to impose an upper limit on
	 *                                                 the instant bitrate, but should
	 *                                                 not be used as the only bitrate
	 *                                                 control. Use #OPUS_SET_BITRATE to
	 *                                                 control the bitrate.
	 * @returns The length of the encoded packet (in bytes) on success or a
	 *          negative error code (see @ref opus_errorcodes) on failure.
	 */
	public final int opus_encode_float(final float[] pcm, final int analysis_frame_size,
								final byte[] data, final int out_data_bytes)
	{
		final int delay_comp = this.application == Jopus_defines.OPUS_APPLICATION_RESTRICTED_LOWDELAY ? 0 : this.delay_compensation;
		final int frame_size = compute_frame_size( pcm, 0, analysis_frame_size,
				this.variable_duration, this.channels, this.Fs, this.bitrate_bps,
				delay_comp, downmix_float, this.analysis.subframe_mem );
		return opus_encode_native( pcm, 0, frame_size, data, 0, out_data_bytes, 24,
					pcm, 0, analysis_frame_size, 0, -2, this.channels, downmix_float, true );
	}
// #endif

	// java: Object... args don't uses because impossible to control arg type
	// java: uses different functions for getters and setters
	/** Perform a CTL function on an Opus encoder.
	 *
	 * java: getters
	 *
	 * Generally the request and subsequent arguments are generated
	 * by a convenience macro.
	 * @param st <tt>OpusEncoder*</tt>: Encoder state.
	 * @param request This and all remaining parameters should be replaced by one
	 *                of the convenience macros in @ref opus_genericctls or
	 *                @ref opus_encoderctls.
	 * @see opus_genericctls
	 * @see opus_encoderctls
	 */
	public final int opus_encoder_ctl(final int request, final Object[] arg)
	{// getters
		if( arg == null || arg.length == 0 )
		{
			return Jopus_defines.OPUS_BAD_ARG;
		}

		int ret = Jopus_defines.OPUS_OK;

		switch( request )
		{
		case Jopus_defines.OPUS_GET_APPLICATION_REQUEST:
			{
				arg[0] = Integer.valueOf( this.application );
			}
			break;
		case Jopus_defines.OPUS_GET_BITRATE_REQUEST:
			{
				arg[0] = Integer.valueOf( user_bitrate_to_bitrate( this.prev_framesize, 1276 ) );
			}
			break;
		case Jopus_defines.OPUS_GET_FORCE_CHANNELS_REQUEST:
			{
				arg[0] = Integer.valueOf( this.force_channels );
			}
			break;
		case Jopus_defines.OPUS_GET_MAX_BANDWIDTH_REQUEST:
			{
				arg[0] = Integer.valueOf( this.max_bandwidth );
			}
			break;
		case Jopus_defines.OPUS_GET_BANDWIDTH_REQUEST:
			{
				arg[0] = Integer.valueOf( this.bandwidth );
			}
			break;
		case Jopus_defines.OPUS_GET_DTX_REQUEST:
			{
				arg[0] = Boolean.valueOf( this.silk_mode.useDTX );
			}
			break;
		case Jopus_defines.OPUS_GET_COMPLEXITY_REQUEST:
			{
				arg[0] = Integer.valueOf( this.silk_mode.complexity );
			}
			break;
		case Jopus_defines.OPUS_GET_INBAND_FEC_REQUEST:
			{
				arg[0] = Boolean.valueOf( this.silk_mode.useInBandFEC );
			}
			break;
		case Jopus_defines.OPUS_GET_PACKET_LOSS_PERC_REQUEST:
			{
				arg[0] = Integer.valueOf( this.silk_mode.packetLossPercentage );
			}
			break;
		case Jopus_defines.OPUS_GET_VBR_REQUEST:
			{
				arg[0] = Boolean.valueOf( this.use_vbr );
			}
			break;
		case Jopus_private.OPUS_GET_VOICE_RATIO_REQUEST:
			{
				arg[0] = Integer.valueOf( this.voice_ratio );
			}
			break;
		case Jopus_defines.OPUS_GET_VBR_CONSTRAINT_REQUEST:
			{
				arg[0] = Boolean.valueOf( this.vbr_constraint );
			}
			break;
		case Jopus_defines.OPUS_GET_SIGNAL_REQUEST:
			{
				arg[0] = Integer.valueOf( this.signal_type );
			}
			break;
		case Jopus_defines.OPUS_GET_LOOKAHEAD_REQUEST:
			{
				int v = this.Fs / 400;
				if( this.application != Jopus_defines.OPUS_APPLICATION_RESTRICTED_LOWDELAY ) {
					v += this.delay_compensation;
				}
				arg[0] = Integer.valueOf( v );
			}
			break;
		case Jopus_defines.OPUS_GET_SAMPLE_RATE_REQUEST:
			{
				arg[0] = Integer.valueOf( this.Fs );
			}
			break;
		case Jopus_defines.OPUS_GET_FINAL_RANGE_REQUEST:
			{
				arg[0] = Long.valueOf( this.rangeFinal );
			}
			break;
		case Jopus_defines.OPUS_GET_LSB_DEPTH_REQUEST:
			{
				arg[0] = Integer.valueOf( this.lsb_depth );
			}
			break;
		case Jopus_defines.OPUS_GET_EXPERT_FRAME_DURATION_REQUEST:
			{
				arg[0] = Integer.valueOf( this.variable_duration );
			}
			break;
		case Jopus_defines.OPUS_GET_PREDICTION_DISABLED_REQUEST:
			{
				arg[0] = Boolean.valueOf( this.silk_mode.reducedDependency );
			}
			break;
		case Jcelt.CELT_GET_MODE_REQUEST:
			{
				ret = this.celt_enc.celt_encoder_ctl( Jcelt.CELT_GET_MODE_REQUEST, arg );
			}
			break;
		default:
			/* fprintf(stderr, "unknown opus_encoder_ctl() request: %d", request);*/
			// System.err.println( CLASS_NAME + " unknown request: " + request );
			ret = Jopus_defines.OPUS_UNIMPLEMENTED;
			break;
		}
		return ret;
	}
	// java added overload variant, setters
	/**
	 * Setters for int
	 *
	 * @param st
	 * @param request
	 * @param value
	 * @return
	 */
	public final int opus_encoder_ctl(final int request, int value)
	{
		int ret = Jopus_defines.OPUS_OK;

		switch( request )
		{
		case Jopus_defines.OPUS_SET_APPLICATION_REQUEST:
			{
				if( (value != Jopus_defines.OPUS_APPLICATION_VOIP && value != Jopus_defines.OPUS_APPLICATION_AUDIO
					&&  value != Jopus_defines.OPUS_APPLICATION_RESTRICTED_LOWDELAY )
						|| (! this.first && this.application != value) )
				{
					ret = Jopus_defines.OPUS_BAD_ARG;
					break;
				}
				this.application = value;
			}
			break;
		case Jopus_defines.OPUS_SET_BITRATE_REQUEST:
			{
				if( value != Jopus_defines.OPUS_AUTO && value != Jopus_defines.OPUS_BITRATE_MAX )
				{
					if( value <= 0 ) {
						return Jopus_defines.OPUS_BAD_ARG;
					} else if( value <= 500 ) {
						value = 500;
					} else if( value > (int)300000 * this.channels ) {
						value = (int)300000 * this.channels;
					}
				}
				this.user_bitrate_bps = value;
			}
			break;
		case Jopus_defines.OPUS_SET_FORCE_CHANNELS_REQUEST:
			{
				if( (value < 1 || value > this.channels) && value != Jopus_defines.OPUS_AUTO )
				{
					return Jopus_defines.OPUS_BAD_ARG;
				}
				this.force_channels = value;
			}
			break;
		case Jopus_defines.OPUS_SET_MAX_BANDWIDTH_REQUEST:
			{
				if( value < Jopus_defines.OPUS_BANDWIDTH_NARROWBAND || value > Jopus_defines.OPUS_BANDWIDTH_FULLBAND )
				{
					return Jopus_defines.OPUS_BAD_ARG;
				}
				this.max_bandwidth = value;
				if( this.max_bandwidth == Jopus_defines.OPUS_BANDWIDTH_NARROWBAND ) {
					this.silk_mode.maxInternalSampleRate = 8000;
				} else if( this.max_bandwidth == Jopus_defines.OPUS_BANDWIDTH_MEDIUMBAND ) {
					this.silk_mode.maxInternalSampleRate = 12000;
				} else {
					this.silk_mode.maxInternalSampleRate = 16000;
				}
			}
			break;
		case Jopus_defines.OPUS_SET_BANDWIDTH_REQUEST:
			{
				if( (value < Jopus_defines.OPUS_BANDWIDTH_NARROWBAND || value > Jopus_defines.OPUS_BANDWIDTH_FULLBAND) && value != Jopus_defines.OPUS_AUTO )
				{
					return Jopus_defines.OPUS_BAD_ARG;
				}
				this.user_bandwidth = value;
				if( this.user_bandwidth == Jopus_defines.OPUS_BANDWIDTH_NARROWBAND ) {
					this.silk_mode.maxInternalSampleRate = 8000;
				} else if( this.user_bandwidth == Jopus_defines.OPUS_BANDWIDTH_MEDIUMBAND ) {
					this.silk_mode.maxInternalSampleRate = 12000;
				} else {
					this.silk_mode.maxInternalSampleRate = 16000;
				}
			}
			break;
		case Jopus_defines.OPUS_SET_COMPLEXITY_REQUEST:
			{
				if( value < 0 || value > 10 )
				{
					return Jopus_defines.OPUS_BAD_ARG;
				}
				this.silk_mode.complexity = value;
				this.celt_enc.celt_encoder_ctl( Jopus_defines.OPUS_SET_COMPLEXITY_REQUEST, value );
			}
			break;
		case Jopus_defines.OPUS_SET_PACKET_LOSS_PERC_REQUEST:
			{
				if( value < 0 || value > 100 )
				{
					return Jopus_defines.OPUS_BAD_ARG;
				}
				this.silk_mode.packetLossPercentage = value;
				this.celt_enc.celt_encoder_ctl( Jopus_defines.OPUS_SET_PACKET_LOSS_PERC_REQUEST, value );
			}
			break;
		case Jopus_private.OPUS_SET_VOICE_RATIO_REQUEST:
			{
				if( value < -1 || value > 100 )
				{
					return Jopus_defines.OPUS_BAD_ARG;
				}
				this.voice_ratio = value;
			}
			break;
		case Jopus_defines.OPUS_SET_SIGNAL_REQUEST:
			{
				if( value != Jopus_defines.OPUS_AUTO && value != Jopus_defines.OPUS_SIGNAL_VOICE && value != Jopus_defines.OPUS_SIGNAL_MUSIC )
				{
					return Jopus_defines.OPUS_BAD_ARG;
				}
				this.signal_type = value;
			}
			break;
		case Jopus_defines.OPUS_SET_LSB_DEPTH_REQUEST:
			{
				if( value < 8 || value > 24 )
				{
					return Jopus_defines.OPUS_BAD_ARG;
				}
				this.lsb_depth = value;
			}
			break;
		case Jopus_defines.OPUS_SET_EXPERT_FRAME_DURATION_REQUEST:
			{
				if( value != Jopus_defines.OPUS_FRAMESIZE_ARG && value != Jopus_defines.OPUS_FRAMESIZE_2_5_MS &&
					value != Jopus_defines.OPUS_FRAMESIZE_5_MS  && value != Jopus_defines.OPUS_FRAMESIZE_10_MS &&
					value != Jopus_defines.OPUS_FRAMESIZE_20_MS && value != Jopus_defines.OPUS_FRAMESIZE_40_MS &&
					value != Jopus_defines.OPUS_FRAMESIZE_60_MS && value != Jcelt.OPUS_FRAMESIZE_VARIABLE )
				{
					return Jopus_defines.OPUS_BAD_ARG;
				}
				this.variable_duration = value;
				this.celt_enc.celt_encoder_ctl( Jopus_defines.OPUS_SET_EXPERT_FRAME_DURATION_REQUEST, value );
			}
			break;
		case Jopus_private.OPUS_SET_FORCE_MODE_REQUEST:
			{
				if( (value < Jopus_private.MODE_SILK_ONLY || value > Jopus_private.MODE_CELT_ONLY) && value != Jopus_defines.OPUS_AUTO )
				{
					return Jopus_defines.OPUS_BAD_ARG;
				}
				this.user_forced_mode = value;
			}
			break;
		default:
			/* fprintf(stderr, "unknown opus_encoder_ctl() request: %d", request);*/
			// System.err.println( CLASS_NAME + " unknown request: " + request );
			ret = Jopus_defines.OPUS_UNIMPLEMENTED;
			break;
		}
		return ret;
	}
	/**
	 * Setters for boolean
	 *
	 * @param st
	 * @param request
	 * @param value
	 * @return
	 */
	public final int opus_encoder_ctl(final int request, final boolean value)
	{
		int ret = Jopus_defines.OPUS_OK;

		switch( request )
		{
		case Jopus_defines.OPUS_SET_DTX_REQUEST:
			{
				this.silk_mode.useDTX = value;
			}
			break;
		case Jopus_defines.OPUS_SET_INBAND_FEC_REQUEST:
			{
				this.silk_mode.useInBandFEC = value;
			}
			break;
		case Jopus_defines.OPUS_SET_VBR_REQUEST:
			{
				this.use_vbr = value;
				this.silk_mode.useCBR = ! value;
			}
			break;
		case Jopus_defines.OPUS_SET_VBR_CONSTRAINT_REQUEST:
			{
				this.vbr_constraint = value;
			}
			break;
		case Jopus_defines.OPUS_SET_PREDICTION_DISABLED_REQUEST:
			{
				this.silk_mode.reducedDependency = value;
			}
			break;
		case Jcelt.OPUS_SET_LFE_REQUEST:
			{
				this.lfe = value;
				ret = this.celt_enc.celt_encoder_ctl( Jcelt.OPUS_SET_LFE_REQUEST, value );
			}
			break;
		default:
			/* fprintf(stderr, "unknown opus_encoder_ctl() request: %d", request);*/
			// System.err.println( CLASS_NAME + " unknown request: " + request );
			ret = Jopus_defines.OPUS_UNIMPLEMENTED;
			break;
		}
		return ret;
	}
	/**
	 * Setters for objects
	 *
	 * @param st
	 * @param request
	 * @param arg
	 * @return
	 */
	public final int opus_encoder_ctl(final int request, final Object arg)
	{
		if( arg == null )
		{
			return Jopus_defines.OPUS_BAD_ARG;
		}

		int ret = Jopus_defines.OPUS_OK;

		switch( request )
		{
		case Jcelt.OPUS_SET_ENERGY_MASK_REQUEST:
			{
				if( ! (arg instanceof float[]) )
				{
					return Jopus_defines.OPUS_BAD_ARG;
				}
				this.energy_masking = (float[])arg;
				ret = this.celt_enc.celt_encoder_ctl( Jcelt.OPUS_SET_ENERGY_MASK_REQUEST, arg );
			}
			break;
		default:
			/* fprintf(stderr, "unknown opus_encoder_ctl() request: %d", request);*/
			// System.err.println( CLASS_NAME + " unknown request: " + request );
			ret = Jopus_defines.OPUS_UNIMPLEMENTED;
			break;
		}
		return ret;
	}
	// java added overload variant
	/**
	 * requests without arguments
	 *
	 * @param request
	 * @return
	 */
	public final int opus_encoder_ctl(final int request) {
		int ret = Jopus_defines.OPUS_OK;

		switch( request )
		{
		case Jopus_defines.OPUS_RESET_STATE:
			{
// #ifndef DISABLE_FLOAT_API
				this.analysis.tonality_analysis_reset();
// #endif

				//start = (char*)&st.OPUS_ENCODER_RESET_START;
				//OPUS_CLEAR( start, sizeof(JOpusEncoder) - (start - (char*)st) );
				clear( false );

				this.celt_enc.celt_encoder_ctl( Jopus_defines.OPUS_RESET_STATE );
				this.silk_enc.silk_InitEncoder( /*st.arch,*/ new Jsilk_EncControlStruct() );
				this.stream_channels = this.channels;
				this.hybrid_stereo_width_Q14 = 1 << 14;
				this.prev_HB_gain = Jfloat_cast.Q15ONE;
				this.first = true;
				this.mode = Jopus_private.MODE_HYBRID;
				this.bandwidth = Jopus_defines.OPUS_BANDWIDTH_FULLBAND;
				this.variable_HP_smth2_Q15 = Jmacros.silk_lin2log( Jtuning_parameters.VARIABLE_HP_MIN_CUTOFF_HZ ) << 8;
			}
			break;
		default:
			/* fprintf(stderr, "unknown opus_encoder_ctl() request: %d", request);*/
			// System.err.println( CLASS_NAME + " unknown request: " + request );
			ret = Jopus_defines.OPUS_UNIMPLEMENTED;
			break;
		}
		return ret;
	}

	/** Frees an <code>OpusEncoder</code> allocated by opus_encoder_create().
	 *
	 * java: use st = null
	 *
	 * @param[in] st <tt>OpusEncoder*</tt>: State to be freed.
	 */
	/*private static final void opus_encoder_destroy(final JOpusEncoder st)
	{
		opus_free( st );
	}*/

}
