package opus;

/**
 * Auxilary structure to exchange data on java
 */
public final class Jopus_packet_data_aux {
	public byte mToc;
	public int mPayloadOffset;
	public int mPacketOffset;
}
