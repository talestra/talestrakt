package opus;

/** Auxilary structure to exchange data on java */
public final class Jms_encoder_data_aux {
	public int streams;
	public int coupled_streams;
}
