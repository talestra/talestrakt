package libmp3lame;

public interface Jid3tag_handler {
	void handle(int num, String name, Object obj);
}
