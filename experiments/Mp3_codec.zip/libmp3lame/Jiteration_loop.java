package libmp3lame;

interface Jiteration_loop {
	//typedef void (*iteration_loop_t) (lame_internal_flags * gfc, const FLOAT pe[2][2],
	//		const FLOAT ms_ratio[2], const III_psy_ratio ratio[2][2]);
	void iteration(Jlame_internal_flags gfc, float pe[][], float ms_ratio[], JIII_psy_ratio ratio[][]);
}
