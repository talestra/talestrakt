package libmpghip;

final class Jal_table2 {
	short bits;
	short d;
	//
	Jal_table2(final int nbits, final int data) {
		this.bits = (short)nbits;
		this.d = (short)data;
	}
}
